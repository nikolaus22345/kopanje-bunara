import { 
  LayoutDashboard, 
  FileText, 
  FolderOpen, 
  Tags, 
  Bookmark, 
  Settings, 
  LogOut,
  ChevronRight,
  MapPin,
  Wrench,
  LayoutGrid,
  Link2
} from 'lucide-react';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const menuItems = [
  { title: 'Dashboard', url: '/admin', icon: LayoutDashboard },
  { title: 'Brzo uređivanje', url: '/admin/quick-edit', icon: Link2 },
  { title: 'Sekcije stranica', url: '/admin/sections', icon: LayoutGrid },
  { title: 'Blog Objave', url: '/admin/posts', icon: FileText },
  { title: 'Stranice', url: '/admin/pages', icon: FolderOpen },
  { title: 'Lokacije', url: '/admin/locations', icon: MapPin },
  { title: 'Usluge', url: '/admin/services', icon: Wrench },
  { title: 'Kategorije', url: '/admin/categories', icon: Bookmark },
  { title: 'Tagovi', url: '/admin/tags', icon: Tags },
  { title: 'Postavke', url: '/admin/settings', icon: Settings },
];

export function AdminSidebar() {
  const { signOut, user } = useAuth();
  const location = useLocation();
  const { state } = useSidebar();
  const collapsed = state === 'collapsed';

  const isActive = (url: string) => {
    if (url === '/admin') {
      return location.pathname === '/admin';
    }
    return location.pathname.startsWith(url);
  };

  return (
    <Sidebar collapsible="icon" className="border-r bg-background">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="px-4 py-3">
            {!collapsed && (
              <span className="text-lg font-bold text-primary">CMS Admin</span>
            )}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2 rounded-md transition-colors",
                        isActive(item.url)
                          ? "bg-primary text-primary-foreground"
                          : "hover:bg-muted text-muted-foreground hover:text-foreground"
                      )}
                    >
                      <item.icon className="h-5 w-5 flex-shrink-0" />
                      {!collapsed && <span>{item.title}</span>}
                      {!collapsed && isActive(item.url) && (
                        <ChevronRight className="ml-auto h-4 w-4" />
                      )}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter className="border-t p-4">
        {!collapsed && user && (
          <div className="mb-3 text-sm text-muted-foreground truncate">
            {user.email}
          </div>
        )}
        <Button 
          variant="outline" 
          size={collapsed ? "icon" : "default"}
          onClick={signOut}
          className="w-full"
        >
          <LogOut className="h-4 w-4" />
          {!collapsed && <span className="ml-2">Odjava</span>}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
