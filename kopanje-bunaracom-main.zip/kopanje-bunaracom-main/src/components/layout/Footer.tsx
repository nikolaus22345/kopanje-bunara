import { Link } from "react-router-dom";
import { Droplets, Phone, Mail, MapPin } from "lucide-react";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const services = [
  { name: "Kopanje bunara", href: "/usluge/kopanje-bunara" },
  { name: "Bušenje bunara", href: "/usluge/busenje-bunara" },
  { name: "Arteški bunari", href: "/usluge/arteski-bunari" },
  { name: "Čišćenje bunara", href: "/usluge/ciscenje-bunara" },
];

const locations = [
  { name: "Zagreb", href: "/lokacija/zagreb" },
  { name: "Split", href: "/lokacija/split" },
  { name: "Osijek", href: "/lokacija/osijek" },
  { name: "Slavonija", href: "/lokacija/slavonija" },
  { name: "Dalmacija", href: "/lokacija/dalmacija" },
  { name: "Istra", href: "/lokacija/istra" },
];

export function Footer() {
  const { settings } = useSiteSettings();
  
  // Format phone for tel: link (remove spaces)
  const phoneLink = settings.contactPhone.replace(/\s/g, '');

  return (
    <footer className="border-t border-border bg-muted/50">
      <div className="container py-12 md:py-16">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
                <Droplets className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="flex flex-col">
                <span className="text-lg font-bold text-foreground">{settings.siteName.replace('.hr', '')}</span>
                <span className="text-xs text-muted-foreground">.hr</span>
              </div>
            </Link>
            <p className="text-sm text-muted-foreground">
              {settings.siteDescription}
            </p>
          </div>

          {/* Services */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-foreground">
              Usluge
            </h3>
            <ul className="space-y-2">
              {services.map((item) => (
                <li key={item.name}>
                  <Link
                    to={item.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Locations */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-foreground">
              Lokacije
            </h3>
            <ul className="space-y-2">
              {locations.map((item) => (
                <li key={item.name}>
                  <Link
                    to={item.href}
                    className="text-sm text-muted-foreground transition-colors hover:text-primary"
                  >
                    {item.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 text-sm font-semibold uppercase tracking-wider text-foreground">
              Kontakt
            </h3>
            <ul className="space-y-3">
              <li>
                <a
                  href={`tel:${phoneLink}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                >
                  <Phone className="h-4 w-4" />
                  {settings.contactPhone}
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${settings.contactEmail}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
                >
                  <Mail className="h-4 w-4" />
                  {settings.contactEmail}
                </a>
              </li>
              <li>
                <div className="flex items-start gap-2 text-sm text-muted-foreground">
                  <MapPin className="mt-0.5 h-4 w-4 shrink-0" />
                  <span>{settings.contactAddress}</span>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Disclaimer */}
        <div className="mt-12 border-t border-border pt-6">
          <p className="text-xs text-muted-foreground text-center max-w-3xl mx-auto">
            Ova web stranica je marketinška platforma za povezivanje korisnika s neovisnim izvođačima. 
            Radove ne izvodimo niti sudjelujemo u naplati usluga. Svi dogovori i plaćanja odvijaju se 
            izravno između korisnika i izvođača.
          </p>
        </div>

        <div className="mt-6 border-t border-border pt-8">
          <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
            <p className="text-sm text-muted-foreground">
              © {new Date().getFullYear()} {settings.siteName}. Sva prava pridržana.
            </p>
            <div className="flex gap-6">
              <Link to="/politika-privatnosti" className="text-sm text-muted-foreground hover:text-primary">
                Privatnost
              </Link>
              <Link to="/uvjeti-koristenja" className="text-sm text-muted-foreground hover:text-primary">
                Uvjeti korištenja
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
