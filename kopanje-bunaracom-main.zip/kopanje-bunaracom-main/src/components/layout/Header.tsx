import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, Droplets } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSiteSettings } from "@/hooks/useSiteSettings";

const navigation = [
  { name: "Početna", href: "/" },
  { name: "Usluge", href: "/usluge" },
  { name: "Lokacije", href: "/lokacije" },
  { name: "Karta voda", href: "/karta-podzemnih-voda-hrvatska" },
  { name: "Blog", href: "/blog" },
  { name: "Kontakt", href: "/kontakt" },
];

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const location = useLocation();
  const { settings } = useSiteSettings();

  // Format phone for tel: link (remove spaces)
  const phoneLink = settings.contactPhone.replace(/\s/g, '');

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/95 backdrop-blur-md">
      <nav className="container flex h-16 items-center justify-between md:h-20">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary sm:h-10 sm:w-10">
            <Droplets className="h-5 w-5 text-primary-foreground sm:h-6 sm:w-6" />
          </div>
          <span className="whitespace-nowrap text-base font-bold text-foreground sm:text-lg">{settings.siteName}</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden items-center gap-1 md:flex">
          {navigation.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={`rounded-lg px-4 py-2 text-sm font-medium transition-colors ${
                location.pathname === item.href
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </div>

        {/* CTA Button */}
        <div className="hidden items-center gap-3 md:flex">
          <a href={`tel:${phoneLink}`} className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Phone className="h-4 w-4 text-primary" />
            {settings.contactPhone}
          </a>
          <Button variant="cta" size="sm" asChild>
            <Link to="/kontakt">Zatražite ponudu</Link>
          </Button>
        </div>

        {/* Mobile menu button */}
        <button
          type="button"
          className="rounded-lg p-2 text-foreground md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <div className="container space-y-1 py-4">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={`block rounded-lg px-4 py-3 text-base font-medium transition-colors ${
                  location.pathname === item.href
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
                onClick={() => setMobileMenuOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            <div className="pt-4">
              <a
                href={`tel:${phoneLink}`}
                className="flex items-center gap-2 px-4 py-2 text-base font-medium text-foreground"
              >
                <Phone className="h-5 w-5 text-primary" />
                {settings.contactPhone}
              </a>
              <div className="px-4 pt-2">
                <Button variant="cta" className="w-full" asChild>
                  <Link to="/kontakt" onClick={() => setMobileMenuOpen(false)}>
                    Zatražite ponudu
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
