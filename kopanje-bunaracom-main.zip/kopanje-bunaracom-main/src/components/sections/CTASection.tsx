import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Phone, ArrowRight } from "lucide-react";

export function CTASection() {
  return (
    <section className="bg-primary py-16 md:py-20">
      <div className="container">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl">
            Spremni ste za vlastiti bunar?
          </h2>
          <p className="mt-4 text-lg text-primary-foreground/80">
            Kontaktirajte nas danas za besplatnu procjenu i ponudu. 
            Naš tim stručnjaka je spreman pomoći vam osigurati pouzdani izvor vode.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button variant="hero" size="xl" asChild>
              <Link to="/kontakt">
                Zatražite ponudu
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button variant="heroOutline" size="xl" asChild>
              <a href="tel:+385976019558">
                <Phone className="mr-2 h-5 w-5" />
                +385 97 601 9558
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
