import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const locations = [
  { name: "Zagreb", slug: "zagreb", region: "Središnja Hrvatska" },
  { name: "Split", slug: "split", region: "Dalmacija" },
  { name: "Osijek", slug: "osijek", region: "Slavonija" },
  { name: "Rijeka", slug: "rijeka", region: "Primorje" },
  { name: "Zadar", slug: "zadar", region: "Dalmacija" },
  { name: "Pula", slug: "pula", region: "Istra" },
  { name: "Slavonski Brod", slug: "slavonski-brod", region: "Slavonija" },
  { name: "Karlovac", slug: "karlovac", region: "Središnja Hrvatska" },
  { name: "Varaždin", slug: "varazdin", region: "Sjeverozapadna Hrvatska" },
  { name: "Šibenik", slug: "sibenik", region: "Dalmacija" },
  { name: "Dubrovnik", slug: "dubrovnik", region: "Dalmacija" },
  { name: "Sisak", slug: "sisak", region: "Središnja Hrvatska" },
];

export function LocationsSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Područja rada
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Pružamo usluge kopanja i bušenja bunara na području cijele Hrvatske.
          </p>
        </div>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
          {locations.map((location) => (
            <Link
              key={location.slug}
              to={`/lokacija/${location.slug}`}
              className="group flex items-center justify-between rounded-lg border border-border bg-card p-4 shadow-soft transition-all duration-200 hover:border-primary/50 hover:shadow-medium"
            >
              <div>
                <h3 className="font-semibold text-foreground group-hover:text-primary">
                  {location.name}
                </h3>
                <p className="text-sm text-muted-foreground">{location.region}</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
            </Link>
          ))}
        </div>

        <div className="mt-8 text-center">
          <Link
            to="/lokacije"
            className="inline-flex items-center gap-2 text-primary hover:underline"
          >
            Pogledajte sve lokacije
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
