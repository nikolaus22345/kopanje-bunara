import { Droplets, Clock, Shield, Award, MapPin, Wrench } from "lucide-react";

const features = [
  {
    icon: Droplets,
    title: "Bušenje bunara za vodu",
    description: "Profesionalno bušenje bunara različitih dubina za osiguranje kvalitetne vode.",
  },
  {
    icon: Clock,
    title: "Brza izvedba",
    description: "Efikasan rad i minimalno vrijeme izvođenja radova na vašem imanju.",
  },
  {
    icon: Shield,
    title: "Kvaliteta i garancija",
    description: "Jamčimo kvalitetu izvedenih radova i pružamo tehničku podršku.",
  },
  {
    icon: Award,
    title: "Višegodišnje iskustvo",
    description: "Više od 15 godina iskustva u kopanju i bušenju bunara.",
  },
  {
    icon: MapPin,
    title: "Cijela Hrvatska",
    description: "Radimo na području cijele Hrvatske – od Slavonije do Dalmacije.",
  },
  {
    icon: Wrench,
    title: "Moderna oprema",
    description: "Koristimo suvremenu opremu za bušenje i kopanje bunara.",
  },
];

export function FeaturesSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Zašto odabrati nas?
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Pouzdani smo partner za sve vaše potrebe vezane uz kopanje i bušenje bunara.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group rounded-xl border border-border bg-card p-6 shadow-soft transition-all duration-300 hover:shadow-medium"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                {feature.title}
              </h3>
              <p className="mt-2 text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
