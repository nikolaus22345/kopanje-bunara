import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

interface FAQItem {
  question: string;
  answer: string;
}

interface FAQSectionProps {
  title?: string;
  description?: string;
  faqs: FAQItem[];
}

export function FAQSection({ 
  title = "Česta pitanja",
  description = "Odgovori na najčešća pitanja o kopanju i bušenju bunara.",
  faqs 
}: FAQSectionProps) {
  // Generate FAQ Schema
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            {title}
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            {description}
          </p>
        </div>

        <div className="mx-auto mt-12 max-w-3xl">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="rounded-lg border border-border bg-card px-6 shadow-soft"
              >
                <AccordionTrigger className="text-left font-semibold hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* FAQ Schema Script */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
        />
      </div>
    </section>
  );
}

// Default FAQs for the homepage
export const defaultFAQs: FAQItem[] = [
  {
    question: "Koliko košta kopanje bunara?",
    answer: "Cijena kopanja bunara ovisi o dubini, vrsti tla i lokaciji. Okvirne cijene kreću se od 500 do 3000 EUR za kopane bunare, dok bušeni bunari mogu koštati od 30 do 80 EUR po metru dubine. Kontaktirajte nas za besplatnu procjenu.",
  },
  {
    question: "Koja je razlika između kopanog i bušenog bunara?",
    answer: "Kopani bunari su šireg promjera (80-150cm), plići (do 15m) i pogodni za područja s visokom razinom podzemnih voda. Bušeni bunari su užeg promjera (15-30cm), mogu ići do 100m+ dubine i pogodniji su za veću količinu vode i dublje izvore.",
  },
  {
    question: "Treba li dozvola za kopanje bunara?",
    answer: "Za bunare do određene dubine i kapaciteta obično nije potrebna dozvola, već samo prijava. Za veće kapacitete i komercijalne namjene potrebna je vodopravna dozvola. Pomažemo vam s kompletnom dokumentacijom.",
  },
  {
    question: "Koliko vremena traje kopanje bunara?",
    answer: "Vrijeme izvedbe ovisi o metodi i dubini. Kopani bunar obično se završi u 2-5 dana, dok bušenje može trajati 1-3 dana, ovisno o uvjetima tla i željenoj dubini.",
  },
  {
    question: "Kako znati ima li vode na mojoj parceli?",
    answer: "Provodimo geološku procjenu terena i koristimo moderne metode za određivanje prisutnosti i dubine podzemnih voda. Dolazimo na lokaciju i procjenjujemo mogućnosti prije početka radova.",
  },
];
