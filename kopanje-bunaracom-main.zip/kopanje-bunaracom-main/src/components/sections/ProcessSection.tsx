import { Search, FileText, Drill, CheckCircle2 } from "lucide-react";

const steps = [
  {
    step: 1,
    icon: Search,
    title: "Procjena terena",
    description: "Dolazimo na lokaciju i procjenjujemo uvjete tla, dubinu podzemnih voda i optimalno mjesto za bunar.",
  },
  {
    step: 2,
    icon: FileText,
    title: "Ponuda i dogovor",
    description: "Pripremamo detaljnu ponudu s cijenom i rokom izvedbe. Dogovaramo termin početka radova.",
  },
  {
    step: 3,
    icon: Drill,
    title: "Izvođenje radova",
    description: "Profesionalno kopamo ili bušimo bunar prema dogovorenim specifikacijama i standardima.",
  },
  {
    step: 4,
    icon: CheckCircle2,
    title: "Završetak i primopredaja",
    description: "Testiramo bunar, provjeravamo kvalitetu vode i predajemo vam gotov projekt s uputama za održavanje.",
  },
];

export function ProcessSection() {
  return (
    <section className="bg-muted/50 py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Naš proces rada
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Jednostavan i transparentan proces od prvog kontakta do završenog bunara.
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((item, index) => (
            <div key={item.step} className="relative">
              {/* Connector line */}
              {index < steps.length - 1 && (
                <div className="absolute left-1/2 top-12 hidden h-0.5 w-full bg-border lg:block" />
              )}
              
              <div className="relative flex flex-col items-center text-center">
                <div className="relative z-10 flex h-24 w-24 items-center justify-center rounded-full bg-card shadow-medium">
                  <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary">
                    <item.icon className="h-8 w-8 text-primary-foreground" />
                  </div>
                  <span className="absolute -right-1 -top-1 flex h-8 w-8 items-center justify-center rounded-full bg-accent text-sm font-bold text-accent-foreground">
                    {item.step}
                  </span>
                </div>
                <h3 className="mt-6 text-lg font-semibold text-foreground">
                  {item.title}
                </h3>
                <p className="mt-2 text-muted-foreground">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
