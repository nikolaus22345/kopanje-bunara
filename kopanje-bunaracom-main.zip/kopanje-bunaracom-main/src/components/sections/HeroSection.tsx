import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Phone, CheckCircle, ArrowRight } from "lucide-react";
import heroImage from "@/assets/hero-drilling.jpg";

const benefits = [
  "Višegodišnje iskustvo",
  "Brza izvedba radova",
  "Rad na području cijele Hrvatske",
  "Besplatna procjena",
];

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary to-primary/90">
      {/* Background image with overlay */}
      <div className="absolute inset-0">
        <img 
          src={heroImage} 
          alt="Bušenje bunara za vodu" 
          className="h-full w-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-primary/80 to-primary/95" />
      </div>

      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg className="h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" className="text-white" />
        </svg>
      </div>

      {/* Water drops decoration */}
      <div className="absolute -right-20 -top-20 h-80 w-80 rounded-full bg-white/5 blur-3xl" />
      <div className="absolute -bottom-40 -left-20 h-96 w-96 rounded-full bg-white/5 blur-3xl" />

      <div className="container relative py-20 md:py-28 lg:py-36">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="animate-fade-up text-3xl font-bold tracking-tight text-white opacity-0 md:text-4xl lg:text-5xl xl:text-6xl">
            Kopanje i bušenje bunara u Hrvatskoj
            <span className="mt-2 block text-white/90">– pouzdano i profesionalno</span>
          </h1>

          <p className="stagger-1 animate-fade-up mx-auto mt-6 max-w-2xl text-lg text-white/80 opacity-0 md:text-xl">
            Osiguravamo vam pouzdan izvor vode uz višegodišnje iskustvo, 
            modernu opremu i stručan tim. Radimo na području cijele Hrvatske.
          </p>

          {/* Benefits */}
          <div className="stagger-2 animate-fade-up mt-8 flex flex-wrap items-center justify-center gap-4 opacity-0 md:gap-6">
            {benefits.map((benefit) => (
              <div key={benefit} className="flex items-center gap-2 text-sm text-white/90 md:text-base">
                <CheckCircle className="h-5 w-5 text-accent" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="stagger-3 animate-fade-up mt-10 flex flex-col items-center justify-center gap-4 opacity-0 sm:flex-row">
            <Button variant="hero" size="xl" asChild>
              <Link to="/kontakt">
                Zatražite ponudu
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button variant="heroOutline" size="xl" asChild>
              <a href="tel:+385976019558">
                <Phone className="mr-2 h-5 w-5" />
                +385 97 601 9558
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
