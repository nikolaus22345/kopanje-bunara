import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import wellTraditional from "@/assets/well-traditional.jpg";
import heroDrilling from "@/assets/hero-drilling.jpg";
import pumpSystem from "@/assets/pump-system.jpg";
import pipesInstallation from "@/assets/pipes-installation.jpg";

const services = [
  {
    title: "Kopanje bunara",
    description: "Tradicionalna metoda kopanja bunara pogodna za manje dubine i područja s visokom razinom podzemnih voda.",
    href: "/usluge/kopanje-bunara",
    features: ["Dubina do 15m", "Promjer 80-150cm", "Idealno za vrtove"],
    image: wellTraditional,
  },
  {
    title: "Bušenje bunara",
    description: "Moderna metoda bušenja za veće dubine i profesionalnu opskrbu vodom.",
    href: "/usluge/busenje-bunara",
    features: ["Dubina do 100m+", "Promjer 15-30cm", "Za sve namjene"],
    image: heroDrilling,
  },
  {
    title: "Arteški bunari",
    description: "Specijalizirano bušenje arteških bunara s prirodnim tlakom vode.",
    href: "/usluge/arteski-bunari",
    features: ["Prirodni tlak", "Visoka kvaliteta vode", "Dugotrajna rješenja"],
    image: pumpSystem,
  },
  {
    title: "Čišćenje i održavanje",
    description: "Redovito održavanje i čišćenje bunara za optimalnu funkcionalnost.",
    href: "/usluge/ciscenje-bunara",
    features: ["Dezinfekcija", "Ispiranje", "Servis pumpi"],
    image: pipesInstallation,
  },
];

export function ServicesSection() {
  return (
    <section className="bg-muted/50 py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl">
            Naše usluge
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Pružamo sve usluge vezane uz kopanje, bušenje i održavanje bunara.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2">
          {services.map((service) => (
            <div
              key={service.title}
              className="group flex flex-col overflow-hidden rounded-xl border border-border bg-card shadow-soft transition-all duration-300 hover:shadow-medium"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent" />
              </div>
              
              <div className="flex flex-1 flex-col p-6">
                <h3 className="text-xl font-semibold text-foreground">
                  {service.title}
                </h3>
                <p className="mt-2 text-muted-foreground">
                  {service.description}
                </p>
                <ul className="mt-4 space-y-2">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <div className="mt-auto pt-6">
                  <Button variant="outline" asChild>
                    <Link to={service.href}>
                      Saznajte više
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
