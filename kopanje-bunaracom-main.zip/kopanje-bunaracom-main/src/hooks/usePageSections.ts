import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface PageSection {
  id: string;
  page_key: string;
  section_key: string;
  title: string | null;
  subtitle: string | null;
  description: string | null;
  content: Record<string, any>;
  sort_order: number;
  is_visible: boolean;
}

export function usePageSections(pageKey: string) {
  const [sections, setSections] = useState<Record<string, PageSection>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    async function fetchSections() {
      try {
        setIsLoading(true);
        const { data, error } = await supabase
          .from('page_sections')
          .select('*')
          .eq('page_key', pageKey)
          .eq('is_visible', true)
          .order('sort_order');

        if (error) throw error;

        const sectionsMap: Record<string, PageSection> = {};
        (data || []).forEach((section: any) => {
          sectionsMap[section.section_key] = {
            ...section,
            content: section.content || {}
          };
        });
        setSections(sectionsMap);
      } catch (err) {
        setError(err as Error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchSections();
  }, [pageKey]);

  const getSection = (sectionKey: string): PageSection | null => {
    return sections[sectionKey] || null;
  };

  return { sections, getSection, isLoading, error };
}

export function useAllPageSections() {
  const [sections, setSections] = useState<PageSection[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const fetchSections = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('page_sections')
        .select('*')
        .order('page_key')
        .order('sort_order');

      if (error) throw error;
      setSections((data || []).map((s: any) => ({
        ...s,
        content: s.content || {}
      })));
    } catch (err) {
      setError(err as Error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSections();
  }, []);

  return { sections, isLoading, error, refetch: fetchSections };
}
