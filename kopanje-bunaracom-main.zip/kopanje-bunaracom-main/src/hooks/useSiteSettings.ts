import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface SiteSettings {
  siteName: string;
  siteDescription: string;
  contactEmail: string;
  contactPhone: string;
  contactAddress: string;
  socialLinks: {
    facebook?: string;
    instagram?: string;
    youtube?: string;
  };
}

const defaultSettings: SiteSettings = {
  siteName: 'KopanjeBunara.hr',
  siteDescription: 'Profesionalno kopanje i bušenje bunara na području cijele Hrvatske.',
  contactEmail: 'info@kopanjebunara.hr',
  contactPhone: '+385 97 601 9558',
  contactAddress: 'Radimo na području cijele Hrvatske',
  socialLinks: {},
};

export function useSiteSettings() {
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchSettings() {
      try {
        const { data, error } = await supabase
          .from('site_settings')
          .select('key, value');
        
        if (error) {
          console.error('Error fetching site settings:', error);
          return;
        }

        if (data) {
          const newSettings = { ...defaultSettings };
          
          data.forEach((setting) => {
            const value = setting.value;
            const stringValue = typeof value === 'string' 
              ? value.replace(/^"|"$/g, '') 
              : typeof value === 'object' && value !== null
                ? value
                : String(value);

            switch (setting.key) {
              case 'site_name':
                newSettings.siteName = typeof stringValue === 'string' ? stringValue : defaultSettings.siteName;
                break;
              case 'site_description':
                newSettings.siteDescription = typeof stringValue === 'string' ? stringValue : defaultSettings.siteDescription;
                break;
              case 'contact_email':
                newSettings.contactEmail = typeof stringValue === 'string' ? stringValue : defaultSettings.contactEmail;
                break;
              case 'contact_phone':
                newSettings.contactPhone = typeof stringValue === 'string' ? stringValue : defaultSettings.contactPhone;
                break;
              case 'contact_address':
                newSettings.contactAddress = typeof stringValue === 'string' ? stringValue : defaultSettings.contactAddress;
                break;
              case 'social_links':
                if (typeof value === 'object' && value !== null) {
                  newSettings.socialLinks = value as SiteSettings['socialLinks'];
                }
                break;
            }
          });
          
          setSettings(newSettings);
        }
      } catch (err) {
        console.error('Error in useSiteSettings:', err);
      } finally {
        setIsLoading(false);
      }
    }

    fetchSettings();
  }, []);

  return { settings, isLoading };
}
