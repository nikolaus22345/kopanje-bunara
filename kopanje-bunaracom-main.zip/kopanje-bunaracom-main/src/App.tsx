import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { HelmetProvider } from "react-helmet-async";
import { ScrollToTop } from "@/components/ScrollToTop";
import { AuthProvider } from "@/contexts/AuthContext";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ContactPage from "./pages/ContactPage";
import LocationPage from "./pages/LocationPage";
import LocationsPage from "./pages/LocationsPage";
import ServicesPage from "./pages/ServicesPage";
import ServiceDetailPage from "./pages/ServiceDetailPage";
import BlogPage from "./pages/BlogPage";
import DynamicBlogPostPage from "./pages/DynamicBlogPostPage";
import KartaPodzemneVodePage from "./pages/KartaPodzemneVodePage";
import CijenaBunaraPage from "./pages/blog/CijenaBunaraPage";
import RazlikaKopaniBuseniPage from "./pages/blog/RazlikaKopaniBuseniPage";
import DozvolaZaBunarPage from "./pages/blog/DozvolaZaBunarPage";
import DubinaBunaraPage from "./pages/blog/DubinaBunaraPage";
import BunarZaKucuPage from "./pages/blog/BunarZaKucuPage";
import DynamicPage from "./pages/DynamicPage";

// Admin pages
import AdminLoginPage from "./pages/admin/AdminLoginPage";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ChangePasswordPage from "./pages/admin/ChangePasswordPage";
import PostsListPage from "./pages/admin/PostsListPage";
import PostEditorPage from "./pages/admin/PostEditorPage";
import PagesListPage from "./pages/admin/PagesListPage";
import PageEditorPage from "./pages/admin/PageEditorPage";
import LocationsListPage from "./pages/admin/LocationsListPage";
import LocationEditorPage from "./pages/admin/LocationEditorPage";
import ServicesListPage from "./pages/admin/ServicesListPage";
import ServiceEditorPage from "./pages/admin/ServiceEditorPage";
import CategoriesPage from "./pages/admin/CategoriesPage";
import TagsPage from "./pages/admin/TagsPage";
import SettingsPage from "./pages/admin/SettingsPage";
import SectionsListPage from "./pages/admin/SectionsListPage";
import SectionEditorPage from "./pages/admin/SectionEditorPage";
import QuickEditPage from "./pages/admin/QuickEditPage";

const queryClient = new QueryClient();

const App = () => (
  <HelmetProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <ScrollToTop />
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/kontakt" element={<ContactPage />} />
              <Route path="/lokacije" element={<LocationsPage />} />
              <Route path="/usluge" element={<ServicesPage />} />
              <Route path="/usluge/:service" element={<ServiceDetailPage />} />
              <Route path="/blog" element={<BlogPage />} />
              <Route path="/blog/cijena-kopanja-bunara" element={<CijenaBunaraPage />} />
              <Route path="/blog/razlika-kopani-buseni-bunar" element={<RazlikaKopaniBuseniPage />} />
              <Route path="/blog/dozvola-za-bunar" element={<DozvolaZaBunarPage />} />
              <Route path="/blog/dubina-bunara" element={<DubinaBunaraPage />} />
              <Route path="/blog/bunar-za-kucu" element={<BunarZaKucuPage />} />
              <Route path="/blog/:slug" element={<DynamicBlogPostPage />} />
              <Route path="/lokacija/:location" element={<LocationPage />} />
              <Route path="/karta-podzemnih-voda-hrvatska" element={<KartaPodzemneVodePage />} />
              <Route path="/politika-privatnosti" element={<DynamicPage />} />
              <Route path="/uvjeti-koristenja" element={<DynamicPage />} />
              <Route path="/stranica/:slug" element={<DynamicPage />} />
              
              {/* Admin routes */}
              <Route path="/admin/login" element={<AdminLoginPage />} />
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/change-password" element={<ChangePasswordPage />} />
              <Route path="/admin/posts" element={<PostsListPage />} />
              <Route path="/admin/posts/:id" element={<PostEditorPage />} />
              <Route path="/admin/pages" element={<PagesListPage />} />
              <Route path="/admin/pages/:id" element={<PageEditorPage />} />
              <Route path="/admin/locations" element={<LocationsListPage />} />
              <Route path="/admin/locations/:id" element={<LocationEditorPage />} />
              <Route path="/admin/services" element={<ServicesListPage />} />
              <Route path="/admin/services/:id" element={<ServiceEditorPage />} />
              <Route path="/admin/categories" element={<CategoriesPage />} />
              <Route path="/admin/tags" element={<TagsPage />} />
              <Route path="/admin/settings" element={<SettingsPage />} />
              <Route path="/admin/sections" element={<SectionsListPage />} />
              <Route path="/admin/sections/:id" element={<SectionEditorPage />} />
              <Route path="/admin/quick-edit" element={<QuickEditPage />} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </HelmetProvider>
);

export default App;
