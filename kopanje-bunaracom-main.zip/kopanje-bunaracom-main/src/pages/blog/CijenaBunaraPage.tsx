import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { CTASection } from "@/components/sections/CTASection";
import { Calendar, Clock, ArrowLeft, CheckCircle } from "lucide-react";
import drillingImage from "@/assets/blog/drilling-machine.jpg";

export default function CijenaBunaraPage() {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Koliko košta kopanje bunara u Hrvatskoj 2024?",
    description: "Detaljan vodič o cijenama kopanja i bušenja bunara u Hrvatskoj. Saznajte što utječe na cijenu i kako planirati budžet.",
    datePublished: "2024-01-15",
    dateModified: "2024-12-01",
    author: {
      "@type": "Organization",
      name: "KopanjeBunara.hr",
    },
  };

  return (
    <Layout>
      <Helmet>
        <title>Koliko košta kopanje bunara u Hrvatskoj 2024? | Cijene i savjeti</title>
        <meta
          name="description"
          content="Saznajte koliko košta kopanje i bušenje bunara u Hrvatskoj. Detaljan pregled cijena po regijama, faktori koji utječu na cijenu i savjeti za uštedu."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog/cijena-kopanja-bunara" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <article className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            {/* Breadcrumb */}
            <Link
              to="/blog"
              className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"
            >
              <ArrowLeft className="h-4 w-4" />
              Natrag na blog
            </Link>

            {/* Header */}
            <header className="mb-10">
              <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
                Koliko košta kopanje bunara u Hrvatskoj 2024?
              </h1>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="h-4 w-4" />
                  15. siječnja 2024.
                </span>
                <span className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  8 min čitanja
                </span>
              </div>
              <img 
                src={drillingImage} 
                alt="Stroj za bušenje bunara u akciji" 
                className="mt-8 w-full rounded-xl object-cover shadow-medium"
              />
            </header>

            {/* Content */}
            <div className="prose prose-lg max-w-none">
              <p className="lead text-xl text-muted-foreground">
                Pitanje cijene bunara jedno je od prvih koje postavljaju vlasnici nekretnina koji razmišljaju o 
                vlastitom izvoru vode. U ovom članku donosimo detaljan pregled cijena kopanja i bušenja bunara 
                u Hrvatskoj za 2024. godinu.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Prosječne cijene kopanja bunara</h2>
              <p className="text-muted-foreground">
                Cijena kopanja bunara u Hrvatskoj kreće se od <strong>500 do 3.000 EUR</strong>, ovisno o 
                dubini, vrsti tla i lokaciji. Kopani bunari su tradicionalna metoda pogodna za područja 
                s plitkim podzemnim vodama.
              </p>

              <div className="my-8 overflow-hidden rounded-xl border border-border bg-card shadow-soft">
                <table className="w-full">
                  <thead className="bg-primary/5">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Dubina bunara</th>
                      <th className="px-4 py-3 text-left font-semibold">Okvirna cijena</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    <tr>
                      <td className="px-4 py-3">Do 5 metara</td>
                      <td className="px-4 py-3 text-accent">500 – 1.000 EUR</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3">5 – 10 metara</td>
                      <td className="px-4 py-3 text-accent">1.000 – 2.000 EUR</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3">10 – 15 metara</td>
                      <td className="px-4 py-3 text-accent">2.000 – 3.000 EUR</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Cijene bušenja bunara</h2>
              <p className="text-muted-foreground">
                Bušeni bunari naplaćuju se po metru dubine. Cijena se kreće od <strong>30 do 80 EUR po metru</strong>, 
                što za prosječni bunar od 30-50 metara iznosi 1.500-4.000 EUR.
              </p>

              <div className="my-8 rounded-xl border border-border bg-muted/30 p-6">
                <h3 className="mb-4 font-semibold text-foreground">Što je uključeno u cijenu bušenja?</h3>
                <ul className="space-y-2">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span>Bušenje do potrebne dubine</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span>Ugradnja PVC cijevi (obloge)</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span>Filter i šljunak oko cijevi</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span>Testiranje izdašnosti bunara</span>
                  </li>
                </ul>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Faktori koji utječu na cijenu</h2>
              
              <h3 className="mt-6 text-xl font-semibold text-foreground">1. Vrsta tla</h3>
              <p className="text-muted-foreground">
                Mekano tlo (pijesak, šljunak) jeftinije je za bušenje od tvrdog kamena ili krša. 
                U Slavoniji su cijene niže zbog povoljnijeg tla, dok su u Dalmaciji i Istri više 
                zbog krškog terena.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">2. Dubina podzemne vode</h3>
              <p className="text-muted-foreground">
                Što je voda dublje, bunar je skuplji. U nizinskim područjima voda je često na 5-15 m, 
                dok u brdskim područjima može biti i preko 50 m.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">3. Pristup lokaciji</h3>
              <p className="text-muted-foreground">
                Teško dostupne lokacije zahtijevaju dodatnu opremu ili ručni rad, što povećava cijenu 
                za 20-50%.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">4. Dodatna oprema</h3>
              <p className="text-muted-foreground">
                Pumpa, hidrofor i instalacija nisu uvijek uključeni u osnovnu cijenu. Računajte na 
                dodatnih 300-1.500 EUR za kompletnu instalaciju.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Cijene po regijama</h2>
              
              <div className="my-8 grid gap-4 md:grid-cols-2">
                <div className="rounded-xl border border-border bg-card p-5">
                  <h4 className="font-semibold text-foreground">Slavonija</h4>
                  <p className="mt-2 text-2xl font-bold text-accent">25-50 EUR/m</p>
                  <p className="mt-1 text-sm text-muted-foreground">Najpovoljnije cijene, plitka voda</p>
                </div>
                <div className="rounded-xl border border-border bg-card p-5">
                  <h4 className="font-semibold text-foreground">Središnja Hrvatska</h4>
                  <p className="mt-2 text-2xl font-bold text-accent">35-60 EUR/m</p>
                  <p className="mt-1 text-sm text-muted-foreground">Umjerene cijene i dubine</p>
                </div>
                <div className="rounded-xl border border-border bg-card p-5">
                  <h4 className="font-semibold text-foreground">Istra i Primorje</h4>
                  <p className="mt-2 text-2xl font-bold text-accent">50-80 EUR/m</p>
                  <p className="mt-1 text-sm text-muted-foreground">Krško tlo, veće dubine</p>
                </div>
                <div className="rounded-xl border border-border bg-card p-5">
                  <h4 className="font-semibold text-foreground">Dalmacija</h4>
                  <p className="mt-2 text-2xl font-bold text-accent">50-80 EUR/m</p>
                  <p className="mt-1 text-sm text-muted-foreground">Nepredvidiv krš, veći rizik</p>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kako uštedjeti na izradi bunara?</h2>
              <ol className="mt-4 list-decimal space-y-3 pl-6 text-muted-foreground">
                <li><strong>Zatražite više ponuda</strong> – usporedite najmanje 3 izvođača</li>
                <li><strong>Bušite u pravo vrijeme</strong> – jesen i zima često imaju niže cijene</li>
                <li><strong>Kombinirajte s susjedima</strong> – zajednička narudžba može sniziti cijenu</li>
                <li><strong>Pripremite pristup</strong> – osigurajte nesmetan pristup strojevima</li>
                <li><strong>Razmotrite kopani bunar</strong> – za plitku vodu može biti jeftiniji</li>
              </ol>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Isplati li se bunar?</h2>
              <p className="text-muted-foreground">
                Prosječna hrvatska obitelj troši 150-300 EUR godišnje na vodu. Bunar se isplati za 
                5-15 godina, ovisno o investiciji i potrošnji. Za navodnjavanje vrta ili poljoprivredu, 
                isplativost je još brža.
              </p>

              <div className="my-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
                <p className="text-lg font-semibold text-foreground">
                  Želite točnu procjenu za vašu lokaciju?
                </p>
                <p className="mt-2 text-muted-foreground">
                  Kontaktirajte nas za besplatnu procjenu i ponudu prilagođenu vašim potrebama.
                </p>
                <Button asChild variant="cta" className="mt-4">
                  <Link to="/kontakt">Zatražite besplatnu ponudu</Link>
                </Button>
              </div>
            </div>

            {/* Related links */}
            <div className="mt-12 border-t border-border pt-8">
              <h3 className="font-semibold text-foreground">Povezani članci</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Link
                  to="/blog/razlika-kopani-buseni-bunar"
                  className="rounded-lg border border-border p-4 hover:border-primary"
                >
                  Razlika između kopanog i bušenog bunara →
                </Link>
                <Link
                  to="/blog/dozvola-za-bunar"
                  className="rounded-lg border border-border p-4 hover:border-primary"
                >
                  Treba li dozvola za kopanje bunara? →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}
