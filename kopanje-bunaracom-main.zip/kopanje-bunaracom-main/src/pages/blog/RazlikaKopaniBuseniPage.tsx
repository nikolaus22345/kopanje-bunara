import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, CheckCircle, X } from "lucide-react";
import comparisonImage from "@/assets/blog/well-comparison.jpg";

export default function RazlikaKopaniBuseniPage() {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Razlika između kopanog i bušenog bunara",
    description: "Saznajte koje su prednosti i nedostaci kopanog i bušenog bunara te koji je bolji izbor za vašu situaciju.",
    datePublished: "2024-02-10",
    dateModified: "2024-11-15",
    author: { "@type": "Organization", name: "KopanjeBunara.hr" },
  };

  return (
    <Layout>
      <Helmet>
        <title>Razlika između kopanog i bušenog bunara | Koji odabrati?</title>
        <meta
          name="description"
          content="Kopani ili bušeni bunar? Saznajte prednosti i nedostatke obje metode, cijene, dubine i koji tip je bolji za vašu lokaciju."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog/razlika-kopani-buseni-bunar" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <article className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <Link to="/blog" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
              <ArrowLeft className="h-4 w-4" />
              Natrag na blog
            </Link>

            <header className="mb-10">
              <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
                Razlika između kopanog i bušenog bunara
              </h1>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />10. veljače 2024.</span>
                <span className="flex items-center gap-1"><Clock className="h-4 w-4" />6 min čitanja</span>
              </div>
              <img 
                src={comparisonImage} 
                alt="Usporedba kopanog i bušenog bunara" 
                className="mt-8 w-full rounded-xl object-cover shadow-medium"
              />
            </header>

            <div className="prose prose-lg max-w-none">
              <p className="lead text-xl text-muted-foreground">
                Jedna od prvih odluka pri izradi bunara je odabir između kopanja i bušenja. 
                Obje metode imaju svoje prednosti i nedostatke, a pravi izbor ovisi o vašoj lokaciji, 
                potrebama i budžetu.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kopani bunar – tradicionalna metoda</h2>
              <p className="text-muted-foreground">
                Kopani bunari izrađuju se ručno ili strojem, s promjerom od 80 do 150 cm. 
                Tradicionalna su metoda koja se koristi tisućama godina i još uvijek je popularna 
                u područjima s plitkim podzemnim vodama.
              </p>

              <div className="my-8 grid gap-6 md:grid-cols-2">
                <div className="rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <h3 className="flex items-center gap-2 font-semibold text-green-800 dark:text-green-200">
                    <CheckCircle className="h-5 w-5" /> Prednosti
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-green-700 dark:text-green-300">
                    <li>• Veći kapacitet vode (veći promjer)</li>
                    <li>• Jednostavnije čišćenje i održavanje</li>
                    <li>• Mogućnost vizualne inspekcije</li>
                    <li>• Niža cijena za plitke bunare</li>
                    <li>• Stabilnija razina vode</li>
                  </ul>
                </div>
                <div className="rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <h3 className="flex items-center gap-2 font-semibold text-red-800 dark:text-red-200">
                    <X className="h-5 w-5" /> Nedostaci
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-red-700 dark:text-red-300">
                    <li>• Ograničena dubina (do 15-20 m)</li>
                    <li>• Veći rizik od onečišćenja</li>
                    <li>• Duže vrijeme izrade</li>
                    <li>• Potrebno više prostora</li>
                    <li>• Moguće urušavanje bez obloge</li>
                  </ul>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Bušeni bunar – moderna metoda</h2>
              <p className="text-muted-foreground">
                Bušeni bunari izrađuju se specijalnim strojevima koji buše uski otvor promjera 
                15-30 cm do velikih dubina. Ova metoda omogućuje pristup dubljim vodonosnim slojevima.
              </p>

              <div className="my-8 grid gap-6 md:grid-cols-2">
                <div className="rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <h3 className="flex items-center gap-2 font-semibold text-green-800 dark:text-green-200">
                    <CheckCircle className="h-5 w-5" /> Prednosti
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-green-700 dark:text-green-300">
                    <li>• Velike dubine (do 150+ m)</li>
                    <li>• Čistija voda iz dubljih slojeva</li>
                    <li>• Manja mogućnost onečišćenja</li>
                    <li>• Brža izrada (1-3 dana)</li>
                    <li>• Manji prostor za izvedbu</li>
                  </ul>
                </div>
                <div className="rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <h3 className="flex items-center gap-2 font-semibold text-red-800 dark:text-red-200">
                    <X className="h-5 w-5" /> Nedostaci
                  </h3>
                  <ul className="mt-3 space-y-2 text-sm text-red-700 dark:text-red-300">
                    <li>• Viša cijena po metru</li>
                    <li>• Manji kapacitet (uži promjer)</li>
                    <li>• Potrebna pumpa</li>
                    <li>• Teže održavanje</li>
                    <li>• Ovisnost o električnoj energiji</li>
                  </ul>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Usporedba u brojkama</h2>
              
              <div className="my-8 overflow-hidden rounded-xl border border-border bg-card shadow-soft">
                <table className="w-full">
                  <thead className="bg-primary/5">
                    <tr>
                      <th className="px-4 py-3 text-left font-semibold">Karakteristika</th>
                      <th className="px-4 py-3 text-left font-semibold">Kopani</th>
                      <th className="px-4 py-3 text-left font-semibold">Bušeni</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    <tr>
                      <td className="px-4 py-3 font-medium">Promjer</td>
                      <td className="px-4 py-3">80-150 cm</td>
                      <td className="px-4 py-3">15-30 cm</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3 font-medium">Maksimalna dubina</td>
                      <td className="px-4 py-3">15-20 m</td>
                      <td className="px-4 py-3">150+ m</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3 font-medium">Vrijeme izrade</td>
                      <td className="px-4 py-3">3-7 dana</td>
                      <td className="px-4 py-3">1-3 dana</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3 font-medium">Cijena (prosječno)</td>
                      <td className="px-4 py-3">500-3.000 €</td>
                      <td className="px-4 py-3">1.500-5.000 €</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-3 font-medium">Potrebna pumpa</td>
                      <td className="px-4 py-3">Opcionalno</td>
                      <td className="px-4 py-3">Obavezno</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Koji bunar odabrati?</h2>
              
              <h3 className="mt-6 text-xl font-semibold text-foreground">Odaberite kopani bunar ako:</h3>
              <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Podzemna voda je plitka (do 10-15 m)</li>
                <li>Trebate veće količine vode</li>
                <li>Želite jednostavnije održavanje</li>
                <li>Imate ograničen budžet za plitku vodu</li>
                <li>Nalazite se u Slavoniji ili nizinskim područjima</li>
              </ul>

              <h3 className="mt-6 text-xl font-semibold text-foreground">Odaberite bušeni bunar ako:</h3>
              <ul className="mt-3 list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Podzemna voda je duboka (preko 15 m)</li>
                <li>Želite čistiju vodu iz dubljih slojeva</li>
                <li>Imate ograničen prostor</li>
                <li>Nalazite se u Dalmaciji, Istri ili brdskim područjima</li>
                <li>Prioritet vam je kvaliteta vode</li>
              </ul>

              <div className="my-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
                <p className="text-lg font-semibold text-foreground">Niste sigurni koji tip je pravi za vas?</p>
                <p className="mt-2 text-muted-foreground">
                  Naši stručnjaci mogu procijeniti vašu lokaciju i preporučiti optimalno rješenje.
                </p>
                <Button asChild variant="cta" className="mt-4">
                  <Link to="/kontakt">Zatražite besplatnu procjenu</Link>
                </Button>
              </div>
            </div>

            <div className="mt-12 border-t border-border pt-8">
              <h3 className="font-semibold text-foreground">Povezani članci</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Link to="/blog/cijena-kopanja-bunara" className="rounded-lg border border-border p-4 hover:border-primary">
                  Koliko košta kopanje bunara? →
                </Link>
                <Link to="/blog/dubina-bunara" className="rounded-lg border border-border p-4 hover:border-primary">
                  Kolika je idealna dubina bunara? →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}
