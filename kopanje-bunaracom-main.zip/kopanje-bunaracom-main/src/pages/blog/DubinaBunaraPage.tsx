import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, Droplets } from "lucide-react";
import depthImage from "@/assets/blog/water-depth.jpg";

export default function DubinaBunaraPage() {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Kolika je idealna dubina bunara?",
    description: "Saznajte kako odrediti optimalnu dubinu bunara za vašu lokaciju i potrebe.",
    datePublished: "2024-04-12",
    dateModified: "2024-11-10",
    author: { "@type": "Organization", name: "KopanjeBunara.hr" },
  };

  return (
    <Layout>
      <Helmet>
        <title>Kolika je idealna dubina bunara? | Vodič po regijama</title>
        <meta
          name="description"
          content="Kako odrediti idealnu dubinu bunara? Pregled prosječnih dubina po regijama Hrvatske i faktori koji utječu na odluku."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog/dubina-bunara" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <article className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <Link to="/blog" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
              <ArrowLeft className="h-4 w-4" />
              Natrag na blog
            </Link>

            <header className="mb-10">
              <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
                Kolika je idealna dubina bunara?
              </h1>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />12. travnja 2024.</span>
                <span className="flex items-center gap-1"><Clock className="h-4 w-4" />6 min čitanja</span>
              </div>
              <img 
                src={depthImage} 
                alt="Presjek tla s podzemnim vodama" 
                className="mt-8 w-full rounded-xl object-cover shadow-medium"
              />
            </header>

            <div className="prose prose-lg max-w-none">
              <p className="lead text-xl text-muted-foreground">
                Dubina bunara jedan je od ključnih faktora koji određuje kvalitetu i količinu vode, 
                ali i ukupnu cijenu izrade. Idealna dubina ovisi o više faktora – od lokacije do namjene.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Zašto je dubina važna?</h2>
              <p className="text-muted-foreground">
                Dubina bunara direktno utječe na:
              </p>
              <ul className="list-disc space-y-2 pl-6 text-muted-foreground">
                <li><strong>Kvalitetu vode</strong> – dublja voda je često čistija jer je filtrirana kroz više slojeva tla</li>
                <li><strong>Količinu vode</strong> – dublji vodonosni slojevi često imaju veći kapacitet</li>
                <li><strong>Stabilnost opskrbe</strong> – plitki bunari mogu presušiti ljeti</li>
                <li><strong>Cijenu izrade</strong> – svaki dodatni metar povećava trošak</li>
              </ul>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Prosječne dubine po regijama</h2>
              
              <div className="my-8 space-y-4">
                <div className="rounded-xl border border-border bg-card p-5">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-8 w-8 text-accent" />
                    <div>
                      <h3 className="font-semibold text-foreground">Slavonija i Baranja</h3>
                      <p className="text-2xl font-bold text-accent">5 – 20 metara</p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Ravničarski teren s visokom razinom podzemnih voda. Idealno za kopane bunare. 
                    Voda je često već na 5-8 metara dubine, ali preporučuje se ići dublje za stabilniju opskrbu.
                  </p>
                </div>

                <div className="rounded-xl border border-border bg-card p-5">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-8 w-8 text-accent" />
                    <div>
                      <h3 className="font-semibold text-foreground">Središnja Hrvatska (Zagreb, Varaždin)</h3>
                      <p className="text-2xl font-bold text-accent">10 – 40 metara</p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Varijabilni uvjeti ovisno o mikrolokaciji. Bliže rijekama voda je plića, 
                    dok brdska područja zahtijevaju dublje bušenje.
                  </p>
                </div>

                <div className="rounded-xl border border-border bg-card p-5">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-8 w-8 text-primary" />
                    <div>
                      <h3 className="font-semibold text-foreground">Istra i Primorje</h3>
                      <p className="text-2xl font-bold text-primary">30 – 100 metara</p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Krško i polukarško tlo s nepredvidivim vodonosnicima. Dubine značajno variraju 
                    čak i na malim udaljenostima. Potrebno stručno istraživanje terena.
                  </p>
                </div>

                <div className="rounded-xl border border-border bg-card p-5">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-8 w-8 text-primary" />
                    <div>
                      <h3 className="font-semibold text-foreground">Dalmacija</h3>
                      <p className="text-2xl font-bold text-primary">40 – 150+ metara</p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Tipični krški teren s dubokim i nepredvidivim izvorima. Bušenje može biti izazovno, 
                    ali duboka voda je obično izuzetne kvalitete.
                  </p>
                </div>

                <div className="rounded-xl border border-border bg-card p-5">
                  <div className="flex items-center gap-3">
                    <Droplets className="h-8 w-8 text-destructive" />
                    <div>
                      <h3 className="font-semibold text-foreground">Otoci</h3>
                      <p className="text-2xl font-bold text-destructive">80 – 200+ metara</p>
                    </div>
                  </div>
                  <p className="mt-3 text-sm text-muted-foreground">
                    Najzahtjevniji uvjeti. Slatka voda je rijetka i duboka, često s rizikom prodora 
                    morske vode. Potrebno pažljivo planiranje i stručna izvedba.
                  </p>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kako odrediti pravu dubinu?</h2>
              
              <h3 className="mt-6 text-xl font-semibold text-foreground">1. Konzultirajte lokalne stručnjake</h3>
              <p className="text-muted-foreground">
                Iskusni bušači poznaju uvjete u vašem području. Pitajte za reference prethodnih radova 
                u blizini vaše parcele.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">2. Provjerite susjedne bunare</h3>
              <p className="text-muted-foreground">
                Ako susjedi imaju bunare, njihova dubina može biti dobar pokazatelj. No, imajte na umu 
                da dubina može varirati i na malim udaljenostima.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">3. Razmislite o namjeni</h3>
              <p className="text-muted-foreground">
                Za zalijevanje vrta može biti dovoljan plići bunar, dok za pitku vodu ili veće potrebe 
                preporučuje se dublje bušenje za kvalitetniju i stabilniju opskrbu.
              </p>

              <h3 className="mt-6 text-xl font-semibold text-foreground">4. Budžetirajte rezervu</h3>
              <p className="text-muted-foreground">
                Uvijek planirajte budžet za 20-30% veću dubinu od očekivane. Bolje je biti pripremljen 
                nego prekinuti radove zbog nedostatka sredstava.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Preporuka: koliko duboko bušiti?</h2>
              <p className="text-muted-foreground">
                Općenito pravilo: <strong>bušite barem 5-10 metara dublje</strong> od prve pojave vode. 
                Ovo osigurava:
              </p>
              <ul className="list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Stabilniju razinu vode tijekom cijele godine</li>
                <li>Veći kapacitet crpljenja</li>
                <li>Bolju kvalitetu vode</li>
                <li>Zaštitu od sezonskih oscilacija</li>
              </ul>

              <div className="my-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
                <p className="text-lg font-semibold text-foreground">Želite saznati dubinu vode na vašoj lokaciji?</p>
                <p className="mt-2 text-muted-foreground">
                  Dolazimo na teren i procjenjujemo uvjete prije početka radova – besplatno.
                </p>
                <Button asChild variant="cta" className="mt-4">
                  <Link to="/kontakt">Zatražite procjenu</Link>
                </Button>
              </div>
            </div>

            <div className="mt-12 border-t border-border pt-8">
              <h3 className="font-semibold text-foreground">Povezani članci</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Link to="/blog/razlika-kopani-buseni-bunar" className="rounded-lg border border-border p-4 hover:border-primary">
                  Razlika između kopanog i bušenog bunara →
                </Link>
                <Link to="/karta-podzemnih-voda-hrvatska" className="rounded-lg border border-border p-4 hover:border-primary">
                  Karta podzemnih voda u Hrvatskoj →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}
