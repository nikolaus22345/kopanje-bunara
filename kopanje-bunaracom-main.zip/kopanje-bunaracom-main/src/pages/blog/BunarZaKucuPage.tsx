import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, CheckCircle, X, Calculator } from "lucide-react";
import houseImage from "@/assets/blog/house-with-well.jpg";

export default function BunarZaKucuPage() {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Bunar za kuću – prednosti i nedostaci",
    description: "Isplati li se imati vlastiti bunar? Saznajte sve prednosti i nedostatke bunara za kućanstvo.",
    datePublished: "2024-05-20",
    dateModified: "2024-11-25",
    author: { "@type": "Organization", name: "KopanjeBunara.hr" },
  };

  return (
    <Layout>
      <Helmet>
        <title>Bunar za kuću – prednosti i nedostaci | Isplati li se?</title>
        <meta
          name="description"
          content="Razmišljate o vlastitom bunaru? Saznajte prednosti i nedostatke bunara za kuću, koliko se isplati i što trebate znati prije kopanja."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog/bunar-za-kucu" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
      </Helmet>

      <article className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <Link to="/blog" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
              <ArrowLeft className="h-4 w-4" />
              Natrag na blog
            </Link>

            <header className="mb-10">
              <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
                Bunar za kuću – prednosti i nedostaci
              </h1>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />20. svibnja 2024.</span>
                <span className="flex items-center gap-1"><Clock className="h-4 w-4" />7 min čitanja</span>
              </div>
              <img 
                src={houseImage} 
                alt="Obiteljska kuća s bunarom u dvorištu" 
                className="mt-8 w-full rounded-xl object-cover shadow-medium"
              />
            </header>

            <div className="prose prose-lg max-w-none">
              <p className="lead text-xl text-muted-foreground">
                Sve više kućanstava u Hrvatskoj razmišlja o vlastitom bunaru kao alternativi ili 
                dopuni javnom vodovodu. Je li bunar pravo rješenje za vas? Analiziramo sve prednosti 
                i nedostatke.
              </p>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Prednosti bunara za kuću</h2>
              
              <div className="my-8 space-y-4">
                <div className="flex gap-4 rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <CheckCircle className="mt-1 h-6 w-6 shrink-0 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">Ušteda na računima za vodu</h3>
                    <p className="mt-1 text-sm text-green-700 dark:text-green-300">
                      Prosječno kućanstvo troši 150-300 EUR godišnje na vodu. S bunarom, jedini trošak 
                      je električna energija za pumpu (20-50 EUR godišnje).
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <CheckCircle className="mt-1 h-6 w-6 shrink-0 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">Neovisnost o javnoj mreži</h3>
                    <p className="mt-1 text-sm text-green-700 dark:text-green-300">
                      Nestanci vode, redukcije i kvarovi na mreži vas ne pogađaju. Imate vlastiti 
                      izvor vode 24/7, što je posebno vrijedno za vikendice i ruralna područja.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <CheckCircle className="mt-1 h-6 w-6 shrink-0 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">Neograničeno zalijevanje</h3>
                    <p className="mt-1 text-sm text-green-700 dark:text-green-300">
                      Zalijevajte vrt, napunite bazen, perite auto – bez brige o računima. 
                      Posebno vrijedno ljeti kada su cijene vode više.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <CheckCircle className="mt-1 h-6 w-6 shrink-0 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">Prirodna, meka voda</h3>
                    <p className="mt-1 text-sm text-green-700 dark:text-green-300">
                      Bunarska voda je često mekša od gradske, bez klora i drugih kemikalija. 
                      Bolja je za biljke, kožu i kućanske aparate.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-green-200 bg-green-50 p-5 dark:border-green-900 dark:bg-green-950/30">
                  <CheckCircle className="mt-1 h-6 w-6 shrink-0 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-green-800 dark:text-green-200">Povećanje vrijednosti nekretnine</h3>
                    <p className="mt-1 text-sm text-green-700 dark:text-green-300">
                      Funkcionalan bunar povećava atraktivnost i vrijednost nekretnine, 
                      posebno u ruralnim područjima.
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Nedostaci bunara za kuću</h2>
              
              <div className="my-8 space-y-4">
                <div className="flex gap-4 rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <X className="mt-1 h-6 w-6 shrink-0 text-red-600" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">Početna investicija</h3>
                    <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                      Izrada bunara košta 1.000-5.000 EUR, ovisno o dubini i metodi. 
                      Povrat investicije traje 5-15 godina.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <X className="mt-1 h-6 w-6 shrink-0 text-red-600" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">Ovisnost o električnoj energiji</h3>
                    <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                      Bušeni bunari zahtijevaju pumpu koja radi na struju. 
                      Nestanak struje = nestanak vode (osim ako imate generator ili kopani bunar).
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <X className="mt-1 h-6 w-6 shrink-0 text-red-600" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">Potreba za testiranjem kvalitete</h3>
                    <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                      Za piće i kuhanje potrebna je analiza vode. Povremeno testiranje košta 50-150 EUR.
                      Voda može zahtijevati filtraciju.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <X className="mt-1 h-6 w-6 shrink-0 text-red-600" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">Nema garancije za vodu</h3>
                    <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                      Na nekim lokacijama možda nema dovoljno vode ili je preskupa za dosegnuti. 
                      Postoji određeni rizik pri investiciji.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-xl border border-red-200 bg-red-50 p-5 dark:border-red-900 dark:bg-red-950/30">
                  <X className="mt-1 h-6 w-6 shrink-0 text-red-600" />
                  <div>
                    <h3 className="font-semibold text-red-800 dark:text-red-200">Održavanje</h3>
                    <p className="mt-1 text-sm text-red-700 dark:text-red-300">
                      Pumpe imaju ograničen vijek trajanja (10-15 godina). 
                      Povremeno čišćenje i servisi su potrebni za optimalan rad.
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kalkulacija isplativosti</h2>
              
              <div className="my-8 rounded-xl border border-border bg-card p-6 shadow-soft">
                <div className="flex items-center gap-3">
                  <Calculator className="h-8 w-8 text-primary" />
                  <h3 className="text-xl font-semibold text-foreground">Primjer izračuna</h3>
                </div>
                
                <div className="mt-6 space-y-4">
                  <div className="flex justify-between border-b border-border pb-2">
                    <span className="text-muted-foreground">Cijena bunara (prosječno)</span>
                    <span className="font-semibold">2.500 EUR</span>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <span className="text-muted-foreground">Godišnja ušteda na vodi</span>
                    <span className="font-semibold text-green-600">200 EUR</span>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <span className="text-muted-foreground">Godišnji trošak struje za pumpu</span>
                    <span className="font-semibold text-red-600">-40 EUR</span>
                  </div>
                  <div className="flex justify-between border-b border-border pb-2">
                    <span className="text-muted-foreground">Neto godišnja ušteda</span>
                    <span className="font-semibold text-accent">160 EUR</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="font-semibold text-foreground">Povrat investicije</span>
                    <span className="text-xl font-bold text-primary">~15 godina</span>
                  </div>
                </div>
                
                <p className="mt-4 text-sm text-muted-foreground">
                  * Za kućanstva s većom potrošnjom (bazen, veliki vrt, poljoprivreda) povrat može biti i za 5-7 godina.
                </p>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Za koga se bunar najviše isplati?</h2>
              
              <ul className="mt-4 list-disc space-y-3 pl-6 text-muted-foreground">
                <li><strong>Vlasnici velikih vrtova</strong> – ušteda na zalijevanju je značajna</li>
                <li><strong>Vlasnici bazena</strong> – punjenje bazena vodom iz bunara je besplatno</li>
                <li><strong>Ruralna kućanstva</strong> – često nemaju pristup javnom vodovodu</li>
                <li><strong>Vikendice</strong> – neovisnost o infrastrukturi</li>
                <li><strong>Mali poljoprivrednici</strong> – navodnjavanje bez velikih troškova</li>
                <li><strong>Područja s čestim nestancima vode</strong> – sigurnost opskrbe</li>
              </ul>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Naša preporuka</h2>
              <p className="text-muted-foreground">
                Bunar se najčešće isplati kao <strong>dopuna javnom vodovodu</strong>, a ne kao potpuna zamjena. 
                Koristite bunarski vodu za vrt, pranje, wc i slično, a gradsku za piće i kuhanje. 
                Tako dobivate najbolje od oba svijeta – uštedu i sigurnost.
              </p>

              <div className="my-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
                <p className="text-lg font-semibold text-foreground">Želite saznati isplati li se bunar na vašoj lokaciji?</p>
                <p className="mt-2 text-muted-foreground">
                  Besplatno procjenjujemo mogućnosti i očekivanu dubinu na vašoj parceli.
                </p>
                <Button asChild variant="cta" className="mt-4">
                  <Link to="/kontakt">Zatražite besplatnu procjenu</Link>
                </Button>
              </div>
            </div>

            <div className="mt-12 border-t border-border pt-8">
              <h3 className="font-semibold text-foreground">Povezani članci</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Link to="/blog/cijena-kopanja-bunara" className="rounded-lg border border-border p-4 hover:border-primary">
                  Koliko košta kopanje bunara? →
                </Link>
                <Link to="/blog/dozvola-za-bunar" className="rounded-lg border border-border p-4 hover:border-primary">
                  Treba li dozvola za kopanje bunara? →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}
