import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowLeft, FileText, AlertTriangle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import permitsImage from "@/assets/blog/permits-documents.jpg";

const faqs = [
  {
    question: "Koliko košta vodopravna dozvola?",
    answer: "Administrativna pristojba za vodopravnu dozvolu iznosi oko 70-150 EUR, ovisno o vrsti zahvata. Dodatni troškovi mogu uključivati izradu projekta i elaborata.",
  },
  {
    question: "Koliko traje postupak dobivanja dozvole?",
    answer: "Jednostavna prijava može se riješiti u roku od 15-30 dana. Za vodopravnu dozvolu postupak može trajati 2-3 mjeseca, ovisno o složenosti i potrebnim studijama.",
  },
  {
    question: "Mogu li bušiti bunar bez dozvole?",
    answer: "Za bunare s malim kapacitetom (do 10 m³/dan) za vlastite potrebe najčešće je dovoljna prijava. Za veće kapacitete ili komercijalne namjene potrebna je dozvola.",
  },
  {
    question: "Što ako bunar bušim bez prijave?",
    answer: "Nelegalni bunari mogu rezultirati kaznama od 500 do 5.000 EUR za fizičke osobe. Dodatno, možete biti obvezani zatvoriti bunar o vlastitom trošku.",
  },
];

export default function DozvolaZaBunarPage() {
  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: "Treba li dozvola za kopanje bunara u Hrvatskoj?",
    description: "Sve što trebate znati o dozvolama i prijavama za kopanje i bušenje bunara u Hrvatskoj.",
    datePublished: "2024-03-05",
    dateModified: "2024-11-20",
    author: { "@type": "Organization", name: "KopanjeBunara.hr" },
  };

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: { "@type": "Answer", text: faq.answer },
    })),
  };

  return (
    <Layout>
      <Helmet>
        <title>Treba li dozvola za kopanje bunara? | Zakonski zahtjevi 2024</title>
        <meta
          name="description"
          content="Saznajte kada je potrebna dozvola za kopanje ili bušenje bunara u Hrvatskoj. Vodič kroz zakonske zahtjeve, prijave i vodopravne dozvole."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog/dozvola-za-bunar" />
        <script type="application/ld+json">{JSON.stringify(articleSchema)}</script>
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
      </Helmet>

      <article className="py-12 md:py-16">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <Link to="/blog" className="mb-6 inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary">
              <ArrowLeft className="h-4 w-4" />
              Natrag na blog
            </Link>

            <header className="mb-10">
              <h1 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl">
                Treba li dozvola za kopanje bunara u Hrvatskoj?
              </h1>
              <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1"><Calendar className="h-4 w-4" />5. ožujka 2024.</span>
                <span className="flex items-center gap-1"><Clock className="h-4 w-4" />7 min čitanja</span>
              </div>
              <img 
                src={permitsImage} 
                alt="Dokumentacija i dozvole za bunar" 
                className="mt-8 w-full rounded-xl object-cover shadow-medium"
              />
            </header>

            <div className="prose prose-lg max-w-none">
              <p className="lead text-xl text-muted-foreground">
                Jedno od najčešćih pitanja prije kopanja bunara je pitanje dozvola. Zakonodavstvo u Hrvatskoj 
                regulira korištenje podzemnih voda, ali nisu svi bunari jednako tretirani. Evo što trebate znati.
              </p>

              <div className="my-8 flex items-start gap-4 rounded-xl border border-amber-200 bg-amber-50 p-5 dark:border-amber-900 dark:bg-amber-950/30">
                <AlertTriangle className="mt-1 h-6 w-6 shrink-0 text-amber-600" />
                <div>
                  <h3 className="font-semibold text-amber-800 dark:text-amber-200">Važna napomena</h3>
                  <p className="mt-1 text-sm text-amber-700 dark:text-amber-300">
                    Zakonski propisi mogu se mijenjati. Preporučujemo provjeru kod lokalne uprave ili 
                    Hrvatskih voda prije početka radova.
                  </p>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kada nije potrebna dozvola?</h2>
              <p className="text-muted-foreground">
                Za <strong>bunare za vlastite potrebe kućanstva</strong> s malim kapacitetom crpljenja 
                (do 10 m³ dnevno) najčešće nije potrebna vodopravna dozvola, već samo prijava.
              </p>
              <p className="text-muted-foreground">
                Ovo uključuje:
              </p>
              <ul className="list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Bunare za zalijevanje vrta</li>
                <li>Bunare za pranje automobila i dvorišta</li>
                <li>Bunare za napajanje stoke (manje količine)</li>
                <li>Bunare za sanitarne potrebe vikendica</li>
              </ul>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Kada je potrebna dozvola?</h2>
              <p className="text-muted-foreground">
                <strong>Vodopravna dozvola</strong> potrebna je za:
              </p>
              <ul className="list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Crpljenje više od 10 m³ vode dnevno</li>
                <li>Komercijalne namjene (poljoprivreda, industrija)</li>
                <li>Bunare za javnu vodoopskrbu</li>
                <li>Bunare u zaštićenim područjima</li>
                <li>Artešte bunare</li>
              </ul>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Postupak prijave bunara</h2>
              
              <div className="my-8 space-y-4">
                <div className="flex gap-4 rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <span className="font-bold text-primary">1</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Prikupite dokumentaciju</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Vlasnički list, kopija katastarskog plana, skica lokacije bunara na parceli.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <span className="font-bold text-primary">2</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Podnesite zahtjev</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Zahtjev se podnosi Hrvatskim vodama ili nadležnom tijelu lokalne samouprave.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
                    <span className="font-bold text-primary">3</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Čekajte odobrenje</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Za jednostavne prijave rok je 15-30 dana. Za dozvole može biti i 2-3 mjeseca.
                    </p>
                  </div>
                </div>
                <div className="flex gap-4 rounded-xl border border-border bg-card p-5">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-accent/10">
                    <span className="font-bold text-accent">4</span>
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Izvedite radove</h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      Nakon odobrenja možete započeti s kopanjem ili bušenjem bunara.
                    </p>
                  </div>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Potrebna dokumentacija</h2>
              <div className="my-6 rounded-xl border border-border bg-muted/30 p-6">
                <div className="flex items-start gap-3">
                  <FileText className="mt-1 h-5 w-5 shrink-0 text-primary" />
                  <ul className="space-y-2 text-muted-foreground">
                    <li>• Zahtjev za izdavanje vodopravne dozvole / prijava</li>
                    <li>• Dokaz o vlasništvu (vlasnički list)</li>
                    <li>• Kopija katastarskog plana</li>
                    <li>• Tehnički opis zahvata (dubina, promjer, namjena)</li>
                    <li>• Za veće zahvate: elaborat o utjecaju na okoliš</li>
                  </ul>
                </div>
              </div>

              <h2 className="mt-10 text-2xl font-bold text-foreground">Legalizacija postojećeg bunara</h2>
              <p className="text-muted-foreground">
                Ako već imate bunar koji nije prijavljen, možete ga legalizirati podnošenjem zahtjeva za 
                naknadno odobrenje. Postupak je sličan prijavi novog bunara, ali može uključivati dodatne 
                troškove i inspekciju.
              </p>
              <p className="text-muted-foreground">
                Legalizacija je preporučljiva jer:
              </p>
              <ul className="list-disc space-y-2 pl-6 text-muted-foreground">
                <li>Izbjegavate moguće kazne</li>
                <li>Bunar možete navesti kao vrijednost nekretnine</li>
                <li>Imate pravnu sigurnost korištenja</li>
              </ul>

              {/* FAQ Section */}
              <h2 className="mt-10 text-2xl font-bold text-foreground">Česta pitanja o dozvolama</h2>
              <div className="mt-6">
                <Accordion type="single" collapsible className="space-y-4">
                  {faqs.map((faq, index) => (
                    <AccordionItem
                      key={index}
                      value={`item-${index}`}
                      className="rounded-lg border border-border bg-card px-6 shadow-soft"
                    >
                      <AccordionTrigger className="text-left font-semibold hover:no-underline">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>

              <div className="my-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
                <p className="text-lg font-semibold text-foreground">Trebate pomoć s dokumentacijom?</p>
                <p className="mt-2 text-muted-foreground">
                  Pomažemo klijentima s prijavama i dozvolama – od savjetovanja do kompletne izrade dokumentacije.
                </p>
                <Button asChild variant="cta" className="mt-4">
                  <Link to="/kontakt">Zatražite pomoć</Link>
                </Button>
              </div>
            </div>

            <div className="mt-12 border-t border-border pt-8">
              <h3 className="font-semibold text-foreground">Povezani članci</h3>
              <div className="mt-4 grid gap-4 md:grid-cols-2">
                <Link to="/blog/cijena-kopanja-bunara" className="rounded-lg border border-border p-4 hover:border-primary">
                  Koliko košta kopanje bunara? →
                </Link>
                <Link to="/blog/bunar-za-kucu" className="rounded-lg border border-border p-4 hover:border-primary">
                  Bunar za kuću – prednosti i nedostaci →
                </Link>
              </div>
            </div>
          </div>
        </div>
      </article>
    </Layout>
  );
}
