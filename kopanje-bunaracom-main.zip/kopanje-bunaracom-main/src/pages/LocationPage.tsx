import { Helmet } from "react-helmet-async";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { FAQSection } from "@/components/sections/FAQSection";
import { CTASection } from "@/components/sections/CTASection";
import { Phone, ArrowRight, MapPin, CheckCircle, Droplets, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface FAQ {
  question: string;
  answer: string;
}

interface LocationData {
  id: string;
  name: string;
  slug: string;
  region: string;
  description: string | null;
  soil_info: string | null;
  water_info: string | null;
  nearby_areas: string[];
  faqs: FAQ[];
  meta_title: string | null;
  meta_description: string | null;
}

// Fallback data for locations without DB entry
const fallbackData: Record<string, Partial<LocationData>> = {
  zagreb: {
    name: "Zagreb",
    region: "Središnja Hrvatska",
    description: "Zagreb i okolica karakterizira aluvijalno tlo rijeke Save s relativno visokim razinama podzemnih voda. Kopanje i bušenje bunara u Zagrebu idealno je za osiguranje neovisnog izvora vode za vrtove, poljoprivredu i kućanstva.",
    soil_info: "Tlo u zagrebačkoj regiji većinom je aluvijalno, sastavljeno od šljunka i pijeska, što omogućuje relativno jednostavno bušenje i dobru izdašnost bunara.",
    water_info: "Podzemne vode u Zagrebu obično se nalaze na dubini od 5 do 25 metara, ovisno o lokaciji. Kvaliteta vode je općenito dobra.",
    nearby_areas: ["Velika Gorica", "Samobor", "Zaprešić", "Sesvete", "Dugo Selo"],
    faqs: [
      { question: "Koliko košta kopanje bunara u Zagrebu?", answer: "Cijena kopanja bunara u Zagrebu kreće se od 500 do 2500 EUR ovisno o dubini i uvjetima tla. Bušenje bunara košta 40-70 EUR po metru dubine. Kontaktirajte nas za besplatnu procjenu." },
      { question: "Koje su dubine podzemnih voda u Zagrebu?", answer: "U zagrebačkoj regiji podzemne vode najčešće se nalaze na dubini od 5 do 25 metara. U nekim dijelovima, posebno bliže Savi, voda može biti i plića." },
      { question: "Treba li dozvola za bunar u Zagrebu?", answer: "Za bunare do 50m³ dnevnog crpljenja obično je potrebna samo prijava. Za veće kapacitete potrebna je vodopravna dozvola. Pomažemo s dokumentacijom." },
    ],
  },
  split: {
    name: "Split",
    region: "Dalmacija",
    description: "Split i dalmatinska obala imaju specifične uvjete za bušenje bunara zbog krških terena. Naši stručnjaci imaju iskustvo u pronalaženju podzemnih vodenih tokova u ovom zahtjevnom terenu.",
    soil_info: "Dalmatinski krš karakterizira vapnenačko tlo s pukotinama i špiljama. Pronalazak vode zahtijeva posebno iskustvo i opremu.",
    water_info: "Podzemne vode u splitskoj regiji nalaze se na različitim dubinama, često 30-80 metara, ali kvaliteta je izvrsna.",
    nearby_areas: ["Solin", "Kaštela", "Trogir", "Omiš", "Makarska"],
    faqs: [
      { question: "Je li moguće bušiti bunar u krškom terenu kod Splita?", answer: "Da, moguće je. Krški teren zahtijeva posebne tehnike i iskustvo u pronalaženju vodenih žila. Naš tim ima višegodišnje iskustvo u bušenju bunara na dalmatinskom kršu." },
      { question: "Kolika je dubina bunara potrebna u Splitu?", answer: "U splitskoj regiji dubina bunara najčešće iznosi 30-80 metara, ovisno o lokaciji. U nekim područjima voda može biti dostupna i na manjim dubinama." },
    ],
  },
  osijek: {
    name: "Osijek",
    region: "Slavonija",
    description: "Osijek i slavonska ravnica idealni su za kopanje i bušenje bunara zahvaljujući plodnom aluvijalnom tlu i relativno visokim razinama podzemnih voda.",
    soil_info: "Slavonsko tlo karakterizira bogata crnica i aluvijalni nanosi rijeke Drave, što omogućuje jednostavno bušenje i visoku izdašnost bunara.",
    water_info: "Podzemne vode u slavonskoj regiji nalaze se već na 3-15 metara dubine, s izvrsnom kvalitetom i obiljem vode.",
    nearby_areas: ["Đakovo", "Vinkovci", "Vukovar", "Našice", "Beli Manastir"],
    faqs: [
      { question: "Koliko je dubok bunar potreban u Osijeku?", answer: "U osječkoj regiji podzemne vode često se nalaze već na 3-15 metara dubine, što značajno smanjuje troškove bušenja i kopanja bunara." },
    ],
  },
};

const defaultLocationData = {
  description: "Pružamo profesionalne usluge kopanja i bušenja bunara s višegodišnjim iskustvom. Naš tim stručnjaka osigurava kvalitetnu izvedbu i pouzdane rezultate.",
  soil_info: "Provodimo detaljnu analizu tla prije početka radova kako bismo odredili optimalnu metodu i dubinu bušenja.",
  water_info: "Određujemo razinu i kvalitetu podzemnih voda na vašoj lokaciji prije početka radova.",
  nearby_areas: [] as string[],
  faqs: [
    { question: "Koliko traje kopanje bunara?", answer: "Vrijeme izvedbe ovisi o dubini i uvjetima tla. Obično kopani bunar završavamo u 2-5 dana, a bušeni u 1-3 dana." },
    { question: "Dajete li garanciju na izvedene radove?", answer: "Da, na sve izvedene radove dajemo garanciju. Također pružamo savjete za pravilno održavanje bunara." },
    { question: "Pomažete li s dokumentacijom?", answer: "Da, pomažemo s kompletnom dokumentacijom potrebnom za legalizaciju bunara i ishođenje potrebnih dozvola." },
  ],
};

export default function LocationPage() {
  const { location } = useParams<{ location: string }>();
  const navigate = useNavigate();
  const locationSlug = location || "";
  
  const [data, setData] = useState<LocationData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchLocation() {
      // Try to fetch from database first
      const { data: dbData, error } = await supabase
        .from('locations')
        .select('*')
        .eq('slug', locationSlug)
        .eq('status', 'published')
        .maybeSingle();

      if (dbData) {
        setData({
          ...dbData,
          nearby_areas: (dbData.nearby_areas as unknown as string[]) || [],
          faqs: (dbData.faqs as unknown as FAQ[]) || [],
        });
      } else {
        // Use fallback data
        const fallback = fallbackData[locationSlug];
        if (fallback) {
          setData({
            id: locationSlug,
            name: fallback.name || locationSlug.charAt(0).toUpperCase() + locationSlug.slice(1),
            slug: locationSlug,
            region: fallback.region || "Hrvatska",
            description: fallback.description || defaultLocationData.description,
            soil_info: fallback.soil_info || defaultLocationData.soil_info,
            water_info: fallback.water_info || defaultLocationData.water_info,
            nearby_areas: fallback.nearby_areas || defaultLocationData.nearby_areas,
            faqs: fallback.faqs || defaultLocationData.faqs,
            meta_title: null,
            meta_description: null,
          });
        } else {
          // Generic fallback
          setData({
            id: locationSlug,
            name: locationSlug.charAt(0).toUpperCase() + locationSlug.slice(1).replace(/-/g, " "),
            slug: locationSlug,
            region: "Hrvatska",
            description: defaultLocationData.description,
            soil_info: defaultLocationData.soil_info,
            water_info: defaultLocationData.water_info,
            nearby_areas: defaultLocationData.nearby_areas,
            faqs: defaultLocationData.faqs,
            meta_title: null,
            meta_description: null,
          });
        }
      }
      setIsLoading(false);
    }

    if (locationSlug) {
      fetchLocation();
    }
  }, [locationSlug]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-20 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  if (!data) return null;

  const pageTitle = data.meta_title || `Kopanje bunara ${data.name} | Bušenje bunara ${data.region}`;
  const pageDescription = data.meta_description || `Profesionalno kopanje i bušenje bunara u ${data.name} i okolici. Višegodišnje iskustvo, povoljne cijene. Besplatna procjena - nazovite +385 97 601 9558.`;

  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: `KopanjeBunara.hr - ${data.name}`,
    description: pageDescription,
    url: `https://kopanjebunara.hr/kopanje-bunara-${locationSlug}`,
    telephone: "+385976019558",
    areaServed: {
      "@type": "City",
      name: data.name,
    },
    serviceType: ["Kopanje bunara", "Bušenje bunara"],
  };

  return (
    <>
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <link rel="canonical" href={`https://kopanjebunara.hr/kopanje-bunara-${locationSlug}`} />
        <script type="application/ld+json">
          {JSON.stringify(localBusinessSchema)}
        </script>
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-3xl text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm text-primary-foreground/90">
                <MapPin className="h-4 w-4" />
                {data.region}
              </div>
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                Kopanje i bušenje bunara {data.name}
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Profesionalna usluga kopanja i bušenja bunara na području {data.name} i okolice. 
                Višegodišnje iskustvo i pouzdana izvedba.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button variant="hero" size="xl" asChild>
                  <Link to="/kontakt">
                    Zatražite ponudu
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="heroOutline" size="xl" asChild>
                  <a href="tel:+385976019558">
                    <Phone className="mr-2 h-5 w-5" />
                    +385 97 601 9558
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mx-auto max-w-4xl">
              <div className="prose prose-lg max-w-none">
                <h2 className="text-2xl font-bold text-foreground">
                  Profesionalno kopanje bunara u {data.name}
                </h2>
                <p className="text-muted-foreground">
                  {data.description}
                </p>

                <div className="my-12 grid gap-8 md:grid-cols-2">
                  <div className="rounded-xl border border-border bg-card p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="rounded-full bg-primary/10 p-3">
                        <Droplets className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-foreground">Uvjeti tla</h3>
                    </div>
                    <p className="text-muted-foreground">{data.soil_info}</p>
                  </div>

                  <div className="rounded-xl border border-border bg-card p-6">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="rounded-full bg-primary/10 p-3">
                        <Droplets className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-foreground">Podzemne vode</h3>
                    </div>
                    <p className="text-muted-foreground">{data.water_info}</p>
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-foreground mt-12">
                  Zašto odabrati nas za kopanje bunara u {data.name}?
                </h2>
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {[
                    "Višegodišnje iskustvo u regiji",
                    "Besplatna procjena terena",
                    "Konkurentne cijene",
                    "Garancija na izvedene radove",
                    "Pomoć s dokumentacijom",
                    "Brza i pouzdana izvedba",
                  ].map((item) => (
                    <li key={item} className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 shrink-0 text-primary" />
                      <span className="text-muted-foreground">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Nearby Areas */}
        {data.nearby_areas.length > 0 && (
          <section className="py-12 bg-muted/30">
            <div className="container">
              <div className="mx-auto max-w-4xl text-center">
                <h2 className="text-2xl font-bold text-foreground mb-6">
                  Pokrivamo i okolna područja
                </h2>
                <div className="flex flex-wrap justify-center gap-3">
                  {data.nearby_areas.map((area) => (
                    <span
                      key={area}
                      className="rounded-full bg-background border border-border px-4 py-2 text-sm text-muted-foreground"
                    >
                      {area}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {data.faqs.length > 0 && (
          <FAQSection
            title={`Česta pitanja o kopanju bunara u ${data.name}`}
            description="Odgovori na najčešća pitanja o kopanju i bušenju bunara u ovoj regiji."
            faqs={data.faqs}
          />
        )}

        <CTASection />
      </Layout>
    </>
  );
}
