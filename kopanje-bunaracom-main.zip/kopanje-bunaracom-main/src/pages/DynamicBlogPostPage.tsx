import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Helmet } from "react-helmet-async";
import { Layout } from "@/components/layout/Layout";
import { CTASection } from "@/components/sections/CTASection";
import { supabase } from "@/integrations/supabase/client";
import { Calendar, ArrowLeft, User } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import NotFound from "./NotFound";

interface Post {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string | null;
  cover_image: string | null;
  published_at: string | null;
  created_at: string;
  meta_title: string | null;
  meta_description: string | null;
  og_image: string | null;
}

export default function DynamicBlogPostPage() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<Post | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    async function fetchPost() {
      if (!slug) return;

      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .eq("slug", slug)
        .eq("status", "published")
        .single();

      if (error || !data) {
        setNotFound(true);
      } else {
        setPost(data);
      }
      setLoading(false);
    }

    fetchPost();
  }, [slug]);

  if (loading) {
    return (
      <Layout>
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-3xl">
              <Skeleton className="h-10 w-3/4 bg-primary-foreground/20" />
              <Skeleton className="mt-4 h-6 w-1/2 bg-primary-foreground/20" />
            </div>
          </div>
        </section>
        <section className="py-16">
          <div className="container">
            <div className="mx-auto max-w-3xl space-y-4">
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-full" />
              <Skeleton className="h-6 w-3/4" />
            </div>
          </div>
        </section>
      </Layout>
    );
  }

  if (notFound || !post) {
    return <NotFound />;
  }

  const publishDate = post.published_at || post.created_at;

  return (
    <>
      <Helmet>
        <title>{post.meta_title || post.title} | KopanjeBunara.hr</title>
        <meta
          name="description"
          content={post.meta_description || post.excerpt || ""}
        />
        <link rel="canonical" href={`https://kopanjebunara.hr/blog/${post.slug}`} />
        {post.og_image && <meta property="og:image" content={post.og_image} />}
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-3xl">
              <Link
                to="/blog"
                className="mb-6 inline-flex items-center gap-2 text-primary-foreground/80 hover:text-primary-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
                Povratak na blog
              </Link>
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                {post.title}
              </h1>
              <div className="mt-4 flex items-center gap-4 text-primary-foreground/80">
                <span className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  {new Date(publishDate).toLocaleDateString("hr-HR", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
            </div>
          </div>
        </section>

        {/* Cover Image */}
        {post.cover_image && (
          <section className="py-8">
            <div className="container">
              <div className="mx-auto max-w-3xl">
                <img
                  src={post.cover_image}
                  alt={post.title}
                  className="w-full rounded-xl object-cover shadow-lg"
                />
              </div>
            </div>
          </section>
        )}

        {/* Content */}
        <section className="py-8 md:py-12">
          <div className="container">
            <article className="prose prose-lg mx-auto max-w-3xl">
              {post.content ? (
                <div dangerouslySetInnerHTML={{ __html: post.content }} />
              ) : (
                <p className="text-muted-foreground">Sadržaj nije dostupan.</p>
              )}
            </article>
          </div>
        </section>

        <CTASection />
      </Layout>
    </>
  );
}
