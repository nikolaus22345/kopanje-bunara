import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { CTASection } from "@/components/sections/CTASection";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { MapPin, Droplets, Search, CheckCircle, AlertTriangle, Phone } from "lucide-react";

const regionDepths = [
  { region: "Slavonija", depth: "5–20 m", description: "Plitke podzemne vode, pogodno za kopane bunare" },
  { region: "Središnja Hrvatska", depth: "10–40 m", description: "Umjerene dubine, često bušeni bunari" },
  { region: "Dalmacija (krš)", depth: "40–150 m", description: "Krško tlo, nepredvidive dubine" },
  { region: "Istra", depth: "30–100 m", description: "Mješovito tlo, varijabilne dubine" },
  { region: "Primorje", depth: "20–80 m", description: "Ovisno o blizini mora i terenu" },
  { region: "Otoci", depth: "100+ m", description: "Često vrlo duboko, ograničeni resursi" },
];

const faqs = [
  {
    question: "Postoji li karta koja pokazuje točnu dubinu vode?",
    answer: "Ne postoji karta koja može sa 100% sigurnošću pokazati točnu dubinu vode na pojedinoj parceli. Hidrogeološke karte daju orijentacijske podatke o vodonosnicima i geološkoj strukturi, ali podzemne vode nisu ravnomjerno raspoređene i variraju čak i na malim udaljenostima.",
  },
  {
    question: "Je li bušenje moguće bez karte?",
    answer: "Da, bušenje je moguće i bez detaljne karte. Iskusni bušači koriste kombinaciju lokalnog znanja, prethodnih bušenja u okolici i geoloških pokazatelja terena. Probno bušenje je najsigurniji način utvrđivanja prisutnosti vode.",
  },
  {
    question: "Koliko je bušenje bunara rizično?",
    answer: "Rizik ovisi o lokaciji. U Slavoniji i nizinskim područjima rizik je minimalan jer su podzemne vode plitke i obilne. U krškim područjima Dalmacije i Istre rizik je veći zbog nepredvidive geološke strukture. Iskusan izvođač može značajno smanjiti rizik procjenom terena.",
  },
  {
    question: "Može li se voda presušiti?",
    answer: "Pravilno izbušeni bunar rijetko presušuje. Važno je bušiti do dovoljne dubine i osigurati dovoljan kapacitet. Sezonske varijacije mogu utjecati na razinu vode, ali kvalitetno izvedeni bunari imaju stabilnu opskrbu tijekom cijele godine.",
  },
  {
    question: "Koliko duboko se najčešće buši bunar?",
    answer: "Prosječna dubina bušenja u Hrvatskoj kreće se od 15 do 60 metara, ovisno o regiji. U Slavoniji je često dovoljno 10-20 m, dok u Dalmaciji i na otocima dubine mogu prelaziti 100 m. Konačna dubina ovisi o lokalnim uvjetima i potrebama korisnika.",
  },
];

const locationLinks = [
  { name: "Zagreb", slug: "zagreb" },
  { name: "Split", slug: "split" },
  { name: "Osijek", slug: "osijek" },
  { name: "Zadar", slug: "zadar" },
  { name: "Rijeka", slug: "rijeka" },
  { name: "Slavonija", slug: "slavonija" },
  { name: "Dalmacija", slug: "dalmacija" },
  { name: "Istra", slug: "istra" },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

export default function KartaPodzemneVodePage() {
  return (
    <Layout>
      <Helmet>
        <title>Karta podzemnih voda u Hrvatskoj – kolika je dubina vode za bunar?</title>
        <meta
          name="description"
          content="Postoji li karta koja pokazuje dubinu podzemne vode u Hrvatskoj? Saznajte što hidrogeološke karte mogu pokazati i kada je bušenje bunara jedino rješenje."
        />
        <link rel="canonical" href="https://kopanjebunara.hr/karta-podzemnih-voda-hrvatska" />
        <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>
      </Helmet>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary via-primary/95 to-accent py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-5xl">
              Postoji li karta podzemnih voda u Hrvatskoj?
            </h1>
            <p className="mt-6 text-lg text-primary-foreground/90 md:text-xl">
              Mnogi traže kartu koja pokazuje točnu dubinu vode za bušenje bunara. 
              Hidrogeološke karte postoje, ali imaju svoja ograničenja. 
              Objasnit ćemo što realno mogu pokazati i kada je bušenje jedini siguran način.
            </p>
            <div className="mt-8">
              <Button asChild variant="hero" size="lg">
                <Link to="/kontakt">
                  <Search className="mr-2 h-5 w-5" />
                  Provjerite mogućnost bušenja
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Koje karte postoje */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Koje karte podzemnih voda postoje u Hrvatskoj?
            </h2>
            <div className="mt-8 grid gap-8 md:grid-cols-2">
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  U Hrvatskoj postoji nekoliko vrsta karata koje prikazuju podatke o podzemnim vodama:
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span><strong>Hidrogeološke karte</strong> – prikazuju tipove vodonosnika, propusnost stijena i opće karakteristike podzemnih voda</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span><strong>Karte vodonosnika</strong> – pokazuju rasprostranjenost i tip vodonosnih slojeva</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-accent" />
                    <span><strong>Geološke karte</strong> – daju uvid u sastav tla i stijena</span>
                  </li>
                </ul>
                <p className="text-muted-foreground">
                  Ove karte izrađuje Hrvatski geološki institut i dostupne su kao stručna dokumentacija. 
                  Međutim, važno je razumjeti njihova ograničenja za praktičnu primjenu kod bušenja bunara.
                </p>
              </div>
              
              {/* SVG Map of Croatia with regions */}
              <div className="flex items-center justify-center rounded-xl border border-border bg-card p-6 shadow-soft">
                <svg viewBox="0 0 400 300" className="h-auto w-full max-w-sm">
                  {/* Simplified Croatia map outline */}
                  <path
                    d="M50 100 L80 80 L120 70 L180 60 L220 55 L280 60 L320 80 L350 100 L360 140 L340 180 L300 200 L260 220 L220 250 L180 260 L140 240 L100 200 L70 160 L50 130 Z"
                    fill="hsl(var(--primary)/0.1)"
                    stroke="hsl(var(--primary))"
                    strokeWidth="2"
                  />
                  {/* Region labels */}
                  <text x="280" y="90" className="fill-primary text-xs font-medium">Slavonija</text>
                  <text x="150" y="100" className="fill-primary text-xs font-medium">Središnja HR</text>
                  <text x="80" y="150" className="fill-accent text-xs font-medium">Istra</text>
                  <text x="200" y="200" className="fill-accent text-xs font-medium">Dalmacija</text>
                  <text x="100" y="120" className="fill-primary text-xs font-medium">Primorje</text>
                  {/* Water droplet icons */}
                  <circle cx="300" cy="75" r="8" fill="hsl(var(--accent)/0.3)" />
                  <circle cx="170" cy="85" r="6" fill="hsl(var(--accent)/0.3)" />
                  <circle cx="220" cy="180" r="5" fill="hsl(var(--accent)/0.3)" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Prosječne dubine po regijama */}
      <section className="bg-muted/30 py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Kolika je prosječna dubina vode po regijama?
            </h2>
            <p className="mt-4 text-muted-foreground">
              Orijentacijske vrijednosti dubine podzemnih voda variraju značajno ovisno o geološkim karakteristikama regije:
            </p>
            
            <div className="mt-8 overflow-hidden rounded-xl border border-border bg-card shadow-soft">
              <table className="w-full">
                <thead className="bg-primary/5">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold text-foreground md:px-6">Regija</th>
                    <th className="px-4 py-3 text-left font-semibold text-foreground md:px-6">Prosječna dubina</th>
                    <th className="hidden px-4 py-3 text-left font-semibold text-foreground md:table-cell md:px-6">Napomena</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {regionDepths.map((item, index) => (
                    <tr key={index} className="hover:bg-muted/50">
                      <td className="px-4 py-3 font-medium text-foreground md:px-6">{item.region}</td>
                      <td className="px-4 py-3 text-accent md:px-6">{item.depth}</td>
                      <td className="hidden px-4 py-3 text-muted-foreground md:table-cell md:px-6">{item.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="mt-6 flex items-start gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 dark:border-amber-900 dark:bg-amber-950/30">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-600" />
              <p className="text-sm text-amber-800 dark:text-amber-200">
                <strong>Napomena:</strong> Ovo su orijentacijske vrijednosti temeljene na prosječnim uvjetima. 
                Stvarna dubina na vašoj parceli može značajno odstupati od prosjeka.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Što karte ne mogu pokazati */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Zašto karta ne može jamčiti vodu na vašoj parceli?
            </h2>
            <div className="mt-8 grid gap-8 md:grid-cols-2">
              <div className="space-y-4">
                <p className="text-muted-foreground">
                  Podzemne vode nisu ravnomjerno raspoređene poput jezera ili rijeka. 
                  One prolaze kroz složene geološke strukture koje se mogu dramatično mijenjati na vrlo malim udaljenostima.
                </p>
                <ul className="space-y-3">
                  <li className="flex items-start gap-3">
                    <MapPin className="mt-1 h-5 w-5 shrink-0 text-destructive" />
                    <span>Sastav tla može se promijeniti svakih nekoliko metara</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="mt-1 h-5 w-5 shrink-0 text-destructive" />
                    <span>Vodonosni slojevi nisu horizontalni niti kontinuirani</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <MapPin className="mt-1 h-5 w-5 shrink-0 text-destructive" />
                    <span>Krška područja imaju potpuno nepredvidivu strukturu</span>
                  </li>
                </ul>
              </div>
              <div className="flex items-center justify-center rounded-xl border-2 border-dashed border-primary/20 bg-primary/5 p-8">
                <p className="text-center text-lg font-semibold text-foreground">
                  <Droplets className="mx-auto mb-4 h-12 w-12 text-primary" />
                  Ne postoji karta koja sa 100% sigurnošću pokazuje dubinu vode na pojedinoj parceli.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Kako se stvarno utvrđuje voda */}
      <section className="bg-muted/30 py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Kako se pouzdano utvrđuje dubina vode?
            </h2>
            <div className="mt-8 grid gap-6 md:grid-cols-3">
              <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <span className="text-xl font-bold text-primary">1</span>
                </div>
                <h3 className="mt-4 font-semibold text-foreground">Lokalno iskustvo</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Iskusni bušači poznaju karakteristike tla i vode u određenom području iz prethodnih radova.
                </p>
              </div>
              <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <span className="text-xl font-bold text-primary">2</span>
                </div>
                <h3 className="mt-4 font-semibold text-foreground">Analiza okolice</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Podaci o postojećim bunarima u okolici daju vrijedne informacije o očekivanoj dubini.
                </p>
              </div>
              <div className="rounded-xl border border-border bg-card p-6 shadow-soft">
                <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent/10">
                  <span className="text-xl font-bold text-accent">3</span>
                </div>
                <h3 className="mt-4 font-semibold text-foreground">Probno bušenje</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Jedini 100% siguran način utvrđivanja prisutnosti i dubine vode na vašoj parceli.
                </p>
              </div>
            </div>
            
            <div className="mt-10 rounded-xl border border-accent/30 bg-accent/10 p-6 text-center">
              <p className="text-lg font-semibold text-foreground">
                Bušenje bunara jedini je siguran način da se utvrdi postoji li voda i na kojoj dubini.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Lokalni SEO blok */}
      <section className="py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-4xl">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Bušenje bunara po cijeloj Hrvatskoj
            </h2>
            <p className="mt-4 text-muted-foreground">
              Pružamo usluge bušenja i kopanja bunara u svim dijelovima Hrvatske. 
              Naše iskustvo pokriva različite geološke uvjete – od slavonskih nizina do dalmatinskog krša.
            </p>
            
            <div className="mt-8 flex flex-wrap gap-3">
              {locationLinks.map((location) => (
                <Link
                  key={location.slug}
                  to={`/lokacija/${location.slug}`}
                  className="rounded-full border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:border-primary hover:bg-primary/5"
                >
                  {location.name}
                </Link>
              ))}
              <Link
                to="/lokacije"
                className="rounded-full border border-primary bg-primary/10 px-4 py-2 text-sm font-medium text-primary transition-colors hover:bg-primary/20"
              >
                Sve lokacije →
              </Link>
            </div>
            
            <div className="mt-8 grid gap-4 md:grid-cols-2">
              <Link
                to="/usluge/busenje-bunara"
                className="group rounded-xl border border-border bg-card p-6 shadow-soft transition-all hover:border-primary hover:shadow-md"
              >
                <h3 className="font-semibold text-foreground group-hover:text-primary">Bušenje bunara →</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Profesionalno bušenje do 150+ metara dubine s modernom opremom.
                </p>
              </Link>
              <Link
                to="/usluge/kopanje-bunara"
                className="group rounded-xl border border-border bg-card p-6 shadow-soft transition-all hover:border-primary hover:shadow-md"
              >
                <h3 className="font-semibold text-foreground group-hover:text-primary">Kopanje bunara →</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Tradicionalni kopani bunari za područja s plitkim podzemnim vodama.
                </p>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="bg-muted/30 py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-3xl">
            <h2 className="text-center text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Česta pitanja o kartama podzemnih voda
            </h2>
            
            <div className="mt-10">
              <Accordion type="single" collapsible className="space-y-4">
                {faqs.map((faq, index) => (
                  <AccordionItem
                    key={index}
                    value={`item-${index}`}
                    className="rounded-lg border border-border bg-card px-6 shadow-soft"
                  >
                    <AccordionTrigger className="text-left font-semibold hover:no-underline">
                      {faq.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {faq.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-primary py-16 md:py-24">
        <div className="container">
          <div className="mx-auto max-w-2xl text-center">
            <h2 className="text-2xl font-bold tracking-tight text-primary-foreground md:text-3xl">
              Želite znati ima li vode na vašoj lokaciji?
            </h2>
            <p className="mt-4 text-lg text-primary-foreground/90">
              Karte su dobar početak za orijentaciju, ali bušenje daje konkretan i pouzdan odgovor. 
              Kontaktirajte nas za besplatnu procjenu mogućnosti na vašoj parceli.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button asChild variant="hero" size="lg">
                <Link to="/kontakt">Zatražite procjenu</Link>
              </Button>
              <Button asChild variant="heroOutline" size="lg">
                <a href="tel:+385976019558">
                  <Phone className="mr-2 h-5 w-5" />
                  Nazovite odmah
                </a>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
