import { Helmet } from "react-helmet-async";
import { Link, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <>
      <Helmet>
        <title>Stranica nije pronađena | KopanjeBunara.hr</title>
        <meta name="robots" content="noindex" />
      </Helmet>

      <Layout>
        <section className="flex min-h-[60vh] items-center justify-center py-16">
          <div className="container">
            <div className="mx-auto max-w-md text-center">
              <div className="text-8xl font-bold text-primary/20">404</div>
              <h1 className="mt-4 text-3xl font-bold text-foreground">
                Stranica nije pronađena
              </h1>
              <p className="mt-4 text-muted-foreground">
                Žao nam je, stranica koju tražite ne postoji ili je premještena.
              </p>
              <div className="mt-8 flex flex-col items-center gap-4 sm:flex-row sm:justify-center">
                <Button asChild>
                  <Link to="/">
                    <Home className="mr-2 h-4 w-4" />
                    Početna stranica
                  </Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link to="/kontakt">
                    <ArrowLeft className="mr-2 h-4 w-4" />
                    Kontaktirajte nas
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
};

export default NotFound;