import { Helmet } from "react-helmet-async";
import { Layout } from "@/components/layout/Layout";
import { HeroSection } from "@/components/sections/HeroSection";
import { FeaturesSection } from "@/components/sections/FeaturesSection";
import { ServicesSection } from "@/components/sections/ServicesSection";
import { ProcessSection } from "@/components/sections/ProcessSection";
import { LocationsSection } from "@/components/sections/LocationsSection";
import { FAQSection, defaultFAQs } from "@/components/sections/FAQSection";
import { CTASection } from "@/components/sections/CTASection";

const Index = () => {
  const localBusinessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    name: "KopanjeBunara.hr",
    description: "Profesionalno kopanje i bušenje bunara na području cijele Hrvatske. Višegodišnje iskustvo i pouzdana izvedba.",
    url: "https://kopanjebunara.hr",
    telephone: "+385976019558",
    email: "info@kopanjebunara.hr",
    areaServed: {
      "@type": "Country",
      name: "Croatia",
    },
    serviceType: ["Kopanje bunara", "Bušenje bunara", "Arteški bunari", "Čišćenje bunara"],
    priceRange: "$$",
  };

  return (
    <>
      <Helmet>
        <title>Kopanje i bušenje bunara u Hrvatskoj | KopanjeBunara.hr</title>
        <meta 
          name="description" 
          content="Profesionalno kopanje i bušenje bunara u Hrvatskoj. Višegodišnje iskustvo, brza izvedba i pouzdana usluga. Besplatna procjena - nazovite +385 97 601 9558." 
        />
        <meta name="keywords" content="kopanje bunara, bušenje bunara, bunar za vodu, arteški bunar, kopanje bunara cijena" />
        <link rel="canonical" href="https://kopanjebunara.hr/" />
        <script type="application/ld+json">
          {JSON.stringify(localBusinessSchema)}
        </script>
      </Helmet>

      <Layout>
        <HeroSection />
        <FeaturesSection />
        <ServicesSection />
        <ProcessSection />
        <LocationsSection />
        <FAQSection faqs={defaultFAQs} />
        <CTASection />
      </Layout>
    </>
  );
};

export default Index;
