import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { CTASection } from "@/components/sections/CTASection";
import { ArrowRight, MapPin, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Location {
  id: string;
  name: string;
  slug: string;
  region: string;
}

const regions = [
  { name: "Slavonija", slug: "slavonija" },
  { name: "Dalmacija", slug: "dalmacija" },
  { name: "Istra", slug: "istra" },
  { name: "Primorje", slug: "primorje" },
];

export default function LocationsPage() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchLocations() {
      const { data, error } = await supabase
        .from('locations')
        .select('id, name, slug, region')
        .eq('status', 'published')
        .order('region')
        .order('name');

      if (data) {
        setLocations(data);
      }
      setIsLoading(false);
    }

    fetchLocations();
  }, []);

  return (
    <>
      <Helmet>
        <title>Lokacije | Kopanje bunara u cijeloj Hrvatskoj | KopanjeBunara.hr</title>
        <meta 
          name="description" 
          content="Pružamo usluge kopanja i bušenja bunara u cijeloj Hrvatskoj - Zagreb, Split, Osijek, Rijeka, Zadar i svi gradovi. Nazovite +385 97 601 9558." 
        />
        <link rel="canonical" href="https://kopanjebunara.hr/lokacije" />
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                Područja rada
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Pružamo usluge kopanja i bušenja bunara na području cijele Hrvatske. 
                Pronađite svoju lokaciju.
              </p>
            </div>
          </div>
        </section>

        {/* Cities Grid */}
        <section className="py-16 md:py-24">
          <div className="container">
            <h2 className="text-2xl font-bold text-foreground md:text-3xl">
              Gradovi
            </h2>
            <p className="mt-2 text-muted-foreground">
              Odaberite grad za detaljne informacije o kopanju bunara u vašem području.
            </p>

            {isLoading ? (
              <div className="mt-8 flex justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="mt-8 grid gap-4 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
                {locations.map((location) => (
                  <Link
                    key={location.id}
                    to={`/lokacija/${location.slug}`}
                    className="group flex items-center justify-between rounded-lg border border-border bg-card p-4 shadow-soft transition-all duration-200 hover:border-primary/50 hover:shadow-medium"
                  >
                    <div className="flex items-center gap-3">
                      <MapPin className="h-5 w-5 text-primary" />
                      <div>
                        <h3 className="font-semibold text-foreground group-hover:text-primary">
                          {location.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">{location.region}</p>
                      </div>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-primary" />
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Regions */}
        <section className="bg-muted/50 py-16 md:py-24">
          <div className="container">
            <h2 className="text-2xl font-bold text-foreground md:text-3xl">
              Regije
            </h2>
            <p className="mt-2 text-muted-foreground">
              Pokrivamo sve regije Hrvatske.
            </p>

            <div className="mt-8 grid gap-4 sm:grid-cols-2 md:grid-cols-4">
              {regions.map((region) => (
                <Link
                  key={region.slug}
                  to={`/lokacija/${region.slug}`}
                  className="group flex flex-col items-center justify-center rounded-xl border border-border bg-card p-6 text-center shadow-soft transition-all duration-200 hover:border-primary/50 hover:shadow-medium"
                >
                  <h3 className="text-lg font-semibold text-foreground group-hover:text-primary">
                    {region.name}
                  </h3>
                  <p className="mt-1 text-sm text-muted-foreground">
                    Kopanje bunara
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <CTASection />
      </Layout>
    </>
  );
}
