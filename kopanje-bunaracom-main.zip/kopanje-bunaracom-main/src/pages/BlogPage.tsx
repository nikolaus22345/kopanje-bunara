import { useEffect, useState } from "react";
import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { CTASection } from "@/components/sections/CTASection";
import { ArrowRight, Calendar } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Skeleton } from "@/components/ui/skeleton";

// Static blog posts for backward compatibility
const staticBlogPosts = [
  {
    slug: "cijena-kopanja-bunara",
    title: "Koliko košta kopanje bunara u Hrvatskoj 2024?",
    excerpt: "Detaljan pregled cijena kopanja i bušenja bunara po regijama i metodama. Saznajte što utječe na cijenu i kako uštedjeti.",
    date: "2024-01-15",
    readTime: "8 min",
    isStatic: true,
  },
  {
    slug: "razlika-kopani-buseni-bunar",
    title: "Razlika između kopanog i bušenog bunara",
    excerpt: "Prednosti i nedostaci svake metode. Koji bunar je bolji izbor za vaše potrebe i lokaciju?",
    date: "2024-02-10",
    readTime: "6 min",
    isStatic: true,
  },
  {
    slug: "dozvola-za-bunar",
    title: "Treba li dozvola za bunar? Vodič za legalizaciju",
    excerpt: "Sve što trebate znati o dozvolama i legalizaciji bunara u Hrvatskoj. Koraci, dokumentacija i rokovi.",
    date: "2024-03-05",
    readTime: "7 min",
    isStatic: true,
  },
  {
    slug: "dubina-bunara",
    title: "Kolika je idealna dubina bunara?",
    excerpt: "Faktori koji određuju potrebnu dubinu bunara - od tipa tla do namjene. Savjeti stručnjaka.",
    date: "2024-04-12",
    readTime: "6 min",
    isStatic: true,
  },
  {
    slug: "bunar-za-kucu",
    title: "Bunar za kuću – prednosti i nedostaci",
    excerpt: "Isplati li se imati vlastiti bunar? Analiza troškova, ušteda i praktičnih aspekata.",
    date: "2024-05-20",
    readTime: "7 min",
    isStatic: true,
  },
];

interface DatabasePost {
  id: string;
  slug: string;
  title: string;
  excerpt: string | null;
  published_at: string | null;
  created_at: string;
}

interface BlogPost {
  slug: string;
  title: string;
  excerpt: string;
  date: string;
  readTime: string;
  isStatic: boolean;
}

export default function BlogPage() {
  const [dbPosts, setDbPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPosts() {
      const { data, error } = await supabase
        .from("posts")
        .select("id, slug, title, excerpt, published_at, created_at")
        .eq("status", "published")
        .order("published_at", { ascending: false });

      if (!error && data) {
        const formattedPosts: BlogPost[] = data.map((post: DatabasePost) => ({
          slug: post.slug,
          title: post.title,
          excerpt: post.excerpt || "",
          date: post.published_at || post.created_at,
          readTime: "5 min",
          isStatic: false,
        }));
        setDbPosts(formattedPosts);
      }
      setLoading(false);
    }

    fetchPosts();
  }, []);

  // Combine database posts with static posts, database posts first
  const allPosts = [...dbPosts, ...staticBlogPosts];

  return (
    <>
      <Helmet>
        <title>Blog | Savjeti o bunarima | KopanjeBunara.hr</title>
        <meta 
          name="description" 
          content="Stručni članci i savjeti o kopanju i bušenju bunara. Saznajte sve o cijenama, dozvolama, održavanju i odabiru pravog bunara." 
        />
        <link rel="canonical" href="https://kopanjebunara.hr/blog" />
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                Blog
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Stručni članci i savjeti o kopanju i bušenju bunara.
              </p>
            </div>
          </div>
        </section>

        {/* Blog Posts */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mx-auto max-w-4xl">
              {loading ? (
                <div className="space-y-8">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="rounded-xl border border-border bg-card p-6">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="mt-3 h-8 w-3/4" />
                      <Skeleton className="mt-2 h-4 w-full" />
                      <Skeleton className="mt-4 h-4 w-32" />
                    </div>
                  ))}
                </div>
              ) : (
                <div className="space-y-8">
                  {allPosts.map((post) => (
                  <article
                    key={post.slug}
                    className="group rounded-xl border border-border bg-card p-6 shadow-soft transition-all duration-200 hover:shadow-medium"
                  >
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(post.date).toLocaleDateString("hr-HR", {
                          day: "numeric",
                          month: "long",
                          year: "numeric",
                        })}
                      </span>
                      <span>•</span>
                      <span>{post.readTime} čitanja</span>
                    </div>
                    <h2 className="mt-3 text-xl font-bold text-foreground group-hover:text-primary md:text-2xl">
                      <Link to={`/blog/${post.slug}`}>
                        {post.title}
                      </Link>
                    </h2>
                    <p className="mt-2 text-muted-foreground">
                      {post.excerpt}
                    </p>
                    <Link
                      to={`/blog/${post.slug}`}
                      className="mt-4 inline-flex items-center gap-2 text-primary hover:underline"
                    >
                      Pročitajte više
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </article>
                  ))}
                </div>
              )}
            </div>
          </div>
        </section>

        <CTASection />
      </Layout>
    </>
  );
}

export { staticBlogPosts as blogPosts };
