import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Layout } from '@/components/layout/Layout';
import { supabase } from '@/integrations/supabase/client';
import { Loader2 } from 'lucide-react';

interface PageData {
  id: string;
  title: string;
  slug: string;
  content: string | null;
  meta_title: string | null;
  meta_description: string | null;
}

export default function DynamicPage() {
  const { slug: paramSlug } = useParams();
  const navigate = useNavigate();
  const location = window.location.pathname;
  const [page, setPage] = useState<PageData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Get slug from param or from the path itself (e.g., /politika-privatnosti)
  const slug = paramSlug || location.replace('/', '');

  useEffect(() => {
    async function fetchPage() {
      if (!slug) {
        navigate('/404');
        return;
      }

      const { data, error } = await supabase
        .from('pages')
        .select('id, title, slug, content, meta_title, meta_description')
        .eq('slug', slug)
        .eq('status', 'published')
        .single();

      if (error || !data) {
        navigate('/404');
        return;
      }

      setPage(data);
      setIsLoading(false);
    }

    fetchPage();
  }, [slug, navigate]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-20 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  if (!page) return null;

  return (
    <Layout>
      <Helmet>
        <title>{page.meta_title || page.title} | Kopanje Bunara</title>
        {page.meta_description && (
          <meta name="description" content={page.meta_description} />
        )}
        <link rel="canonical" href={`https://kopanje-bunaracom.lovable.app/stranica/${page.slug}`} />
      </Helmet>

      <article className="container py-12 max-w-4xl">
        <h1 className="text-4xl font-bold mb-8">{page.title}</h1>
        
        {page.content && (
          <div 
            className="prose prose-lg max-w-none"
            dangerouslySetInnerHTML={{ __html: page.content }}
          />
        )}
      </article>
    </Layout>
  );
}
