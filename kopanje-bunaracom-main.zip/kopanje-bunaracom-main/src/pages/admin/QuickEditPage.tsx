import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Search, ExternalLink, ArrowRight, FileText, MapPin, Wrench, LayoutGrid, BookOpen, Loader2 } from 'lucide-react';

interface PageMapping {
  type: 'section' | 'location' | 'service' | 'page' | 'post';
  editorUrl: string;
  label: string;
  icon: React.ReactNode;
  slug?: string;
}

export default function QuickEditPage() {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<PageMapping | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isLoading: authLoading } = useAuth();

  const parseUrlToType = (inputUrl: string): { type: string; slug: string; path: string } | null => {
    let path = inputUrl.trim();
    
    try {
      if (path.startsWith('http')) {
        const urlObj = new URL(path);
        path = urlObj.pathname;
      }
    } catch {
      // Not a valid URL, treat as path
    }
    
    if (!path.startsWith('/')) {
      path = '/' + path;
    }
    
    path = path.replace(/\/$/, '') || '/';

    // Match patterns
    if (path === '/') {
      return { type: 'home', slug: '', path };
    }
    
    if (path === '/usluge') {
      return { type: 'services-list', slug: '', path };
    }
    
    const serviceMatch = path.match(/^\/usluge\/(.+)$/);
    if (serviceMatch) {
      return { type: 'service', slug: serviceMatch[1], path };
    }
    
    if (path === '/lokacije') {
      return { type: 'locations-list', slug: '', path };
    }
    
    const locationMatch = path.match(/^\/lokacija\/(.+)$/);
    if (locationMatch) {
      return { type: 'location', slug: locationMatch[1], path };
    }
    
    if (path === '/kontakt') {
      return { type: 'contact', slug: '', path };
    }
    
    if (path === '/blog') {
      return { type: 'blog-list', slug: '', path };
    }
    
    const blogMatch = path.match(/^\/blog\/(.+)$/);
    if (blogMatch) {
      return { type: 'post', slug: blogMatch[1], path };
    }

    // Known static pages
    const staticPages = ['karta-podzemnih-voda-hrvatska', 'politika-privatnosti', 'uvjeti-koristenja'];
    const genericSlug = path.replace(/^\//, '');
    
    if (genericSlug && !genericSlug.includes('/')) {
      return { type: 'page', slug: genericSlug, path };
    }
    
    return null;
  };

  const handleSearch = async () => {
    if (!url.trim()) {
      toast({ title: 'Unesite URL', variant: 'destructive' });
      return;
    }
    
    setIsSearching(true);
    setNotFound(false);
    setResult(null);
    
    const parsed = parseUrlToType(url);
    
    if (!parsed) {
      setNotFound(true);
      setIsSearching(false);
      return;
    }

    try {
      let mapping: PageMapping | null = null;

      switch (parsed.type) {
        case 'home':
          mapping = {
            type: 'section',
            editorUrl: '/admin/sections?page=home',
            label: 'Početna stranica - Sekcije',
            icon: <LayoutGrid className="h-5 w-5" />
          };
          break;

        case 'services-list':
          mapping = {
            type: 'section',
            editorUrl: '/admin/sections?page=services',
            label: 'Stranica Usluge - Sekcije',
            icon: <LayoutGrid className="h-5 w-5" />
          };
          break;

        case 'service':
          // Look up service by slug to get ID
          const { data: service } = await supabase
            .from('services')
            .select('id, title')
            .eq('slug', parsed.slug)
            .maybeSingle();
          
          if (service) {
            mapping = {
              type: 'service',
              editorUrl: `/admin/services/${service.id}`,
              label: `Usluga: ${service.title}`,
              icon: <Wrench className="h-5 w-5" />,
              slug: parsed.slug
            };
          }
          break;

        case 'locations-list':
          mapping = {
            type: 'section',
            editorUrl: '/admin/sections?page=locations',
            label: 'Stranica Lokacije - Sekcije',
            icon: <LayoutGrid className="h-5 w-5" />
          };
          break;

        case 'location':
          // Look up location by slug to get ID
          const { data: location } = await supabase
            .from('locations')
            .select('id, name')
            .eq('slug', parsed.slug)
            .maybeSingle();
          
          if (location) {
            mapping = {
              type: 'location',
              editorUrl: `/admin/locations/${location.id}`,
              label: `Lokacija: ${location.name}`,
              icon: <MapPin className="h-5 w-5" />,
              slug: parsed.slug
            };
          }
          break;

        case 'contact':
          mapping = {
            type: 'section',
            editorUrl: '/admin/sections?page=contact',
            label: 'Kontakt stranica - Sekcije',
            icon: <LayoutGrid className="h-5 w-5" />
          };
          break;

        case 'blog-list':
          mapping = {
            type: 'section',
            editorUrl: '/admin/sections?page=blog',
            label: 'Blog stranica - Sekcije',
            icon: <LayoutGrid className="h-5 w-5" />
          };
          break;

        case 'post':
          // Look up post by slug to get ID
          const { data: post } = await supabase
            .from('posts')
            .select('id, title')
            .eq('slug', parsed.slug)
            .maybeSingle();
          
          if (post) {
            mapping = {
              type: 'post',
              editorUrl: `/admin/posts/${post.id}`,
              label: `Blog objava: ${post.title}`,
              icon: <BookOpen className="h-5 w-5" />,
              slug: parsed.slug
            };
          }
          break;

        case 'page':
          // Look up page by slug to get ID
          const { data: page } = await supabase
            .from('pages')
            .select('id, title')
            .eq('slug', parsed.slug)
            .maybeSingle();
          
          if (page) {
            mapping = {
              type: 'page',
              editorUrl: `/admin/pages/${page.id}`,
              label: `Stranica: ${page.title}`,
              icon: <FileText className="h-5 w-5" />,
              slug: parsed.slug
            };
          }
          break;
      }

      if (mapping) {
        setResult(mapping);
        setNotFound(false);
      } else {
        setNotFound(true);
      }
    } catch (error) {
      console.error('Error searching:', error);
      setNotFound(true);
    }
    
    setIsSearching(false);
  };

  const handleGoToEditor = () => {
    if (result) {
      navigate(result.editorUrl);
    }
  };

  const handleQuickLink = async (linkUrl: string) => {
    setUrl(linkUrl);
    // Trigger search after setting URL
    const parsed = parseUrlToType(linkUrl);
    if (parsed && (parsed.type === 'home' || parsed.type === 'services-list' || parsed.type === 'locations-list' || parsed.type === 'contact' || parsed.type === 'blog-list')) {
      // These don't need DB lookup
      let mapping: PageMapping | null = null;
      switch (parsed.type) {
        case 'home':
          mapping = { type: 'section', editorUrl: '/admin/sections?page=home', label: 'Početna stranica - Sekcije', icon: <LayoutGrid className="h-5 w-5" /> };
          break;
        case 'services-list':
          mapping = { type: 'section', editorUrl: '/admin/sections?page=services', label: 'Stranica Usluge - Sekcije', icon: <LayoutGrid className="h-5 w-5" /> };
          break;
        case 'locations-list':
          mapping = { type: 'section', editorUrl: '/admin/sections?page=locations', label: 'Stranica Lokacije - Sekcije', icon: <LayoutGrid className="h-5 w-5" /> };
          break;
        case 'contact':
          mapping = { type: 'section', editorUrl: '/admin/sections?page=contact', label: 'Kontakt stranica - Sekcije', icon: <LayoutGrid className="h-5 w-5" /> };
          break;
        case 'blog-list':
          mapping = { type: 'section', editorUrl: '/admin/sections?page=blog', label: 'Blog stranica - Sekcije', icon: <LayoutGrid className="h-5 w-5" /> };
          break;
      }
      setResult(mapping);
      setNotFound(false);
    }
  };

  const quickLinks = [
    { label: 'Početna stranica', url: '/', icon: <LayoutGrid className="h-4 w-4" /> },
    { label: 'Kontakt stranica', url: '/kontakt', icon: <LayoutGrid className="h-4 w-4" /> },
    { label: 'Usluge', url: '/usluge', icon: <Wrench className="h-4 w-4" /> },
    { label: 'Lokacije', url: '/lokacije', icon: <MapPin className="h-4 w-4" /> },
    { label: 'Blog', url: '/blog', icon: <BookOpen className="h-4 w-4" /> },
  ];

  if (authLoading) {
    return (
      <AdminLayout>
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-2xl">
        <div>
          <h1 className="text-3xl font-bold">Brzo uređivanje</h1>
          <p className="text-muted-foreground">
            Unesite URL stranice koju želite urediti i automatski ćemo vas preusmjeriti na odgovarajući editor
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Unesite URL</CardTitle>
            <CardDescription>
              Kopirajte URL iz preglednika ili unesite putanju (npr. /kontakt, /usluge/kopanje-bunara, /lokacija/zagreb)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <div className="flex-1">
                <Input
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://kopanje-bunara.com/kontakt ili /kontakt"
                  onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
              <Button onClick={handleSearch} disabled={isSearching}>
                {isSearching ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Pronađi
                  </>
                )}
              </Button>
            </div>

            {result && (
              <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg text-primary">
                      {result.icon}
                    </div>
                    <div>
                      <p className="font-medium">{result.label}</p>
                      <p className="text-sm text-muted-foreground">
                        Tip: {result.type === 'section' ? 'Sekcije stranice' : 
                              result.type === 'location' ? 'Lokacija' :
                              result.type === 'service' ? 'Usluga' :
                              result.type === 'post' ? 'Blog objava' : 'Stranica'}
                      </p>
                    </div>
                  </div>
                  <Button onClick={handleGoToEditor}>
                    Uredi
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </div>
            )}

            {notFound && (
              <div className="p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
                <p className="text-destructive font-medium">Stranica nije pronađena u bazi</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Provjerite URL ili kreirajte novu stranicu kroz Admin panel (Stranice, Lokacije, Usluge, ili Blog Objave)
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Brzi pristup</CardTitle>
            <CardDescription>Kliknite za brzi pristup uređivanju najčešćih stranica</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {quickLinks.map((link) => (
                <button
                  key={link.url}
                  onClick={() => handleQuickLink(link.url)}
                  className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted transition-colors text-left"
                >
                  <div className="text-muted-foreground">{link.icon}</div>
                  <span className="font-medium">{link.label}</span>
                  <span className="text-sm text-muted-foreground ml-auto">{link.url}</span>
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Primjeri URL-ova</CardTitle>
            <CardDescription>Formati URL-ova koje možete unijeti</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-sm text-muted-foreground space-y-2">
              <p><code className="bg-muted px-2 py-1 rounded">/lokacija/zagreb</code> - Otvara editor za lokaciju Zagreb</p>
              <p><code className="bg-muted px-2 py-1 rounded">/usluge/kopanje-bunara</code> - Otvara editor za uslugu kopanja bunara</p>
              <p><code className="bg-muted px-2 py-1 rounded">/blog/cijena-kopanja-bunara</code> - Otvara editor za blog članak</p>
              <p><code className="bg-muted px-2 py-1 rounded">https://kopanje-bunara.com/kontakt</code> - Podržani su i puni URL-ovi</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
