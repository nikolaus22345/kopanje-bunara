import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Save, Loader2, Eye, Plus, X } from 'lucide-react';
import type { Json } from '@/integrations/supabase/types';

interface FAQ {
  question: string;
  answer: string;
}

export default function LocationEditorPage() {
  const { id } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isLoading: authLoading, isAdmin } = useAuth();

  const [isLoading, setIsLoading] = useState(!isNew);
  const [isSaving, setIsSaving] = useState(false);

  const [name, setName] = useState('');
  const [slug, setSlug] = useState('');
  const [region, setRegion] = useState('');
  const [description, setDescription] = useState('');
  const [soilInfo, setSoilInfo] = useState('');
  const [waterInfo, setWaterInfo] = useState('');
  const [nearbyAreas, setNearbyAreas] = useState<string[]>([]);
  const [newArea, setNewArea] = useState('');
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [status, setStatus] = useState<'draft' | 'published'>('published');
  const [metaTitle, setMetaTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');

  useEffect(() => {
    async function fetchLocation() {
      if (isNew) {
        setIsLoading(false);
        return;
      }

      if (!id || authLoading || !isAdmin) return;

      const { data, error } = await supabase
        .from('locations')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error || !data) {
        toast({ title: 'Greška', description: 'Lokacija nije pronađena', variant: 'destructive' });
        navigate('/admin/locations');
        return;
      }

      setName(data.name);
      setSlug(data.slug);
      setRegion(data.region);
      setDescription(data.description || '');
      setSoilInfo(data.soil_info || '');
      setWaterInfo(data.water_info || '');
      setNearbyAreas((data.nearby_areas as unknown as string[]) || []);
      setFaqs((data.faqs as unknown as FAQ[]) || []);
      setStatus(data.status as 'draft' | 'published');
      setMetaTitle(data.meta_title || '');
      setMetaDescription(data.meta_description || '');
      setIsLoading(false);
    }

    fetchLocation();
  }, [id, isNew, navigate, toast, authLoading, isAdmin]);

  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[čć]/g, 'c')
      .replace(/[šś]/g, 's')
      .replace(/[žź]/g, 'z')
      .replace(/đ/g, 'd')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  };

  const handleNameChange = (value: string) => {
    setName(value);
    if (isNew || !slug) {
      setSlug(generateSlug(value));
    }
  };

  const addNearbyArea = () => {
    if (newArea.trim()) {
      setNearbyAreas([...nearbyAreas, newArea.trim()]);
      setNewArea('');
    }
  };

  const removeNearbyArea = (index: number) => {
    setNearbyAreas(nearbyAreas.filter((_, i) => i !== index));
  };

  const addFaq = () => {
    setFaqs([...faqs, { question: '', answer: '' }]);
  };

  const updateFaq = (index: number, field: 'question' | 'answer', value: string) => {
    const updated = [...faqs];
    updated[index][field] = value;
    setFaqs(updated);
  };

  const removeFaq = (index: number) => {
    setFaqs(faqs.filter((_, i) => i !== index));
  };

  const handleSave = async () => {
    if (!name || !slug || !region) {
      toast({ title: 'Greška', description: 'Ispunite obavezna polja', variant: 'destructive' });
      return;
    }

    setIsSaving(true);

    const locationData = {
      name,
      slug,
      region,
      description: description || null,
      soil_info: soilInfo || null,
      water_info: waterInfo || null,
      nearby_areas: nearbyAreas as Json,
      faqs: faqs.filter(f => f.question && f.answer) as unknown as Json,
      status,
      meta_title: metaTitle || null,
      meta_description: metaDescription || null,
    };

    let locationId = id;

    if (isNew) {
      const { data, error } = await supabase
        .from('locations')
        .insert([locationData])
        .select()
        .single();

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
      locationId = data.id;
    } else {
      const { error } = await supabase
        .from('locations')
        .update(locationData)
        .eq('id', id);

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
    }

    toast({ 
      title: isNew ? 'Lokacija kreirana' : 'Lokacija ažurirana', 
      description: 'Promjene su uspješno spremljene.' 
    });

    if (isNew) {
      navigate(`/admin/locations/${locationId}`);
    }

    setIsSaving(false);
  };

  if (isLoading || authLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/locations')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{isNew ? 'Nova lokacija' : 'Uredi lokaciju'}</h1>
              <p className="text-muted-foreground">
                {isNew ? 'Kreirajte novu lokaciju' : 'Uredite postojeću lokaciju'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!isNew && status === 'published' && (
              <a href={`/lokacija/${slug}`} target="_blank" rel="noopener noreferrer">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  Pregledaj
                </Button>
              </a>
            )}
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Spremi
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Osnovne informacije</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Naziv lokacije *</Label>
                    <Input
                      id="name"
                      value={name}
                      onChange={(e) => handleNameChange(e.target.value)}
                      placeholder="npr. Zagreb"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="region">Regija *</Label>
                    <Input
                      id="region"
                      value={region}
                      onChange={(e) => setRegion(e.target.value)}
                      placeholder="npr. Središnja Hrvatska"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="slug">URL Slug *</Label>
                  <Input
                    id="slug"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    placeholder="zagreb"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Opis</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Opis lokacije i uvjeta za bunare..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="soilInfo">Informacije o tlu</Label>
                  <Textarea
                    id="soilInfo"
                    value={soilInfo}
                    onChange={(e) => setSoilInfo(e.target.value)}
                    placeholder="Opis vrste tla na lokaciji..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="waterInfo">Informacije o podzemnim vodama</Label>
                  <Textarea
                    id="waterInfo"
                    value={waterInfo}
                    onChange={(e) => setWaterInfo(e.target.value)}
                    placeholder="Opis podzemnih voda na lokaciji..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Obližnja područja</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-2">
                  <Input
                    value={newArea}
                    onChange={(e) => setNewArea(e.target.value)}
                    placeholder="Dodaj obližnje mjesto..."
                    onKeyPress={(e) => e.key === 'Enter' && addNearbyArea()}
                  />
                  <Button type="button" onClick={addNearbyArea}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {nearbyAreas.map((area, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-muted text-sm"
                    >
                      {area}
                      <button onClick={() => removeNearbyArea(index)} className="hover:text-destructive">
                        <X className="h-3 w-3" />
                      </button>
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>FAQ</CardTitle>
                <Button type="button" variant="outline" size="sm" onClick={addFaq}>
                  <Plus className="mr-2 h-4 w-4" />
                  Dodaj pitanje
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                {faqs.map((faq, index) => (
                  <div key={index} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 space-y-2">
                        <Label>Pitanje</Label>
                        <Input
                          value={faq.question}
                          onChange={(e) => updateFaq(index, 'question', e.target.value)}
                          placeholder="Unesite pitanje..."
                        />
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFaq(index)}
                      >
                        <X className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                    <div className="space-y-2">
                      <Label>Odgovor</Label>
                      <Textarea
                        value={faq.answer}
                        onChange={(e) => updateFaq(index, 'answer', e.target.value)}
                        placeholder="Unesite odgovor..."
                        rows={3}
                      />
                    </div>
                  </div>
                ))}
                {faqs.length === 0 && (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    Nema FAQ pitanja. Kliknite "Dodaj pitanje" za dodavanje.
                  </p>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Objava</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Nacrt</SelectItem>
                      <SelectItem value="published">Objavljeno</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>SEO</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="metaTitle">Meta naslov ({metaTitle.length}/60)</Label>
                  <Input
                    id="metaTitle"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    placeholder="SEO naslov"
                    maxLength={60}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="metaDescription">Meta opis ({metaDescription.length}/160)</Label>
                  <Textarea
                    id="metaDescription"
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    placeholder="SEO opis"
                    maxLength={160}
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
