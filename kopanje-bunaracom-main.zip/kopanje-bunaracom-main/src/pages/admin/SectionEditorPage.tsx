import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { ArrowLeft, Save, Plus, Trash2, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

interface FAQ {
  question: string;
  answer: string;
}

interface Feature {
  icon: string;
  title: string;
  description: string;
}

interface Step {
  number: string;
  title: string;
  description: string;
}

interface Stat {
  value: string;
  label: string;
}

const PAGE_LABELS: Record<string, string> = {
  home: "Početna",
  contact: "Kontakt",
  services: "Usluge",
  locations: "Lokacije",
  blog: "Blog"
};

const SECTION_LABELS: Record<string, string> = {
  hero: "Hero sekcija",
  features: "Značajke",
  services: "Usluge",
  process: "Proces rada",
  locations: "Lokacije",
  faq: "FAQ",
  cta: "CTA sekcija",
  info: "Informacije"
};

export default function SectionEditorPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isLoading: authLoading, isAdmin } = useAuth();

  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  
  const [pageKey, setPageKey] = useState("");
  const [sectionKey, setSectionKey] = useState("");
  const [title, setTitle] = useState("");
  const [subtitle, setSubtitle] = useState("");
  const [description, setDescription] = useState("");
  const [isVisible, setIsVisible] = useState(true);
  const [sortOrder, setSortOrder] = useState(0);
  const [content, setContent] = useState<Record<string, any>>({});

  // Content-specific states
  const [features, setFeatures] = useState<Feature[]>([]);
  const [faqs, setFaqs] = useState<FAQ[]>([]);
  const [steps, setSteps] = useState<Step[]>([]);
  const [stats, setStats] = useState<Stat[]>([]);

  useEffect(() => {
    async function fetchSection() {
      if (!id || authLoading || !isAdmin) return;

      try {
        setIsLoading(true);
        const { data, error } = await supabase
          .from("page_sections")
          .select("*")
          .eq("id", id)
          .maybeSingle();

        if (error) throw error;
        if (!data) {
          toast({ title: "Sekcija nije pronađena", variant: "destructive" });
          navigate("/admin/sections");
          return;
        }

        setPageKey(data.page_key);
        setSectionKey(data.section_key);
        setTitle(data.title || "");
        setSubtitle(data.subtitle || "");
        setDescription(data.description || "");
        setIsVisible(data.is_visible);
        setSortOrder(data.sort_order);
        
        const contentData = data.content as Record<string, any> || {};
        setContent(contentData);
        setFeatures(contentData.features || []);
        setFaqs(contentData.faqs || []);
        setSteps(contentData.steps || []);
        setStats(contentData.stats || []);
      } catch (error: any) {
        toast({ title: "Greška pri učitavanju", description: error.message, variant: "destructive" });
      } finally {
        setIsLoading(false);
      }
    }

    fetchSection();
  }, [id, navigate, toast, authLoading, isAdmin]);

  const handleSave = async () => {
    try {
      setIsSaving(true);

      // Build content based on section type
      const updatedContent = { ...content };
      if (features.length > 0) updatedContent.features = features;
      if (faqs.length > 0) updatedContent.faqs = faqs;
      if (steps.length > 0) updatedContent.steps = steps;
      if (stats.length > 0) updatedContent.stats = stats;

      const { error } = await supabase
        .from("page_sections")
        .update({
          title: title || null,
          subtitle: subtitle || null,
          description: description || null,
          is_visible: isVisible,
          sort_order: sortOrder,
          content: updatedContent,
          updated_at: new Date().toISOString()
        })
        .eq("id", id);

      if (error) throw error;

      toast({ title: "Sekcija je spremljena" });
    } catch (error: any) {
      toast({ title: "Greška pri spremanju", description: error.message, variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  // Feature handlers
  const addFeature = () => setFeatures([...features, { icon: "Star", title: "", description: "" }]);
  const updateFeature = (index: number, field: keyof Feature, value: string) => {
    const updated = [...features];
    updated[index] = { ...updated[index], [field]: value };
    setFeatures(updated);
  };
  const removeFeature = (index: number) => setFeatures(features.filter((_, i) => i !== index));

  // FAQ handlers
  const addFaq = () => setFaqs([...faqs, { question: "", answer: "" }]);
  const updateFaq = (index: number, field: keyof FAQ, value: string) => {
    const updated = [...faqs];
    updated[index] = { ...updated[index], [field]: value };
    setFaqs(updated);
  };
  const removeFaq = (index: number) => setFaqs(faqs.filter((_, i) => i !== index));

  // Step handlers
  const addStep = () => setSteps([...steps, { number: String(steps.length + 1), title: "", description: "" }]);
  const updateStep = (index: number, field: keyof Step, value: string) => {
    const updated = [...steps];
    updated[index] = { ...updated[index], [field]: value };
    setSteps(updated);
  };
  const removeStep = (index: number) => setSteps(steps.filter((_, i) => i !== index));

  // Stat handlers
  const addStat = () => setStats([...stats, { value: "", label: "" }]);
  const updateStat = (index: number, field: keyof Stat, value: string) => {
    const updated = [...stats];
    updated[index] = { ...updated[index], [field]: value };
    setStats(updated);
  };
  const removeStat = (index: number) => setStats(stats.filter((_, i) => i !== index));

  if (isLoading || authLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate("/admin/sections")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">
                {SECTION_LABELS[sectionKey] || sectionKey}
              </h1>
              <p className="text-muted-foreground">
                {PAGE_LABELS[pageKey] || pageKey} stranica
              </p>
            </div>
          </div>
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Spremanje..." : "Spremi"}
          </Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            {/* Basic Info */}
            <Card>
              <CardHeader>
                <CardTitle>Osnovne informacije</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Naslov</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Naslov sekcije"
                  />
                </div>
                <div>
                  <Label htmlFor="subtitle">Podnaslov</Label>
                  <Input
                    id="subtitle"
                    value={subtitle}
                    onChange={(e) => setSubtitle(e.target.value)}
                    placeholder="Podnaslov sekcije"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Opis</Label>
                  <Textarea
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Opis sekcije"
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Features Editor */}
            {(sectionKey === "features" || features.length > 0) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Značajke
                    <Button size="sm" onClick={addFeature}>
                      <Plus className="mr-2 h-4 w-4" />
                      Dodaj
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {features.map((feature, index) => (
                    <div key={index} className="flex gap-4 rounded-lg border p-4">
                      <div className="flex-1 space-y-3">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Ikona</Label>
                            <Input
                              value={feature.icon}
                              onChange={(e) => updateFeature(index, "icon", e.target.value)}
                              placeholder="Shield, Clock, Award..."
                            />
                          </div>
                          <div>
                            <Label>Naslov</Label>
                            <Input
                              value={feature.title}
                              onChange={(e) => updateFeature(index, "title", e.target.value)}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>Opis</Label>
                          <Textarea
                            value={feature.description}
                            onChange={(e) => updateFeature(index, "description", e.target.value)}
                            rows={2}
                          />
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeFeature(index)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* FAQ Editor */}
            {(sectionKey === "faq" || faqs.length > 0) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    FAQ
                    <Button size="sm" onClick={addFaq}>
                      <Plus className="mr-2 h-4 w-4" />
                      Dodaj
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {faqs.map((faq, index) => (
                    <div key={index} className="flex gap-4 rounded-lg border p-4">
                      <div className="flex-1 space-y-3">
                        <div>
                          <Label>Pitanje</Label>
                          <Input
                            value={faq.question}
                            onChange={(e) => updateFaq(index, "question", e.target.value)}
                          />
                        </div>
                        <div>
                          <Label>Odgovor</Label>
                          <Textarea
                            value={faq.answer}
                            onChange={(e) => updateFaq(index, "answer", e.target.value)}
                            rows={3}
                          />
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeFaq(index)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Steps Editor */}
            {(sectionKey === "process" || steps.length > 0) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Koraci procesa
                    <Button size="sm" onClick={addStep}>
                      <Plus className="mr-2 h-4 w-4" />
                      Dodaj
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {steps.map((step, index) => (
                    <div key={index} className="flex gap-4 rounded-lg border p-4">
                      <div className="flex-1 space-y-3">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label>Broj</Label>
                            <Input
                              value={step.number}
                              onChange={(e) => updateStep(index, "number", e.target.value)}
                            />
                          </div>
                          <div>
                            <Label>Naslov</Label>
                            <Input
                              value={step.title}
                              onChange={(e) => updateStep(index, "title", e.target.value)}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>Opis</Label>
                          <Textarea
                            value={step.description}
                            onChange={(e) => updateStep(index, "description", e.target.value)}
                            rows={2}
                          />
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeStep(index)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* Stats Editor (for Hero) */}
            {(sectionKey === "hero" || stats.length > 0) && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    Statistike
                    <Button size="sm" onClick={addStat}>
                      <Plus className="mr-2 h-4 w-4" />
                      Dodaj
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {stats.map((stat, index) => (
                    <div key={index} className="flex gap-4 rounded-lg border p-4">
                      <div className="flex-1 grid grid-cols-2 gap-4">
                        <div>
                          <Label>Vrijednost</Label>
                          <Input
                            value={stat.value}
                            onChange={(e) => updateStat(index, "value", e.target.value)}
                            placeholder="500+"
                          />
                        </div>
                        <div>
                          <Label>Oznaka</Label>
                          <Input
                            value={stat.label}
                            onChange={(e) => updateStat(index, "label", e.target.value)}
                            placeholder="Izrađenih bunara"
                          />
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" onClick={() => removeStat(index)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            {/* CTA Content */}
            {sectionKey === "cta" && (
              <Card>
                <CardHeader>
                  <CardTitle>CTA sadržaj</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="cta_text">Tekst gumba</Label>
                    <Input
                      id="cta_text"
                      value={content.cta_text || ""}
                      onChange={(e) => setContent({ ...content, cta_text: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone">Telefon</Label>
                    <Input
                      id="phone"
                      value={content.phone || ""}
                      onChange={(e) => setContent({ ...content, phone: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Contact Info */}
            {sectionKey === "info" && (
              <Card>
                <CardHeader>
                  <CardTitle>Kontakt informacije</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label htmlFor="phone">Telefon</Label>
                    <Input
                      id="phone"
                      value={content.phone || ""}
                      onChange={(e) => setContent({ ...content, phone: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      value={content.email || ""}
                      onChange={(e) => setContent({ ...content, email: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="address">Adresa</Label>
                    <Input
                      id="address"
                      value={content.address || ""}
                      onChange={(e) => setContent({ ...content, address: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="working_hours">Radno vrijeme</Label>
                    <Input
                      id="working_hours"
                      value={content.working_hours || ""}
                      onChange={(e) => setContent({ ...content, working_hours: e.target.value })}
                    />
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Postavke</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="visible">Vidljivo</Label>
                  <Switch
                    id="visible"
                    checked={isVisible}
                    onCheckedChange={setIsVisible}
                  />
                </div>
                <div>
                  <Label htmlFor="sortOrder">Redoslijed</Label>
                  <Input
                    id="sortOrder"
                    type="number"
                    value={sortOrder}
                    onChange={(e) => setSortOrder(parseInt(e.target.value) || 0)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
