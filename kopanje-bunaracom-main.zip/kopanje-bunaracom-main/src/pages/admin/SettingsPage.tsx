import { useEffect, useState } from 'react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Save, Loader2 } from 'lucide-react';

export default function SettingsPage() {
  const { isLoading: authLoading, isAdmin } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  
  // General settings
  const [siteName, setSiteName] = useState('');
  const [siteDescription, setSiteDescription] = useState('');
  
  // Contact settings
  const [contactEmail, setContactEmail] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactAddress, setContactAddress] = useState('');
  
  // Social links
  const [facebook, setFacebook] = useState('');
  const [instagram, setInstagram] = useState('');
  const [youtube, setYoutube] = useState('');
  
  // Footer/Legal text
  const [footerDisclaimer, setFooterDisclaimer] = useState('');
  
  const { toast } = useToast();

  useEffect(() => {
    if (authLoading || !isAdmin) return;
    
    async function fetchSettings() {
      const { data, error } = await supabase.from('site_settings').select('key, value');
      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
      } else if (data) {
        data.forEach((setting) => {
          const value = setting.value;
          const stringValue = typeof value === 'string' 
            ? value.replace(/^"|"$/g, '') 
            : typeof value === 'object' && value !== null
              ? value
              : String(value || '');

          switch (setting.key) {
            case 'site_name': 
              setSiteName(typeof stringValue === 'string' ? stringValue : ''); 
              break;
            case 'site_description': 
              setSiteDescription(typeof stringValue === 'string' ? stringValue : ''); 
              break;
            case 'contact_email': 
              setContactEmail(typeof stringValue === 'string' ? stringValue : ''); 
              break;
            case 'contact_phone': 
              setContactPhone(typeof stringValue === 'string' ? stringValue : ''); 
              break;
            case 'contact_address': 
              setContactAddress(typeof stringValue === 'string' ? stringValue : ''); 
              break;
            case 'footer_disclaimer':
              setFooterDisclaimer(typeof stringValue === 'string' ? stringValue : '');
              break;
            case 'social_links':
              if (typeof value === 'object' && value !== null) {
                const social = value as { facebook?: string; instagram?: string; youtube?: string };
                setFacebook(social.facebook || '');
                setInstagram(social.instagram || '');
                setYoutube(social.youtube || '');
              }
              break;
          }
        });
      }
      setIsLoading(false);
    }
    fetchSettings();
  }, [authLoading, isAdmin]);

  const handleSave = async () => {
    setIsSaving(true);
    const updates = [
      { key: 'site_name', value: siteName },
      { key: 'site_description', value: siteDescription },
      { key: 'contact_email', value: contactEmail },
      { key: 'contact_phone', value: contactPhone },
      { key: 'contact_address', value: contactAddress },
      { key: 'footer_disclaimer', value: footerDisclaimer },
      { key: 'social_links', value: { facebook, instagram, youtube } },
    ];

    for (const update of updates) {
      await supabase.from('site_settings').upsert({ key: update.key, value: update.value }, { onConflict: 'key' });
    }

    toast({ title: 'Postavke spremljene', description: 'Promjene će se prikazati na stranici.' });
    setIsSaving(false);
  };

  if (isLoading || authLoading) {
    return <AdminLayout><div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin" /></div></AdminLayout>;
  }

  return (
    <AdminLayout>
      <div className="space-y-6 max-w-2xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Postavke stranice</h1>
            <p className="text-muted-foreground">Upravljajte globalnim postavkama koje se prikazuju na cijeloj stranici</p>
          </div>
          <Button onClick={handleSave} disabled={isSaving}>
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Spremi
          </Button>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Općenito</CardTitle>
            <CardDescription>Osnovne informacije o stranici (prikazuju se u headeru, footeru i SEO)</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Naziv stranice</Label>
              <Input value={siteName} onChange={(e) => setSiteName(e.target.value)} placeholder="KopanjeBunara.hr" />
            </div>
            <div className="space-y-2">
              <Label>Opis stranice</Label>
              <Textarea 
                value={siteDescription} 
                onChange={(e) => setSiteDescription(e.target.value)} 
                placeholder="Kratki opis koji se prikazuje u footeru..."
                rows={3}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Kontakt informacije</CardTitle>
            <CardDescription>Telefon, email i adresa koji se prikazuju u headeru i footeru</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Telefon</Label>
              <Input value={contactPhone} onChange={(e) => setContactPhone(e.target.value)} placeholder="+385 97 601 9558" />
              <p className="text-xs text-muted-foreground">Ovaj broj se prikazuje u headeru i footeru</p>
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input value={contactEmail} onChange={(e) => setContactEmail(e.target.value)} placeholder="info@kopanjebunara.hr" />
            </div>
            <div className="space-y-2">
              <Label>Adresa / Područje rada</Label>
              <Input value={contactAddress} onChange={(e) => setContactAddress(e.target.value)} placeholder="Radimo na području cijele Hrvatske" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Društvene mreže</CardTitle>
            <CardDescription>Linkovi na vaše profile na društvenim mrežama</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Facebook URL</Label>
              <Input value={facebook} onChange={(e) => setFacebook(e.target.value)} placeholder="https://facebook.com/..." />
            </div>
            <div className="space-y-2">
              <Label>Instagram URL</Label>
              <Input value={instagram} onChange={(e) => setInstagram(e.target.value)} placeholder="https://instagram.com/..." />
            </div>
            <div className="space-y-2">
              <Label>YouTube URL</Label>
              <Input value={youtube} onChange={(e) => setYoutube(e.target.value)} placeholder="https://youtube.com/..." />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Pravne napomene</CardTitle>
            <CardDescription>Disclaimer tekst koji se prikazuje u footeru</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Footer disclaimer</Label>
              <Textarea 
                value={footerDisclaimer} 
                onChange={(e) => setFooterDisclaimer(e.target.value)} 
                placeholder="Ova web stranica je marketinška platforma..."
                rows={4}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
