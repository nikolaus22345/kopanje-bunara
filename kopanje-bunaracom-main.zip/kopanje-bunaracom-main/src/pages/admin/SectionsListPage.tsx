import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { AdminLayout } from "@/components/admin/AdminLayout";
import { Edit, Eye, EyeOff, Search, LayoutGrid } from "lucide-react";
import { useAllPageSections } from "@/hooks/usePageSections";

const PAGE_LABELS: Record<string, string> = {
  home: "Početna",
  contact: "Kontakt",
  services: "Usluge",
  locations: "Lokacije",
  blog: "Blog"
};

const SECTION_LABELS: Record<string, string> = {
  hero: "Hero sekcija",
  features: "Značajke",
  services: "Usluge",
  process: "Proces rada",
  locations: "Lokacije",
  faq: "FAQ",
  cta: "CTA sekcija",
  info: "Informacije"
};

export default function SectionsListPage() {
  const { sections, isLoading } = useAllPageSections();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredSections = sections.filter(section => 
    section.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.page_key.toLowerCase().includes(searchQuery.toLowerCase()) ||
    section.section_key.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Group sections by page
  const groupedSections = filteredSections.reduce((acc, section) => {
    if (!acc[section.page_key]) {
      acc[section.page_key] = [];
    }
    acc[section.page_key].push(section);
    return acc;
  }, {} as Record<string, typeof sections>);

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sekcije stranica</h1>
            <p className="text-muted-foreground">
              Upravljajte sadržajem svih sekcija na stranicama
            </p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Pretraži sekcije..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
              </div>
            ) : Object.keys(groupedSections).length === 0 ? (
              <div className="flex flex-col items-center justify-center py-8 text-center">
                <LayoutGrid className="h-12 w-12 text-muted-foreground/50" />
                <h3 className="mt-4 text-lg font-semibold">Nema sekcija</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  Sekcije stranica nisu pronađene.
                </p>
              </div>
            ) : (
              <div className="space-y-8">
                {Object.entries(groupedSections).map(([pageKey, pageSections]) => (
                  <div key={pageKey}>
                    <h3 className="mb-4 text-lg font-semibold flex items-center gap-2">
                      <Badge variant="outline" className="text-sm">
                        {PAGE_LABELS[pageKey] || pageKey}
                      </Badge>
                    </h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Sekcija</TableHead>
                          <TableHead>Naslov</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Redoslijed</TableHead>
                          <TableHead className="text-right">Akcije</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pageSections.map((section) => (
                          <TableRow key={section.id}>
                            <TableCell className="font-medium">
                              {SECTION_LABELS[section.section_key] || section.section_key}
                            </TableCell>
                            <TableCell>{section.title || "-"}</TableCell>
                            <TableCell>
                              {section.is_visible ? (
                                <Badge variant="default" className="bg-green-600">
                                  <Eye className="mr-1 h-3 w-3" />
                                  Vidljivo
                                </Badge>
                              ) : (
                                <Badge variant="secondary">
                                  <EyeOff className="mr-1 h-3 w-3" />
                                  Skriveno
                                </Badge>
                              )}
                            </TableCell>
                            <TableCell>{section.sort_order}</TableCell>
                            <TableCell className="text-right">
                              <Link to={`/admin/sections/${section.id}`}>
                                <Button variant="ghost" size="icon">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </Link>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
