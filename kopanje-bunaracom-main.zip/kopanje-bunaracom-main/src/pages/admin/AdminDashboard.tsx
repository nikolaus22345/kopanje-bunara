import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { FileText, FolderOpen, Bookmark, Tags, TrendingUp, Clock } from 'lucide-react';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface DashboardStats {
  posts: number;
  publishedPosts: number;
  pages: number;
  categories: number;
  tags: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    posts: 0,
    publishedPosts: 0,
    pages: 0,
    categories: 0,
    tags: 0,
  });
  const [recentPosts, setRecentPosts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchStats() {
      try {
        const [postsRes, publishedRes, pagesRes, categoriesRes, tagsRes] = await Promise.all([
          supabase.from('posts').select('id', { count: 'exact', head: true }),
          supabase.from('posts').select('id', { count: 'exact', head: true }).eq('status', 'published'),
          supabase.from('pages').select('id', { count: 'exact', head: true }),
          supabase.from('categories').select('id', { count: 'exact', head: true }),
          supabase.from('tags').select('id', { count: 'exact', head: true }),
        ]);

        setStats({
          posts: postsRes.count || 0,
          publishedPosts: publishedRes.count || 0,
          pages: pagesRes.count || 0,
          categories: categoriesRes.count || 0,
          tags: tagsRes.count || 0,
        });

        // Fetch recent posts
        const { data: posts } = await supabase
          .from('posts')
          .select('id, title, status, created_at')
          .order('created_at', { ascending: false })
          .limit(5);

        setRecentPosts(posts || []);
      } catch (error) {
        console.error('Error fetching dashboard stats:', error);
      } finally {
        setIsLoading(false);
      }
    }

    fetchStats();
  }, []);

  const statCards = [
    { title: 'Ukupno objava', value: stats.posts, icon: FileText, color: 'text-blue-600', href: '/admin/posts' },
    { title: 'Objavljeno', value: stats.publishedPosts, icon: TrendingUp, color: 'text-green-600', href: '/admin/posts' },
    { title: 'Stranice', value: stats.pages, icon: FolderOpen, color: 'text-purple-600', href: '/admin/pages' },
    { title: 'Kategorije', value: stats.categories, icon: Bookmark, color: 'text-orange-600', href: '/admin/categories' },
    { title: 'Tagovi', value: stats.tags, icon: Tags, color: 'text-pink-600', href: '/admin/tags' },
  ];

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Pregled vašeg sadržaja</p>
        </div>

        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {statCards.map((stat) => (
            <Link key={stat.title} to={stat.href}>
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                  <stat.icon className={`h-4 w-4 ${stat.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {isLoading ? '-' : stat.value}
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Quick Actions & Recent Posts */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Brze akcije</CardTitle>
              <CardDescription>Najčešće radnje</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link to="/admin/posts/new">
                <Button className="w-full justify-start" variant="outline">
                  <FileText className="mr-2 h-4 w-4" />
                  Nova blog objava
                </Button>
              </Link>
              <Link to="/admin/pages/new">
                <Button className="w-full justify-start" variant="outline">
                  <FolderOpen className="mr-2 h-4 w-4" />
                  Nova stranica
                </Button>
              </Link>
              <Link to="/admin/categories">
                <Button className="w-full justify-start" variant="outline">
                  <Bookmark className="mr-2 h-4 w-4" />
                  Upravljaj kategorijama
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Nedavne objave</CardTitle>
              <CardDescription>Posljednjih 5 blog objava</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <p className="text-muted-foreground">Učitavanje...</p>
              ) : recentPosts.length === 0 ? (
                <div className="text-center py-6 text-muted-foreground">
                  <FileText className="mx-auto h-8 w-8 mb-2 opacity-50" />
                  <p>Nema objava</p>
                  <Link to="/admin/posts/new">
                    <Button variant="link" size="sm">
                      Kreiraj prvu objavu
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  {recentPosts.map((post) => (
                    <Link 
                      key={post.id} 
                      to={`/admin/posts/${post.id}`}
                      className="flex items-center justify-between p-2 rounded-md hover:bg-muted transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{post.title}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="h-3 w-3" />
                          {new Date(post.created_at).toLocaleDateString('hr-HR')}
                        </div>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full ${
                        post.status === 'published' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {post.status === 'published' ? 'Objavljeno' : 'Nacrt'}
                      </span>
                    </Link>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
