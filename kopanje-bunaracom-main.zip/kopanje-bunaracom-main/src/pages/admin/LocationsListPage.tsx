import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Plus, Search, Edit, Trash2, Eye, MapPin, Loader2 } from 'lucide-react';

interface Location {
  id: string;
  name: string;
  slug: string;
  region: string;
  status: string;
  updated_at: string;
}

export default function LocationsListPage() {
  const [locations, setLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const { toast } = useToast();

  const fetchLocations = async () => {
    setIsLoading(true);
    let query = supabase
      .from('locations')
      .select('id, name, slug, region, status, updated_at')
      .order('name', { ascending: true });

    if (searchQuery) {
      query = query.or(`name.ilike.%${searchQuery}%,region.ilike.%${searchQuery}%`);
    }

    const { data, error } = await query;

    if (error) {
      toast({ title: 'Greška', description: error.message, variant: 'destructive' });
    } else {
      setLocations(data || []);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchLocations();
  }, [searchQuery]);

  const handleDelete = async () => {
    if (!deleteId) return;
    
    setIsDeleting(true);
    const { error } = await supabase.from('locations').delete().eq('id', deleteId);
    
    if (error) {
      toast({ title: 'Greška pri brisanju', description: error.message, variant: 'destructive' });
    } else {
      toast({ title: 'Lokacija obrisana', description: 'Lokacija je uspješno obrisana.' });
      fetchLocations();
    }
    
    setIsDeleting(false);
    setDeleteId(null);
  };

  const getStatusBadge = (status: string) => {
    return status === 'published' ? (
      <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-700">
        Objavljeno
      </span>
    ) : (
      <span className="text-xs px-2 py-1 rounded-full bg-yellow-100 text-yellow-700">
        Nacrt
      </span>
    );
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Lokacije</h1>
            <p className="text-muted-foreground">Upravljajte stranicama lokacija</p>
          </div>
          <Link to="/admin/locations/new">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Nova lokacija
            </Button>
          </Link>
        </div>

        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Pretraži lokacije..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="border rounded-lg bg-background">
          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : locations.length === 0 ? (
            <div className="text-center py-12">
              <MapPin className="mx-auto h-12 w-12 text-muted-foreground/50" />
              <h3 className="mt-4 text-lg font-medium">Nema lokacija</h3>
              <p className="text-muted-foreground">Dodajte prvu lokaciju.</p>
              <Link to="/admin/locations/new">
                <Button className="mt-4">
                  <Plus className="mr-2 h-4 w-4" />
                  Nova lokacija
                </Button>
              </Link>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Naziv</TableHead>
                  <TableHead>Regija</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Ažurirano</TableHead>
                  <TableHead className="text-right">Akcije</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {locations.map((location) => (
                  <TableRow key={location.id}>
                    <TableCell>
                      <div>
                        <p className="font-medium">{location.name}</p>
                        <p className="text-sm text-muted-foreground">/lokacija/{location.slug}</p>
                      </div>
                    </TableCell>
                    <TableCell>{location.region}</TableCell>
                    <TableCell>{getStatusBadge(location.status)}</TableCell>
                    <TableCell>
                      {new Date(location.updated_at).toLocaleDateString('hr-HR')}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link to={`/lokacija/${location.slug}`} target="_blank">
                          <Button variant="ghost" size="icon">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Link to={`/admin/locations/${location.id}`}>
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </Link>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          onClick={() => setDeleteId(location.id)}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>

      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Jeste li sigurni?</AlertDialogTitle>
            <AlertDialogDescription>
              Ova akcija se ne može poništiti. Lokacija će biti trajno obrisana.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={isDeleting}>Odustani</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={isDeleting}>
              {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Obriši
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </AdminLayout>
  );
}
