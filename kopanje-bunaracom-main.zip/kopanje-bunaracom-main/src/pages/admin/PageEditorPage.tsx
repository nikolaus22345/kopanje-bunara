import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Save, Loader2, Eye } from 'lucide-react';
import { z } from 'zod';

const pageSchema = z.object({
  title: z.string().min(1, 'Naslov je obavezan'),
  slug: z.string().min(1, 'Slug je obavezan').regex(/^[a-z0-9-]+$/, 'Slug može sadržavati samo mala slova, brojeve i crtice'),
  content: z.string().optional(),
  status: z.enum(['draft', 'published']),
  meta_title: z.string().max(60, 'Meta naslov može imati maksimalno 60 znakova').optional(),
  meta_description: z.string().max(160, 'Meta opis može imati maksimalno 160 znakova').optional(),
});

export default function PageEditorPage() {
  const { id } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isLoading: authLoading, isAdmin } = useAuth();

  const [isLoading, setIsLoading] = useState(!isNew);
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [content, setContent] = useState('');
  const [status, setStatus] = useState<'draft' | 'published'>('draft');
  const [metaTitle, setMetaTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');

  useEffect(() => {
    async function fetchPage() {
      if (isNew) {
        setIsLoading(false);
        return;
      }

      if (!id || authLoading || !isAdmin) return;

      const { data: page, error } = await supabase
        .from('pages')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error || !page) {
        toast({ title: 'Greška', description: 'Stranica nije pronađena', variant: 'destructive' });
        navigate('/admin/pages');
        return;
      }

      setTitle(page.title);
      setSlug(page.slug);
      setContent(page.content || '');
      setStatus(page.status as 'draft' | 'published');
      setMetaTitle(page.meta_title || '');
      setMetaDescription(page.meta_description || '');
      setIsLoading(false);
    }

    fetchPage();
  }, [id, isNew, navigate, toast, authLoading, isAdmin]);

  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[čć]/g, 'c')
      .replace(/[šś]/g, 's')
      .replace(/[žź]/g, 'z')
      .replace(/đ/g, 'd')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  };

  const handleTitleChange = (value: string) => {
    setTitle(value);
    if (isNew || !slug) {
      setSlug(generateSlug(value));
    }
  };

  const handleSave = async () => {
    setErrors({});
    
    const result = pageSchema.safeParse({
      title,
      slug,
      content,
      status,
      meta_title: metaTitle,
      meta_description: metaDescription,
    });

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setIsSaving(true);

    const pageData = {
      title,
      slug,
      content: content || null,
      status,
      meta_title: metaTitle || null,
      meta_description: metaDescription || null,
    };

    let pageId = id;

    if (isNew) {
      const { data, error } = await supabase
        .from('pages')
        .insert([pageData])
        .select()
        .single();

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
      pageId = data.id;
    } else {
      const { error } = await supabase
        .from('pages')
        .update(pageData)
        .eq('id', id);

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
    }

    toast({ 
      title: isNew ? 'Stranica kreirana' : 'Stranica ažurirana', 
      description: 'Promjene su uspješno spremljene.' 
    });

    if (isNew) {
      navigate(`/admin/pages/${pageId}`);
    }

    setIsSaving(false);
  };

  if (isLoading || authLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/pages')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{isNew ? 'Nova stranica' : 'Uredi stranicu'}</h1>
              <p className="text-muted-foreground">
                {isNew ? 'Kreirajte novu stranicu' : 'Uredite postojeću stranicu'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!isNew && status === 'published' && (
              <a href={`/${slug}`} target="_blank" rel="noopener noreferrer">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  Pregledaj
                </Button>
              </a>
            )}
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Spremi
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sadržaj</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Naslov *</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="Unesite naslov stranice"
                    className={errors.title ? 'border-destructive' : ''}
                  />
                  {errors.title && <p className="text-sm text-destructive">{errors.title}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="slug">URL Slug *</Label>
                  <Input
                    id="slug"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    placeholder="url-slug-stranice"
                    className={errors.slug ? 'border-destructive' : ''}
                  />
                  {errors.slug && <p className="text-sm text-destructive">{errors.slug}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Sadržaj</Label>
                  <Textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Unesite sadržaj stranice (podržava HTML)"
                    rows={20}
                    className="font-mono text-sm"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Objava</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Nacrt</SelectItem>
                      <SelectItem value="published">Objavljeno</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>SEO</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="metaTitle">Meta naslov ({metaTitle.length}/60)</Label>
                  <Input
                    id="metaTitle"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    placeholder="SEO naslov"
                    maxLength={60}
                    className={errors.meta_title ? 'border-destructive' : ''}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="metaDescription">Meta opis ({metaDescription.length}/160)</Label>
                  <Textarea
                    id="metaDescription"
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    placeholder="SEO opis"
                    maxLength={160}
                    rows={3}
                    className={errors.meta_description ? 'border-destructive' : ''}
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
