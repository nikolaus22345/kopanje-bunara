import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, Save, Loader2, Eye } from 'lucide-react';
import { z } from 'zod';

const postSchema = z.object({
  title: z.string().min(1, 'Naslov je obavezan'),
  slug: z.string().min(1, 'Slug je obavezan').regex(/^[a-z0-9-]+$/, 'Slug može sadržavati samo mala slova, brojeve i crtice'),
  excerpt: z.string().optional(),
  content: z.string().optional(),
  cover_image: z.string().url().optional().or(z.literal('')),
  status: z.enum(['draft', 'published', 'scheduled']),
  meta_title: z.string().max(60, 'Meta naslov može imati maksimalno 60 znakova').optional(),
  meta_description: z.string().max(160, 'Meta opis može imati maksimalno 160 znakova').optional(),
});

interface Category {
  id: string;
  name: string;
}

interface Tag {
  id: string;
  name: string;
}

export default function PostEditorPage() {
  const { id } = useParams();
  const isNew = id === 'new';
  const navigate = useNavigate();
  const { toast } = useToast();
  const { isLoading: authLoading, isAdmin, user } = useAuth();

  const [isLoading, setIsLoading] = useState(!isNew);
  const [isSaving, setIsSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [title, setTitle] = useState('');
  const [slug, setSlug] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [status, setStatus] = useState<'draft' | 'published' | 'scheduled'>('draft');
  const [metaTitle, setMetaTitle] = useState('');
  const [metaDescription, setMetaDescription] = useState('');
  
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);

  useEffect(() => {
    async function fetchData() {
      if (authLoading || !isAdmin) return;

      // Fetch categories and tags
      const [categoriesRes, tagsRes] = await Promise.all([
        supabase.from('categories').select('id, name').order('name'),
        supabase.from('tags').select('id, name').order('name'),
      ]);
      
      setCategories(categoriesRes.data || []);
      setTags(tagsRes.data || []);

      if (isNew) {
        setIsLoading(false);
        return;
      }

      if (!id) return;

      const { data: post, error } = await supabase
        .from('posts')
        .select('*')
        .eq('id', id)
        .maybeSingle();

      if (error || !post) {
        toast({ title: 'Greška', description: 'Objava nije pronađena', variant: 'destructive' });
        navigate('/admin/posts');
        return;
      }

      setTitle(post.title);
      setSlug(post.slug);
      setExcerpt(post.excerpt || '');
      setContent(post.content || '');
      setCoverImage(post.cover_image || '');
      setStatus(post.status as 'draft' | 'published' | 'scheduled');
      setMetaTitle(post.meta_title || '');
      setMetaDescription(post.meta_description || '');

      // Fetch post categories and tags
      const [postCategoriesRes, postTagsRes] = await Promise.all([
        supabase.from('post_categories').select('category_id').eq('post_id', id),
        supabase.from('post_tags').select('tag_id').eq('post_id', id),
      ]);

      setSelectedCategories(postCategoriesRes.data?.map(pc => pc.category_id) || []);
      setSelectedTags(postTagsRes.data?.map(pt => pt.tag_id) || []);
      setIsLoading(false);
    }

    fetchData();
  }, [id, isNew, navigate, toast, authLoading, isAdmin]);

  const generateSlug = (text: string) => {
    return text
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[čć]/g, 'c')
      .replace(/[šś]/g, 's')
      .replace(/[žź]/g, 'z')
      .replace(/đ/g, 'd')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
  };

  const handleTitleChange = (value: string) => {
    setTitle(value);
    if (isNew || !slug) {
      setSlug(generateSlug(value));
    }
  };

  const handleSave = async () => {
    setErrors({});
    
    const result = postSchema.safeParse({
      title,
      slug,
      excerpt,
      content,
      cover_image: coverImage,
      status,
      meta_title: metaTitle,
      meta_description: metaDescription,
    });

    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.errors.forEach((err) => {
        fieldErrors[err.path[0] as string] = err.message;
      });
      setErrors(fieldErrors);
      return;
    }

    setIsSaving(true);

    const postData = {
      title,
      slug,
      excerpt: excerpt || null,
      content: content || null,
      cover_image: coverImage || null,
      status,
      meta_title: metaTitle || null,
      meta_description: metaDescription || null,
      author_id: user?.id,
      published_at: status === 'published' ? new Date().toISOString() : null,
    };

    let postId = id;

    if (isNew) {
      const { data, error } = await supabase
        .from('posts')
        .insert([postData])
        .select()
        .single();

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
      postId = data.id;
    } else {
      const { error } = await supabase
        .from('posts')
        .update(postData)
        .eq('id', id);

      if (error) {
        toast({ title: 'Greška', description: error.message, variant: 'destructive' });
        setIsSaving(false);
        return;
      }
    }

    // Update categories
    await supabase.from('post_categories').delete().eq('post_id', postId);
    if (selectedCategories.length > 0) {
      await supabase.from('post_categories').insert(
        selectedCategories.map(categoryId => ({ post_id: postId, category_id: categoryId }))
      );
    }

    // Update tags
    await supabase.from('post_tags').delete().eq('post_id', postId);
    if (selectedTags.length > 0) {
      await supabase.from('post_tags').insert(
        selectedTags.map(tagId => ({ post_id: postId, tag_id: tagId }))
      );
    }

    toast({ 
      title: isNew ? 'Objava kreirana' : 'Objava ažurirana', 
      description: 'Promjene su uspješno spremljene.' 
    });

    if (isNew) {
      navigate(`/admin/posts/${postId}`);
    }

    setIsSaving(false);
  };

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId) 
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const toggleTag = (tagId: string) => {
    setSelectedTags(prev => 
      prev.includes(tagId) 
        ? prev.filter(id => id !== tagId)
        : [...prev, tagId]
    );
  };

  if (isLoading || authLoading) {
    return (
      <AdminLayout>
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin/posts')}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold">{isNew ? 'Nova objava' : 'Uredi objavu'}</h1>
              <p className="text-muted-foreground">
                {isNew ? 'Kreirajte novu blog objavu' : 'Uredite postojeću objavu'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {!isNew && status === 'published' && (
              <a href={`/blog/${slug}`} target="_blank" rel="noopener noreferrer">
                <Button variant="outline">
                  <Eye className="mr-2 h-4 w-4" />
                  Pregledaj
                </Button>
              </a>
            )}
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Spremi
            </Button>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sadržaj</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title">Naslov *</Label>
                  <Input
                    id="title"
                    value={title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="Unesite naslov objave"
                    className={errors.title ? 'border-destructive' : ''}
                  />
                  {errors.title && <p className="text-sm text-destructive">{errors.title}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="slug">URL Slug *</Label>
                  <Input
                    id="slug"
                    value={slug}
                    onChange={(e) => setSlug(e.target.value)}
                    placeholder="url-slug-objave"
                    className={errors.slug ? 'border-destructive' : ''}
                  />
                  {errors.slug && <p className="text-sm text-destructive">{errors.slug}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="excerpt">Kratki opis</Label>
                  <Textarea
                    id="excerpt"
                    value={excerpt}
                    onChange={(e) => setExcerpt(e.target.value)}
                    placeholder="Kratki opis objave za prikaz u listi"
                    rows={3}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Sadržaj</Label>
                  <Textarea
                    id="content"
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder="Unesite sadržaj objave (podržava HTML)"
                    rows={15}
                    className="font-mono text-sm"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Objava</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Nacrt</SelectItem>
                      <SelectItem value="published">Objavljeno</SelectItem>
                      <SelectItem value="scheduled">Zakazano</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="coverImage">URL naslovne slike</Label>
                  <Input
                    id="coverImage"
                    value={coverImage}
                    onChange={(e) => setCoverImage(e.target.value)}
                    placeholder="https://..."
                    className={errors.cover_image ? 'border-destructive' : ''}
                  />
                  {errors.cover_image && <p className="text-sm text-destructive">{errors.cover_image}</p>}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Kategorije</CardTitle>
              </CardHeader>
              <CardContent>
                {categories.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nema kategorija</p>
                ) : (
                  <div className="space-y-2">
                    {categories.map((category) => (
                      <label key={category.id} className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={selectedCategories.includes(category.id)}
                          onChange={() => toggleCategory(category.id)}
                          className="rounded border-gray-300"
                        />
                        <span className="text-sm">{category.name}</span>
                      </label>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tagovi</CardTitle>
              </CardHeader>
              <CardContent>
                {tags.length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nema tagova</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {tags.map((tag) => (
                      <button
                        key={tag.id}
                        type="button"
                        onClick={() => toggleTag(tag.id)}
                        className={`px-3 py-1 text-sm rounded-full border transition-colors ${
                          selectedTags.includes(tag.id)
                            ? 'bg-primary text-primary-foreground border-primary'
                            : 'bg-background hover:bg-muted border-border'
                        }`}
                      >
                        {tag.name}
                      </button>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>SEO</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="metaTitle">Meta naslov ({metaTitle.length}/60)</Label>
                  <Input
                    id="metaTitle"
                    value={metaTitle}
                    onChange={(e) => setMetaTitle(e.target.value)}
                    placeholder="SEO naslov"
                    maxLength={60}
                    className={errors.meta_title ? 'border-destructive' : ''}
                  />
                  {errors.meta_title && <p className="text-sm text-destructive">{errors.meta_title}</p>}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="metaDescription">Meta opis ({metaDescription.length}/160)</Label>
                  <Textarea
                    id="metaDescription"
                    value={metaDescription}
                    onChange={(e) => setMetaDescription(e.target.value)}
                    placeholder="SEO opis"
                    maxLength={160}
                    rows={3}
                    className={errors.meta_description ? 'border-destructive' : ''}
                  />
                  {errors.meta_description && <p className="text-sm text-destructive">{errors.meta_description}</p>}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
