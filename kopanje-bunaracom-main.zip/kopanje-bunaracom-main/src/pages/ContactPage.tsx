import { useState, useEffect } from "react";
import { Helmet } from "react-helmet-async";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Phone, Mail, MapPin, Clock, Send, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface ContactInfo {
  phone: string;
  email: string;
  address: string;
  working_hours: string;
}

const defaultContactInfo: ContactInfo = {
  phone: "+385 97 601 9558",
  email: "info@kopanjebunara.hr",
  address: "Cijela Hrvatska",
  working_hours: "Pon - Pet: 07:00 - 19:00, Sub: 08:00 - 14:00",
};

export default function ContactPage() {
  const [contactInfo, setContactInfo] = useState<ContactInfo>(defaultContactInfo);

  useEffect(() => {
    async function fetchContactInfo() {
      const { data } = await supabase
        .from('page_sections')
        .select('content')
        .eq('page_key', 'contact')
        .eq('section_key', 'info')
        .single();

      if (data?.content && typeof data.content === 'object') {
        const content = data.content as Record<string, unknown>;
        setContactInfo({
          phone: (content.phone as string) || defaultContactInfo.phone,
          email: (content.email as string) || defaultContactInfo.email,
          address: (content.address as string) || defaultContactInfo.address,
          working_hours: (content.working_hours as string) || defaultContactInfo.working_hours,
        });
      }
    }
    fetchContactInfo();
  }, []);
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get("name") as string,
      phone: formData.get("phone") as string,
      email: formData.get("email") as string,
      location: formData.get("location") as string,
      message: formData.get("message") as string,
      formSource: "Kontakt stranica",
    };

    try {
      const { error } = await supabase.functions.invoke("send-contact-email", {
        body: data,
      });

      if (error) throw error;

      setIsSubmitted(true);
      toast({
        title: "Poruka poslana!",
        description: "Javit ćemo vam se u najkraćem mogućem roku.",
      });
    } catch (error) {
      console.error("Error sending email:", error);
      toast({
        title: "Greška",
        description: "Došlo je do greške. Molimo pokušajte ponovo ili nas nazovite.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Kontakt | KopanjeBunara.hr – Zatražite ponudu</title>
        <meta 
          name="description" 
          content="Kontaktirajte nas za kopanje i bušenje bunara. Besplatna procjena i ponuda. Nazovite +385 97 601 9558 ili ispunite kontakt obrazac." 
        />
        <link rel="canonical" href="https://kopanjebunara.hr/kontakt" />
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                Kontaktirajte nas
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Zatražite besplatnu procjenu ili nas nazovite za hitne upite. 
                Tu smo za vas!
              </p>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-24">
          <div className="container">
            <div className="grid gap-12 lg:grid-cols-2">
              {/* Contact Info */}
              <div>
                <h2 className="text-2xl font-bold text-foreground">
                  Kako nas možete kontaktirati
                </h2>
                <p className="mt-4 text-muted-foreground">
                  Dostupni smo za sve vaše upite vezane uz kopanje i bušenje bunara. 
                  Odgovaramo u najkraćem mogućem roku.
                </p>

                <div className="mt-8 space-y-6">
                  <a
                    href={`tel:${contactInfo.phone.replace(/\s/g, '')}`}
                    className="flex items-start gap-4 rounded-lg border border-border bg-card p-4 shadow-soft transition-all hover:shadow-medium"
                  >
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Telefon</h3>
                      <p className="text-lg font-medium text-primary">{contactInfo.phone}</p>
                      <p className="text-sm text-muted-foreground">Za hitne upite nazovite odmah</p>
                    </div>
                  </a>

                  <a
                    href={`mailto:${contactInfo.email}`}
                    className="flex items-start gap-4 rounded-lg border border-border bg-card p-4 shadow-soft transition-all hover:shadow-medium"
                  >
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Email</h3>
                      <p className="text-lg font-medium text-primary">{contactInfo.email}</p>
                      <p className="text-sm text-muted-foreground">Odgovaramo unutar 24 sata</p>
                    </div>
                  </a>

                  <div className="flex items-start gap-4 rounded-lg border border-border bg-card p-4 shadow-soft">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Područje rada</h3>
                      <p className="text-muted-foreground">{contactInfo.address}</p>
                      <p className="text-sm text-muted-foreground">Zagreb, Split, Osijek, Rijeka i okolica</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4 rounded-lg border border-border bg-card p-4 shadow-soft">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground">Radno vrijeme</h3>
                      <p className="text-muted-foreground">{contactInfo.working_hours}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div>
                <div className="rounded-xl border border-border bg-card p-6 shadow-medium md:p-8">
                  <h2 className="text-2xl font-bold text-foreground">
                    Zatražite besplatnu ponudu
                  </h2>
                  <p className="mt-2 text-muted-foreground">
                    Ispunite obrazac i javit ćemo vam se u najkraćem roku.
                  </p>

                  {isSubmitted ? (
                    <div className="mt-8 flex flex-col items-center py-8 text-center">
                      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                        <CheckCircle className="h-8 w-8 text-green-600" />
                      </div>
                      <h3 className="mt-4 text-xl font-semibold text-foreground">
                        Hvala na upitu!
                      </h3>
                      <p className="mt-2 text-muted-foreground">
                        Vaša poruka je uspješno poslana. Javit ćemo vam se u najkraćem mogućem roku.
                      </p>
                      <Button 
                        className="mt-6" 
                        onClick={() => setIsSubmitted(false)}
                      >
                        Pošaljite novi upit
                      </Button>
                    </div>
                  ) : (
                    <form onSubmit={handleSubmit} className="mt-6 space-y-4">
                      <div className="grid gap-4 sm:grid-cols-2">
                        <div>
                          <label htmlFor="name" className="mb-2 block text-sm font-medium text-foreground">
                            Ime i prezime *
                          </label>
                          <Input
                            id="name"
                            name="name"
                            type="text"
                            required
                            placeholder="Vaše ime"
                          />
                        </div>
                        <div>
                          <label htmlFor="phone" className="mb-2 block text-sm font-medium text-foreground">
                            Telefon *
                          </label>
                          <Input
                            id="phone"
                            name="phone"
                            type="tel"
                            required
                            placeholder="Vaš broj telefona"
                          />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="email" className="mb-2 block text-sm font-medium text-foreground">
                          Email
                        </label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          placeholder="Vaša email adresa"
                        />
                      </div>

                      <div>
                        <label htmlFor="location" className="mb-2 block text-sm font-medium text-foreground">
                          Lokacija *
                        </label>
                        <Input
                          id="location"
                          name="location"
                          type="text"
                          required
                          placeholder="Grad ili mjesto radova"
                        />
                      </div>

                      <div>
                        <label htmlFor="message" className="mb-2 block text-sm font-medium text-foreground">
                          Poruka *
                        </label>
                        <Textarea
                          id="message"
                          name="message"
                          required
                          rows={4}
                          placeholder="Opišite što vam treba (vrsta bunara, namjena, procjena dubine...)"
                        />
                      </div>

                      <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
                        {isSubmitting ? (
                          "Šaljem..."
                        ) : (
                          <>
                            Pošaljite upit
                            <Send className="ml-2 h-4 w-4" />
                          </>
                        )}
                      </Button>

                      <p className="text-center text-xs text-muted-foreground">
                        Vaši podaci su sigurni i neće biti dijeljeni s trećim stranama.
                      </p>
                    </form>
                  )}
                </div>
              </div>
            </div>
          </div>
        </section>
      </Layout>
    </>
  );
}
