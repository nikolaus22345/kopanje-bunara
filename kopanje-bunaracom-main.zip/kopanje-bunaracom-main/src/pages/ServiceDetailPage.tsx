import { Helmet } from "react-helmet-async";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { FAQSection } from "@/components/sections/FAQSection";
import { CTASection } from "@/components/sections/CTASection";
import { ArrowRight, Phone, CheckCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface FAQ {
  question: string;
  answer: string;
}

interface ServiceData {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  full_description: string | null;
  features: string[];
  faqs: FAQ[];
  meta_title: string | null;
  meta_description: string | null;
}

// Fallback data for services without DB entry
const fallbackServices: Record<string, ServiceData> = {
  "kopanje-bunara": {
    id: "kopanje-bunara",
    title: "Kopanje bunara",
    slug: "kopanje-bunara",
    description: "Tradicionalna metoda kopanja bunara pogodna za manje dubine i područja s visokom razinom podzemnih voda.",
    full_description: "Kopanje bunara je tradicionalna metoda osiguravanja vlastitog izvora vode. Kopani bunari su šireg promjera (80-150cm) i plići (do 15m), što ih čini idealnima za vrtove, manja imanja i područja s visokom razinom podzemnih voda.",
    features: [
      "Dubina do 15 metara",
      "Promjer 80-150 cm",
      "Idealno za vrtove i manja imanja",
      "Veći kapacitet akumulacije vode",
      "Jednostavnije održavanje",
      "Pogodno za područja s visokim vodnim slojem",
    ],
    faqs: [
      { question: "Kada je kopani bunar bolje rješenje od bušenog?", answer: "Kopani bunar je bolji izbor kada je voda blizu površine (do 15m), kada vam treba veći kapacitet akumulacije vode, ili kada je teren pogodan za kopanje. Također je često povoljniji za manje dubine." },
      { question: "Koliko dugo traje kopanje bunara?", answer: "Kopanje bunara obično traje 2-5 dana, ovisno o dubini, vrsti tla i vremenskim uvjetima." },
      { question: "Koja je minimalna dubina kopanog bunara?", answer: "Minimalna dubina ovisi o razini podzemnih voda na vašoj lokaciji. Obično je to 3-5 metara, ali može varirati." },
    ],
    meta_title: null,
    meta_description: null,
  },
  "busenje-bunara": {
    id: "busenje-bunara",
    title: "Bušenje bunara",
    slug: "busenje-bunara",
    description: "Moderna metoda bušenja za veće dubine i profesionalnu opskrbu vodom.",
    full_description: "Bušenje bunara je moderna metoda koja omogućuje pristup dubljim izvorima podzemne vode. Bušeni bunari su užeg promjera (15-30cm) ali mogu doseći dubine i preko 100 metara, što ih čini idealnim za veće potrebe za vodom.",
    features: [
      "Dubina do 100+ metara",
      "Promjer 15-30 cm",
      "Pogodno za sve vrste terena",
      "Pristup dubljim, kvalitetnijim izvorima",
      "Manja površina zahvata",
      "Brža izvedba od kopanja",
    ],
    faqs: [
      { question: "Do koje dubine možete bušiti?", answer: "Standardno bušimo do 100 metara dubine, ali u specifičnim uvjetima možemo ići i dublje. Dubina ovisi o geološkim uvjetima i vašim potrebama." },
      { question: "Koliko traje bušenje bunara?", answer: "Bušenje bunara obično traje 1-3 dana, ovisno o dubini i vrsti tla. Krški teren može zahtijevati više vremena." },
      { question: "Je li bušenje moguće na svakom terenu?", answer: "Da, moderna oprema omogućuje bušenje na gotovo svim vrstama terena, uključujući krš, šljunak i kamenje." },
    ],
    meta_title: null,
    meta_description: null,
  },
  "arteski-bunari": {
    id: "arteski-bunari",
    title: "Arteški bunari",
    slug: "arteski-bunari",
    description: "Specijalizirano bušenje arteških bunara s prirodnim tlakom vode.",
    full_description: "Arteški bunari su posebna vrsta bunara gdje voda prirodno izbija na površinu zbog podzemnog tlaka. Ovi bunari ne zahtijevaju pumpu za podizanje vode, što ih čini ekonomičnim dugoročnim rješenjem.",
    features: [
      "Prirodni tlak vode",
      "Nema potrebe za pumpom",
      "Izuzetno kvalitetna voda",
      "Niski troškovi održavanja",
      "Konstantan protok vode",
      "Dugoročno rješenje",
    ],
    faqs: [
      { question: "Što je arteški bunar?", answer: "Arteški bunar je bunar u kojem voda prirodno izbija na površinu zbog tlaka između nepropusnih slojeva tla. Ne zahtijeva pumpu za podizanje vode." },
      { question: "Kako znati imam li uvjete za arteški bunar?", answer: "Potrebna je geološka analiza terena. Arteški uvjeti ovise o specifičnoj geološkoj strukturi - vodonosnom sloju između dvaju nepropusnih slojeva." },
    ],
    meta_title: null,
    meta_description: null,
  },
  "ciscenje-bunara": {
    id: "ciscenje-bunara",
    title: "Čišćenje i održavanje bunara",
    slug: "ciscenje-bunara",
    description: "Redovito održavanje i čišćenje bunara za optimalnu funkcionalnost.",
    full_description: "Redovito održavanje bunara ključno je za očuvanje kvalitete vode i funkcionalnosti sustava. Nudimo kompletne usluge čišćenja, dezinfekcije i servisiranja bunara i pripadajuće opreme.",
    features: [
      "Čišćenje i ispiranje bunara",
      "Dezinfekcija",
      "Servis pumpi i opreme",
      "Analiza kvalitete vode",
      "Preventivno održavanje",
      "Hitne intervencije",
    ],
    faqs: [
      { question: "Koliko često treba čistiti bunar?", answer: "Preporučamo čišćenje bunara svakih 3-5 godina, ovisno o kvaliteti vode i intenzitetu korištenja. Redovita analiza vode pomoći će odrediti pravi trenutak." },
      { question: "Što uključuje čišćenje bunara?", answer: "Čišćenje uključuje ispumpavanje vode, mehaničko čišćenje stijenki, uklanjanje mulja i naslaga, dezinfekciju i ispiranje dok voda ne postane čista." },
    ],
    meta_title: null,
    meta_description: null,
  },
};

export default function ServiceDetailPage() {
  const { service: serviceSlug } = useParams<{ service: string }>();
  const navigate = useNavigate();
  
  const [service, setService] = useState<ServiceData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchService() {
      if (!serviceSlug) {
        navigate('/usluge');
        return;
      }

      // Try to fetch from database first
      const { data: dbData, error } = await supabase
        .from('services')
        .select('*')
        .eq('slug', serviceSlug)
        .eq('status', 'published')
        .maybeSingle();

      if (dbData) {
        setService({
          ...dbData,
          features: (dbData.features as unknown as string[]) || [],
          faqs: (dbData.faqs as unknown as FAQ[]) || [],
        });
      } else {
        // Use fallback data
        const fallback = fallbackServices[serviceSlug];
        if (fallback) {
          setService(fallback);
        } else {
          navigate('/usluge');
          return;
        }
      }
      setIsLoading(false);
    }

    fetchService();
  }, [serviceSlug, navigate]);

  if (isLoading) {
    return (
      <Layout>
        <div className="container py-20 flex justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </Layout>
    );
  }

  if (!service) {
    return (
      <Layout>
        <div className="container py-24 text-center">
          <h1 className="text-2xl font-bold">Usluga nije pronađena</h1>
          <Button asChild className="mt-4">
            <Link to="/usluge">Povratak na usluge</Link>
          </Button>
        </div>
      </Layout>
    );
  }

  const pageTitle = service.meta_title || `${service.title} | KopanjeBunara.hr`;
  const pageDescription = service.meta_description || `${(service.full_description || service.description || '').slice(0, 150)}... Profesionalna usluga u cijeloj Hrvatskoj. Nazovite +385 97 601 9558.`;

  return (
    <>
      <Helmet>
        <title>{pageTitle}</title>
        <meta name="description" content={pageDescription} />
        <link rel="canonical" href={`https://kopanjebunara.hr/usluge/${service.slug}`} />
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-3xl text-center">
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                {service.title}
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                {service.description}
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Button variant="hero" size="xl" asChild>
                  <Link to="/kontakt">
                    Zatražite ponudu
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="heroOutline" size="xl" asChild>
                  <a href="tel:+385976019558">
                    <Phone className="mr-2 h-5 w-5" />
                    +385 97 601 9558
                  </a>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Content */}
        <section className="py-16 md:py-24">
          <div className="container">
            <div className="mx-auto max-w-4xl">
              <div className="prose prose-lg max-w-none">
                <p className="text-lg text-muted-foreground">
                  {service.full_description}
                </p>

                {service.features.length > 0 && (
                  <>
                    <h2 className="mt-12 text-2xl font-bold text-foreground">
                      Što uključuje usluga
                    </h2>
                    <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                      {service.features.map((feature) => (
                        <li key={feature} className="flex items-start gap-3">
                          <CheckCircle className="mt-1 h-5 w-5 shrink-0 text-primary" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                )}

                <h2 className="mt-12 text-2xl font-bold text-foreground">
                  Naš proces
                </h2>
                <ol className="mt-6 space-y-4">
                  <li className="flex gap-4">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">1</span>
                    <div>
                      <h3 className="font-semibold text-foreground">Konzultacija i procjena</h3>
                      <p className="text-muted-foreground">Dolazimo na lokaciju, procjenjujemo uvjete i dajemo preporuke.</p>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">2</span>
                    <div>
                      <h3 className="font-semibold text-foreground">Ponuda i dogovor</h3>
                      <p className="text-muted-foreground">Pripremamo detaljnu ponudu s cijenama i rokovima.</p>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">3</span>
                    <div>
                      <h3 className="font-semibold text-foreground">Izvođenje radova</h3>
                      <p className="text-muted-foreground">Profesionalno izvodimo radove prema dogovorenim specifikacijama.</p>
                    </div>
                  </li>
                  <li className="flex gap-4">
                    <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">4</span>
                    <div>
                      <h3 className="font-semibold text-foreground">Primopredaja</h3>
                      <p className="text-muted-foreground">Testiramo sustav i predajemo s uputama za održavanje.</p>
                    </div>
                  </li>
                </ol>
              </div>
            </div>
          </div>
        </section>

        {service.faqs.length > 0 && (
          <FAQSection
            title={`Česta pitanja o usluzi ${service.title.toLowerCase()}`}
            description="Odgovori na najčešća pitanja naših klijenata."
            faqs={service.faqs}
          />
        )}

        <CTASection />
      </Layout>
    </>
  );
}
