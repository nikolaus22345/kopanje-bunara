import { Helmet } from "react-helmet-async";
import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { CTASection } from "@/components/sections/CTASection";
import { ArrowRight, CheckCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface FeatureItem {
  title?: string;
  description?: string;
  icon?: string;
}

interface ServiceItem {
  id: string;
  slug: string;
  title: string;
  description: string | null;
  features: (string | FeatureItem)[];
}

// Fallback services for backward compatibility
const fallbackServices: ServiceItem[] = [
  {
    id: "1",
    slug: "kopanje-bunara",
    title: "Kopanje bunara",
    description: "Tradicionalna metoda kopanja bunara pogodna za manje dubine i područja s visokom razinom podzemnih voda.",
    features: ["Dubina do 15 metara", "Promjer 80-150 cm", "Idealno za vrtove i manja imanja", "Veći kapacitet akumulacije vode"],
  },
  {
    id: "2",
    slug: "busenje-bunara",
    title: "Bušenje bunara",
    description: "Moderna metoda bušenja za veće dubine i profesionalnu opskrbu vodom.",
    features: ["Dubina do 100+ metara", "Promjer 15-30 cm", "Pogodno za sve vrste terena", "Pristup dubljim, kvalitetnijim izvorima"],
  },
  {
    id: "3",
    slug: "arteski-bunari",
    title: "Arteški bunari",
    description: "Specijalizirano bušenje arteških bunara s prirodnim tlakom vode.",
    features: ["Prirodni tlak vode", "Nema potrebe za pumpom", "Izuzetno kvalitetna voda", "Niski troškovi održavanja"],
  },
  {
    id: "4",
    slug: "ciscenje-bunara",
    title: "Čišćenje i održavanje bunara",
    description: "Redovito održavanje i čišćenje bunara za optimalnu funkcionalnost.",
    features: ["Čišćenje i ispiranje bunara", "Dezinfekcija", "Servis pumpi i opreme", "Analiza kvalitete vode"],
  },
];

export default function ServicesPage() {
  const [services, setServices] = useState<ServiceItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function fetchServices() {
      const { data, error } = await supabase
        .from('services')
        .select('id, slug, title, description, features')
        .eq('status', 'published')
        .order('title', { ascending: true });

      if (data && data.length > 0) {
        setServices(data.map(s => ({
          ...s,
          features: (s.features as unknown as string[]) || [],
        })));
      } else {
        // Use fallback services
        setServices(fallbackServices);
      }
      setIsLoading(false);
    }

    fetchServices();
  }, []);

  return (
    <>
      <Helmet>
        <title>Usluge | Kopanje i bušenje bunara | KopanjeBunara.hr</title>
        <meta 
          name="description" 
          content="Usluge kopanja i bušenja bunara, arteških bunara, čišćenja i održavanja. Profesionalna izvedba u cijeloj Hrvatskoj. Nazovite 099 123 4567." 
        />
        <link rel="canonical" href="https://kopanjebunara.hr/usluge" />
      </Helmet>

      <Layout>
        {/* Hero */}
        <section className="bg-primary py-16 md:py-20">
          <div className="container">
            <div className="mx-auto max-w-2xl text-center">
              <h1 className="text-3xl font-bold tracking-tight text-primary-foreground md:text-4xl lg:text-5xl">
                Naše usluge
              </h1>
              <p className="mt-4 text-lg text-primary-foreground/80">
                Pružamo kompletne usluge kopanja, bušenja i održavanja bunara. 
                Od procjene terena do gotovog projekta.
              </p>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-16 md:py-24">
          <div className="container">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <div className="grid gap-8 md:grid-cols-2">
                {services.map((service) => (
                  <div
                    key={service.id}
                    className="flex flex-col rounded-xl border border-border bg-card p-6 shadow-soft md:p-8"
                  >
                    <h2 className="text-2xl font-bold text-foreground">
                      {service.title}
                    </h2>
                    <p className="mt-2 text-muted-foreground">
                      {service.description}
                    </p>
                    <ul className="mt-6 space-y-2">
                      {service.features.slice(0, 4).map((feature, index) => {
                        const displayText = typeof feature === 'string' 
                          ? feature 
                          : feature.title || feature.description || '';
                        return (
                          <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                            <CheckCircle className="h-4 w-4 shrink-0 text-primary" />
                            {displayText}
                          </li>
                        );
                      })}
                    </ul>
                    <div className="mt-auto pt-6">
                      <Button variant="outline" asChild>
                        <Link to={`/usluge/${service.slug}`}>
                          Saznajte više
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        <CTASection />
      </Layout>
    </>
  );
}
