import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface ContactFormRequest {
  name: string;
  phone: string;
  email?: string;
  location: string;
  message: string;
  formSource?: string;
}

async function sendEmail(options: { from: string; to: string[]; subject: string; html: string }) {
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(options),
  });
  return response.json();
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { name, phone, email, location, message, formSource = "Kontakt forma" }: ContactFormRequest = await req.json();

    console.log("Received contact form submission:", { name, phone, email, location, formSource });

    // Send notification email to admin
    const adminEmailResponse = await sendEmail({
      from: "KopanjeBunara.hr <onboarding@resend.dev>",
      to: ["nikolacvitanovic.hr@gmail.com"],
      subject: `Nova poruka - ${formSource} | ${name}`,
      html: `
        <h2>Nova poruka s web stranice KopanjeBunara.hr</h2>
        <p><strong>Izvor:</strong> ${formSource}</p>
        <hr />
        <p><strong>Ime i prezime:</strong> ${name}</p>
        <p><strong>Telefon:</strong> ${phone}</p>
        <p><strong>Email:</strong> ${email || "Nije naveden"}</p>
        <p><strong>Lokacija:</strong> ${location}</p>
        <hr />
        <p><strong>Poruka:</strong></p>
        <p>${message.replace(/\n/g, "<br />")}</p>
        <hr />
        <p style="color: #666; font-size: 12px;">Ova poruka je automatski poslana s web stranice KopanjeBunara.hr</p>
      `,
    });

    console.log("Admin email sent successfully:", adminEmailResponse);

    // Optionally send confirmation email to user if they provided email
    if (email) {
      const userEmailResponse = await sendEmail({
        from: "KopanjeBunara.hr <onboarding@resend.dev>",
        to: [email],
        subject: "Primili smo vaš upit | KopanjeBunara.hr",
        html: `
          <h2>Hvala na upitu, ${name}!</h2>
          <p>Primili smo vašu poruku i javit ćemo vam se u najkraćem mogućem roku.</p>
          <hr />
          <p><strong>Vaša poruka:</strong></p>
          <p>${message.replace(/\n/g, "<br />")}</p>
          <hr />
          <p>Za hitne upite nazovite nas na <strong>+385 97 601 9558</strong></p>
          <p>Srdačan pozdrav,<br />Tim KopanjeBunara.hr</p>
        `,
      });
      console.log("User confirmation email sent:", userEmailResponse);
    }

    return new Response(JSON.stringify({ success: true }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: unknown) {
    console.error("Error in send-contact-email function:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);
