-- Create locations table for managing location pages
CREATE TABLE public.locations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  region TEXT NOT NULL,
  description TEXT,
  soil_info TEXT,
  water_info TEXT,
  nearby_areas JSONB DEFAULT '[]'::jsonb,
  faqs JSONB DEFAULT '[]'::jsonb,
  meta_title TEXT,
  meta_description TEXT,
  status TEXT NOT NULL DEFAULT 'published',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create services table for managing service pages
CREATE TABLE public.services (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  full_description TEXT,
  features JSONB DEFAULT '[]'::jsonb,
  faqs JSONB DEFAULT '[]'::jsonb,
  meta_title TEXT,
  meta_description TEXT,
  status TEXT NOT NULL DEFAULT 'published',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

-- RLS policies for locations
CREATE POLICY "Anyone can view published locations" 
ON public.locations 
FOR SELECT 
USING ((status = 'published') OR is_admin());

CREATE POLICY "Admins can insert locations" 
ON public.locations 
FOR INSERT 
WITH CHECK (is_admin());

CREATE POLICY "Admins can update locations" 
ON public.locations 
FOR UPDATE 
USING (is_admin());

CREATE POLICY "Admins can delete locations" 
ON public.locations 
FOR DELETE 
USING (is_admin());

-- RLS policies for services
CREATE POLICY "Anyone can view published services" 
ON public.services 
FOR SELECT 
USING ((status = 'published') OR is_admin());

CREATE POLICY "Admins can insert services" 
ON public.services 
FOR INSERT 
WITH CHECK (is_admin());

CREATE POLICY "Admins can update services" 
ON public.services 
FOR UPDATE 
USING (is_admin());

CREATE POLICY "Admins can delete services" 
ON public.services 
FOR DELETE 
USING (is_admin());

-- Add updated_at triggers
CREATE TRIGGER update_locations_updated_at
BEFORE UPDATE ON public.locations
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_services_updated_at
BEFORE UPDATE ON public.services
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();