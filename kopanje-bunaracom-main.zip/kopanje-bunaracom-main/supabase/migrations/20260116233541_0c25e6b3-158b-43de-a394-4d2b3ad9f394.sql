-- Drop existing restrictive policy
DROP POLICY IF EXISTS "Anyone can view published posts" ON public.posts;

-- Create new permissive policy for viewing published posts
CREATE POLICY "Anyone can view published posts" 
ON public.posts 
FOR SELECT 
USING ((status = 'published') OR is_admin());