-- Create page_sections table for managing section content
CREATE TABLE public.page_sections (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    page_key TEXT NOT NULL,
    section_key TEXT NOT NULL,
    title TEXT,
    subtitle TEXT,
    description TEXT,
    content JSONB DEFAULT '{}'::jsonb,
    sort_order INTEGER DEFAULT 0,
    is_visible BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
    UNIQUE(page_key, section_key)
);

-- Enable RLS
ALTER TABLE public.page_sections ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view visible sections" 
ON public.page_sections 
FOR SELECT 
USING (is_visible = true OR is_admin());

CREATE POLICY "Admins can insert sections" 
ON public.page_sections 
FOR INSERT 
WITH CHECK (is_admin());

CREATE POLICY "Admins can update sections" 
ON public.page_sections 
FOR UPDATE 
USING (is_admin());

CREATE POLICY "Admins can delete sections" 
ON public.page_sections 
FOR DELETE 
USING (is_admin());

-- Add trigger for updated_at
CREATE TRIGGER update_page_sections_updated_at
BEFORE UPDATE ON public.page_sections
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Insert default sections for Home page
INSERT INTO public.page_sections (page_key, section_key, title, subtitle, description, content, sort_order) VALUES
('home', 'hero', 'Profesionalno kopanje i bušenje bunara', 'Pouzdana rješenja za vodoopskrbu vašeg doma i imanja', 'Specijalizirani smo za izradu bunara po cijeloj Hrvatskoj. S više od 15 godina iskustva, pružamo kvalitetnu uslugu kopanja i bušenja bunara prilagođenu vašim potrebama.', '{"cta_primary": "Zatražite ponudu", "cta_secondary": "Saznajte više", "stats": [{"value": "500+", "label": "Izrađenih bunara"}, {"value": "15+", "label": "Godina iskustva"}, {"value": "100%", "label": "Zadovoljnih klijenata"}]}'::jsonb, 1),
('home', 'features', 'Zašto odabrati nas?', NULL, 'Naše prednosti koje nas izdvajaju od konkurencije', '{"features": [{"icon": "Shield", "title": "Stručnost i iskustvo", "description": "Više od 15 godina iskustva u kopanju i bušenju bunara diljem Hrvatske."}, {"icon": "Clock", "title": "Brza izvedba", "description": "Efikasna realizacija projekta uz poštivanje dogovorenih rokova."}, {"icon": "Award", "title": "Kvalitetni materijali", "description": "Koristimo samo provjerene i certificirane materijale."}, {"icon": "Headphones", "title": "Stručna podrška", "description": "Dostupni smo za sva vaša pitanja i savjetovanje."}]}'::jsonb, 2),
('home', 'services', 'Naše usluge', NULL, 'Nudimo širok spektar usluga vezanih za bunare', '{}'::jsonb, 3),
('home', 'process', 'Kako radimo?', NULL, 'Jednostavan proces od upita do gotovog bunara', '{"steps": [{"number": "1", "title": "Kontaktirajte nas", "description": "Ispunite obrazac ili nas nazovite za besplatnu konzultaciju."}, {"number": "2", "title": "Procjena terena", "description": "Naš stručnjak dolazi na teren i procjenjuje mogućnosti."}, {"number": "3", "title": "Izrada ponude", "description": "Dobivate detaljnu ponudu s cijenom i rokovima."}, {"number": "4", "title": "Realizacija", "description": "Izvodimo radove prema dogovorenom planu."}]}'::jsonb, 4),
('home', 'locations', 'Gdje radimo?', NULL, 'Pokrivamo cijelu Hrvatsku', '{}'::jsonb, 5),
('home', 'faq', 'Često postavljana pitanja', NULL, 'Odgovori na najčešća pitanja o kopanju bunara', '{"faqs": [{"question": "Koliko košta kopanje bunara?", "answer": "Cijena ovisi o dubini, vrsti tla i lokaciji. Kontaktirajte nas za besplatnu procjenu."}, {"question": "Koliko traje izrada bunara?", "answer": "Prosječno 1-3 dana, ovisno o dubini i uvjetima terena."}, {"question": "Treba li mi dozvola?", "answer": "Za bunare do 10m dubine i kapaciteta do 10m³ dnevno nije potrebna dozvola."}]}'::jsonb, 6),
('home', 'cta', 'Spremni za vlastiti bunar?', NULL, 'Kontaktirajte nas danas za besplatnu procjenu i ponudu', '{"cta_text": "Zatražite besplatnu ponudu", "phone": "+385 99 123 4567"}'::jsonb, 7),
('contact', 'hero', 'Kontaktirajte nas', NULL, 'Javite nam se za besplatnu konzultaciju i ponudu', '{}'::jsonb, 1),
('contact', 'info', 'Kontakt informacije', NULL, NULL, '{"phone": "+385 99 123 4567", "email": "info@kopanjebunara.hr", "address": "Zagreb, Hrvatska", "working_hours": "Pon-Pet: 08:00 - 18:00, Sub: 09:00 - 14:00"}'::jsonb, 2),
('services', 'hero', 'Naše usluge', NULL, 'Profesionalne usluge kopanja i bušenja bunara', '{}'::jsonb, 1),
('locations', 'hero', 'Lokacije', NULL, 'Pokrivamo cijelu Hrvatsku', '{}'::jsonb, 1),
('blog', 'hero', 'Blog', NULL, 'Korisni savjeti i informacije o bunarima', '{}'::jsonb, 1);